"""Regression for v5 user footage/log analysis: independent keeper and spaced forwards.

Uses real strategy and fake robot backend, not real physics.
"""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.main import _act_normal, _act_our_kickoff, Phase
from src.keeper_v33 import goalie_decision
from src.framework.types import GameControlState, GameState
from src.param import KEEPER_ACTIVE_DISTANCE_FROM_GOAL_M, FORWARD_SEPARATION_M

class IndependentKeeperV33(unittest.TestCase):
    def test_quarter_pitch_trigger_is_from_own_goal(self):
        ctx, ps, _=scene(ball=(-3.50,0))
        d=goalie_decision(ctx,(0,0),())
        self.assertTrue(d.dangerous)
        self.assertEqual(KEEPER_ACTIVE_DISTANCE_FROM_GOAL_M,3.5)
        self.assertGreater(d.target[0],-6.57)
    def test_far_ball_maintains_home(self):
        ctx,ps,_=scene(ball=(-1.0,1.1))
        d=goalie_decision(ctx,(0,0),())
        self.assertFalse(d.dangerous)
        self.assertAlmostEqual(d.target[0],-6.57)
    def test_stationary_wide_ball_does_not_freeze_near_goal(self):
        ctx,ps,_=scene(ball=(-5.0,-2.3),poses=((-1,2,0),(-6.57,-0.68,0),(-1,-2.9,0)))
        d=goalie_decision(ctx,(0,0),())
        self.assertTrue(d.dangerous)
        self.assertGreater(d.target[0],-6.4)
        self.assertLessEqual(abs(d.target[1]),1.13+1e-8)
        ps[1].guard(forwards=(ps[0].pose,ps[2].pose))
        self.assertGreater(math.hypot(*ps[1].desired_velocity[:2]),0.4)
        self.assertEqual(ps[1].action,'guard:step_block')
    def test_forward_between_ball_and_goal_stops_keeper_rush(self):
        ctx,ps,_=scene(ball=(-4.2,0.3),poses=((-5.2,0.15,0),(-6.56,0,0),(0,2,0)))
        d=goalie_decision(ctx,(0,0),(ps[0].pose,ps[2].pose))
        self.assertTrue(d.covered_by_forward)
        self.assertEqual(d.action,'guard:covered_line')
        self.assertAlmostEqual(d.target[0],-6.57)
    def test_forward_off_shot_line_means_goalie_steps_forward(self):
        ctx,ps,_=scene(ball=(-4.2,0.3),poses=((-5.2,2.0,0),(-6.56,0,0),(0,-2,0)))
        d=goalie_decision(ctx,(0,0),(ps[0].pose,ps[2].pose))
        self.assertFalse(d.covered_by_forward)
        self.assertEqual(d.action,'guard:step_block')
        self.assertGreater(d.target[0],-6.57)
    def test_fast_incoming_shot_wins_over_rush(self):
        ctx,ps,_=scene(ball=(-4.7,0.2))
        d=goalie_decision(ctx,(-4,0),())
        self.assertEqual(d.action,'guard:urgent_block')
        self.assertAlmostEqual(d.target[0],-6.57)
    def test_goalie_always_has_separate_controller(self):
        ctx,ps,st=scene(ball=(-5.0,-2.3),poses=((-3.9,-2.2,0),(-6.57,-0.68,0),(-2.9,1.1,0)))
        _act_normal(ctx,ps,st)
        self.assertNotEqual(st.normal_attacker,2)
        self.assertTrue(ps[1].action.startswith('guard:'))
        self.assertTrue(ps[0].action.startswith(('attack:','press:','support:')))
        self.assertTrue(ps[2].action.startswith(('attack:','press:','support:')))
    def test_keeper_kick_is_not_cancelled_by_striker(self):
        ctx,ps,st=scene(ball=(-5.7,.3),poses=((-2,0,0),(-6.2,.3,0),(-1,2,0)))
        _act_normal(ctx,ps,st)
        self.assertTrue(ps[1].is_kicking)
        self.assertEqual(ps[1].action,'guard:emergency_clear')
        self.assertNotEqual(st.normal_attacker,2)
    def test_goalkeeper_faces_ball_outside_goal_mouth(self):
        ctx,ps,st=scene(ball=(-4.0,2.0),poses=((-2,0,0),(-6.56,0,0),(0,2,0)))
        ps[1].guard(forwards=(ps[0].pose,ps[2].pose))
        self.assertGreater(ps[1].desired_velocity[2],0.0)
        self.assertGreaterEqual(ps[1].navigation.find('keeper'),0)
    def test_goalkeeper_near_net_does_not_rotate_to_behind(self):
        ctx,ps,st=scene(ball=(-6.9,0.2),poses=((-2,0,0),(-6.6,0,0),(0,2,0)))
        ps[1].guard()
        self.assertTrue(ps[1].action.startswith('guard:'))
        self.assertLessEqual(abs(ps[1].target[1]),1.13+1e-7)
        self.assertGreaterEqual(ps[1].target[0],-6.85)
    def test_kickoff_aim_is_plus_minus_one(self):
        ctx,ps,st=scene(poses=((-0.4,0,0),(-6.5,0,0),(-.55,-1.9,0)),now=5)
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        self.assertEqual(st.kickoff_taker,1)
        self.assertAlmostEqual(abs(st.kickoff_aim[1]),1)
        self.assertEqual(ps[0].kick_command[1],10)
    def test_strikers_separate_when_too_close(self):
        ctx,ps,st=scene(ball=(3,0),poses=((2.5,0,0),(-6.57,0,0),(2.6,.25,0)))
        _act_normal(ctx,ps,st)
        self.assertIn('support:separate_forward',(ps[0].action,ps[2].action))
        target=ps[2].target if ps[2].action=='support:separate_forward' else ps[0].target
        self.assertGreater(abs(target[1]),1.2)
    def test_ball_slips_behind_keeper_recover_mouth(self):
        ctx,ps,_=scene(ball=(-6.89,0.25),poses=((-4,0,0),(-6.58,0,0),(0,2,0)))
        d=goalie_decision(ctx,(-.8,0),())
        self.assertLessEqual(d.target[0],-6.67)
        self.assertGreaterEqual(d.target[0],-6.85)
        self.assertTrue(d.action.startswith('guard:'))
    def test_kickoff_shot_turns_before_misaligned_kick(self):
        ctx,ps,st=scene(poses=((-0.4,0,1.3),(-6.57,0,0),(-.55,-1.95,0)),now=6)
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        self.assertEqual(ps[0].action,'kickoff:align')
        self.assertFalse(ps[0].is_kicking)
        self.assertGreater(abs(ps[0].desired_velocity[2]),0.1)
    def test_goalie_does_not_kick_during_opp_restart(self):
        ctx,ps,st=scene(ball=(-6.0,0),poses=((-2,0,0),(-6.5,0,0),(1,1,0)),
                        game=GameControlState(state=GameState.PLAYING))
        # assert ordinary goalie can kick; referee safety elsewhere tests opp set play.
        ps[1].guard(allow_clear=False)
        self.assertFalse(ps[1].is_kicking)

if __name__=='__main__': unittest.main()
