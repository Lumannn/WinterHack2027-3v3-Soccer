"""Regression for V34 stability gate and evidence-filtered direction calibration."""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.param import SHOT_POWER, CLEAR_IN_OUR_HALF_POWER
from tools.shot_feedback import analyze


class V34FeedbackCalibration(unittest.TestCase):
    def test_own_half_emergency_clear_is_eight(self):
        ctx, ps, _ = scene(ball=(-5.0, 0.0), poses=((-5.44, 0, 0),))
        self.assertEqual(ps[0].plan_kick()[1], CLEAR_IN_OUR_HALF_POWER)

    def test_opponent_half_shot_power_eight(self):
        ctx, ps, _ = scene(ball=(4, 0), poses=((3.55, 0, 0),))
        self.assertEqual(ps[0].plan_kick()[1], SHOT_POWER)

    def test_sprinting_robot_brakes_before_close_power_shot(self):
        ctx, ps, _ = scene(ball=(4, 0), poses=((3.57, 0, 0),))
        p = ps[0]
        p.attack()
        self.assertTrue(p.is_kicking)
        # Move 20cm in 100ms: rapid approach; close enough but unstable.
        new_poses=dict(ctx.teammates)
        new_poses[1]=replace(new_poses[1],pose=replace(new_poses[1].pose,x=3.77),last_seen_at=ctx.now+0.1)
        new_ctx=replace(ctx,now=ctx.now+0.1,teammates=new_poses,
                        ball=replace(ctx.ball,last_seen_at=ctx.now+0.1))
        p.context=new_ctx
        p.attack()
        self.assertEqual(p.action, 'attack:shot_brake')
        self.assertFalse(p.is_kicking)
        self.assertEqual(p.desired_velocity,(0.0,0.0,0.0))

    @staticmethod
    def row(t, x, y, *, cmd=None, action='attack:shoot'):
        return dict(t=t, ball=[x,y], robots=[dict(id=1,action=action,
                    pose=[x-0.40,y,0],kick_contact_distance=0.40,
                    kick_command_world=([cmd,8.0] if cmd is not None else None))],
                    opponents=[])

    def test_no_movement_cannot_generate_direction_bias(self):
        rows=[self.row(i*.2,4,0,cmd=0 if i==0 else None) for i in range(7)]
        report=analyze(rows)
        self.assertEqual(report['summary']['candidate_count'],0)
        self.assertIsNone(report['summary']['proposed_compensation_deg'])

    def test_three_moving_shots_still_require_video_review(self):
        rows=[]
        for k in range(3):
            base=k*3.0
            rows.append(self.row(base,4,0,cmd=0.0))
            rows.append(self.row(base+.2,4.35,.02,cmd=None))
        report=analyze(rows)
        self.assertEqual(report['summary']['candidate_count'],3)
        self.assertIsNotNone(report['summary']['proposed_compensation_deg'])
        self.assertIn('video',report['summary']['note'])


if __name__=='__main__':unittest.main()
