"""V36 no-log footage follow-up: deterministic controller checks, NOT physics proof."""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.framework.types import GameControlState,GameState
from src.main import Phase,_act_our_kickoff, _act_normal
from src.keeper_v33 import goalie_decision
from src.param import (KEEPER_V36_MIN_LEGAL_X_OFFSET_M, KICKOFF_SHOOT_POWER,
                       PRESS_V36_POKE_POWER)


def next_frame(ctx,players,t,ball):
    ctx=replace(ctx,now=t,ball=replace(ctx.ball,x=ball[0],y=ball[1],last_seen_at=t),
                teammates={i:replace(s,last_seen_at=t) for i,s in ctx.teammates.items()})
    for p in players: p.context=ctx
    return ctx

class V36VideoRegressions(unittest.TestCase):
    def test_mouth_rescue_overrides_forward_cover_when_ball_behind_keeper(self):
        ctx,ps,_=scene(ball=(-6.83,0.25),poses=((-6.5,0.25,0),(-6.25,0.2,0),(0,2,0)))
        # Here robot1 is between ball and goal only in trivial terms; keeper still rescues.
        d=goalie_decision(ctx,(-.35,0), (ps[0].pose,ps[2].pose))
        self.assertEqual(d.action,'guard:mouth_rescue')
        self.assertLess(d.target[0],-6.57)
        self.assertGreaterEqual(d.target[0],-7 + KEEPER_V36_MIN_LEGAL_X_OFFSET_M - 1e-8)
        ps[1].guard(forwards=(ps[0].pose,ps[2].pose))
        self.assertEqual(ps[1].action,'guard:mouth_rescue')
        self.assertLess(ps[1].target[0],-6.57)
        # V37 turns first if goal-line recovery point lies substantially behind.
        self.assertTrue(abs(ps[1].desired_velocity[2]) > 0.1 or ps[1].desired_velocity[0] < 0)

    def test_mouth_rescue_must_stay_in_field(self):
        for bx in (-6.99,-6.93,-6.81,-6.45):
            ctx,_,_=scene(ball=(bx,0.2))
            d=goalie_decision(ctx,(-.3,0),())
            self.assertGreaterEqual(d.target[0], -7+KEEPER_V36_MIN_LEGAL_X_OFFSET_M-1e-7)
            self.assertLess(d.target[0],-6.56)

    def test_near_post_ball_not_far_wide_chase(self):
        ctx,ps,_=scene(ball=(-6.45,2.05),poses=((-3,0,0),(-6.55,0,0),(0,2,0)))
        d=goalie_decision(ctx,(0,0),())
        self.assertNotEqual(d.action,'guard:mouth_rescue')
        self.assertLessEqual(abs(d.target[1]),1.13+1e-6)

    def test_keeper_clears_when_ball_really_in_front_and_reachable(self):
        ctx,ps,st=scene(ball=(-6.43,.25),poses=((-3,0,0),(-6.7,.25,0),(0,2,0)))
        ps[1].guard()
        self.assertEqual(ps[1].action,'guard:emergency_clear')
        self.assertEqual(ps[1].kick_command[1],8.0)
        self.assertGreater(math.cos(ps[1].kick_command[0]),0)

    def test_keeper_sdk_lease_continues_across_small_ball_jitter(self):
        ctx,ps,_=scene(ball=(-6.25,0),poses=((-2,2,0),(-6.57,0,0),(0,2,0)))
        g=ps[1]
        g.guard()
        self.assertEqual(g.action,'guard:emergency_clear')
        self.assertTrue(g.is_kicking)
        ctx=next_frame(ctx,ps,ctx.now+0.12,(-6.20,0.03))
        g.guard()
        self.assertEqual(g.action,'guard:clear_lease')
        self.assertTrue(g.is_kicking)
        self.assertEqual(g.kick_command[1],8)

    def test_keeper_clear_lease_ends_when_ball_moves_away(self):
        ctx,ps,_=scene(ball=(-6.25,0),poses=((-2,2,0),(-6.57,0,0),(0,2,0)))
        g=ps[1];g.guard()
        ctx=next_frame(ctx,ps,ctx.now+0.16,(-5.65,0))
        g.guard()
        self.assertIsNone(g._v36_keeper_clear_origin)
        self.assertFalse(g.is_kicking)

    def test_direct_corners_remain_inside_opponent_posts_and_power10(self):
        ctx,ps,st=scene(poses=((-0.60,0,0),(-6.5,0,0),(-.55,-1.9,0)))
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        self.assertTrue(abs(st.kickoff_aim[1])<ctx.field.goal_width/2)
        self.assertAlmostEqual(abs(st.kickoff_aim[1]),1.0)
        self.assertTrue(ps[0].is_kicking)
        self.assertEqual(ps[0].kick_command[1],KICKOFF_SHOOT_POWER)
        self.assertEqual(ps[0].action,'kickoff:direct_shoot')

    def test_old_077_fails_safety_but_065_engages_earlier_than_v35(self):
        _,ps,_=scene(poses=((-0.77,0,0),))
        ps[0].kick_off_direct((7,1),0)
        self.assertFalse(ps[0].is_kicking)
        _,ps,_=scene(poses=((-0.65,0,0),))
        ps[0].kick_off_direct((7,1),0)
        self.assertTrue(ps[0].is_kicking)

    def test_nudged_ball_041_m_does_not_abort_sdk_lease(self):
        ctx,ps,st=scene(poses=((-0.6,0,0),(-6.5,0,0),(-2,-2,0)),now=4)
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        self.assertTrue(ps[0].is_kicking)
        self.assertEqual(ps[0]._ko35_mode,'sdk')
        ctx=next_frame(ctx,ps,4.32,(0.42,0.01)) # 1.31m/s, not clean high-speed launch
        st.prev_phase=Phase.OUR_KICKOFF
        _act_our_kickoff(ctx,ps,st)
        self.assertFalse(ps[0]._ko35_verified)
        self.assertEqual(ps[0]._ko35_mode,'sdk')
        self.assertTrue(ps[0].is_kicking)

    def test_fast_launch_releases_when_verified(self):
        ctx,ps,st=scene(poses=((-0.6,0,0),(-6.5,0,0),(-2,-2,0)),now=4)
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        ctx=next_frame(ctx,ps,4.10,(0.05,0.009))
        st.prev_phase=Phase.OUR_KICKOFF
        _act_our_kickoff(ctx,ps,st)
        ctx=next_frame(ctx,ps,4.19,(0.31,0.046))
        _act_our_kickoff(ctx,ps,st)
        self.assertTrue(ps[0]._ko35_verified)
        self.assertFalse(ps[0].is_kicking)

    def test_pressure_short_disruption_only_with_near_opponent(self):
        ctx,ps,_=scene(ball=(-2,0),poses=((-2.35,0,0),(-6.5,0,0),(-1,2,0)),
                       opponents=((-1.8,.2,0),))
        ps[0].attack()
        self.assertEqual(ps[0].action,'attack:pressure_poke')
        self.assertEqual(ps[0].kick_command[1],PRESS_V36_POKE_POWER)
        ctx,ps,_=scene(ball=(-2,0),poses=((-2.35,0,0),(-6.5,0,0),(-1,2,0)))
        ps[0].attack()
        self.assertNotEqual(ps[0].action,'attack:pressure_poke')

    def test_pressure_poke_not_used_in_our_goal_mouth(self):
        ctx,ps,_=scene(ball=(-6.5,0),poses=((-6.85,0,0),(-6.5,0,0),(-1,2,0)),
                       opponents=((-6.3,.2,0),))
        ps[0].attack()
        self.assertNotEqual(ps[0].action,'attack:pressure_poke')

    def test_no_kick_when_referee_set(self):
        ctx,ps,st=scene(ball=(0,0),poses=((-0.6,0,0),(-6.57,0,0),(-1,2,0)),
                        game=GameControlState(state=GameState.SET))
        ps[0].kick_off_direct((7,1),0)
        self.assertFalse(ps[0].is_kicking)

if __name__=='__main__':unittest.main()
