"""V31 2026-10-28 feedback: tactical state regressions. Fake backend, no soccer physics."""
import math
import unittest
from test_scenarios import scene
from src.main import _act_normal, _act_our_kickoff, Phase
from src.param import *
from src.tactics import keeper_target


class V31VideoRegressions(unittest.TestCase):
    def test_consistent_robot1_kickoff_long_class(self):
        ctx, ps, st = scene(poses=((-0.35, .15, 0), (-6.5, 0, 0), (-.5, -1.9, 0)))
        st.prev_phase = Phase.READY
        _act_our_kickoff(ctx, ps, st)
        self.assertEqual(st.kickoff_taker, 1)
        self.assertEqual(ps[0].action, 'kickoff:direct_shoot')
        self.assertEqual(ps[0].kick_command[1], 10.0)
        self.assertLess(abs(ps[0].kick_command[0]), 0.2)
        self.assertEqual(ps[2].action, 'kickoff:rebound_ready')

    def test_kickoff_receiver_runs_forward_after_ball_moves(self):
        ctx, ps, st = scene(ball=(0.85, -0.9),
                            poses=((-0.3,0,0), (-6.5,0,0),(-.5,-1.9,0)),now=10)
        st.prev_phase=Phase.OUR_KICKOFF
        st.kickoff_taker=1
        st.kickoff_origin=(0.0,0.0)
        _act_our_kickoff(ctx,ps,st)
        self.assertEqual(ps[2].action,'kickoff:rebound_chase')
        self.assertGreater(ps[2].target[0],.85)
        self.assertFalse(ps[0].is_kicking)
        self.assertEqual(ps[0].action,'kickoff:shot_follow')
        self.assertGreater(st.kickoff_finished_until,ctx.now)

    def test_kickoff_forward_lock_survives_phase_switch(self):
        ctx,ps,st=scene(ball=(1.1,-1.0),poses=((0.1,0,0),(-6.5,0,0),(-0.4,-1.9,0)), now=10.2)
        st.kickoff_finished_until=12
        st.kickoff_receiver_id=3
        _act_normal(ctx,ps,st)
        self.assertEqual(ps[2].action,'kickoff:receiver_sprint')
        self.assertGreater(ps[2].target[0],1)

    def test_keeper_readies_side_for_incoming_shot(self):
        ctx,ps,_=scene(ball=(-4.9,-1.25),poses=((-2,0,0),(-6.28,0,0),(-1,2,0)))
        target,shot=keeper_target(ctx,(-1.7,0.47))
        self.assertTrue(shot)
        self.assertLess(target[1],0)
        ps[1].ball_velocity=(-1.7,0.47)
        ps[1].guard(allow_clear=False)
        self.assertTrue(ps[1].action.startswith('guard:'))
        self.assertLess(ps[1].target[1],0)
        self.assertLess(ps[1].target[0],-5.9)

    def test_keeper_does_not_chase_ball_behind_into_goal(self):
        ctx,ps,st=scene(ball=(-6.8,-.5),poses=((-3,0,0),(-6.4,-0.5,0),(1,2,0)))
        _act_normal(ctx,ps,st)
        self.assertFalse(ps[1].is_kicking)
        self.assertLessEqual(ps[1].target[0], -6.1)

    def test_keeper_caps_forward_claim_not_box_runout(self):
        ctx,ps,st=scene(ball=(-5.4,0),poses=((-2,0,0),(-6.5,0,0),(1,2,0)))
        _act_normal(ctx,ps,st)
        self.assertEqual(ps[1].action,'guard:claim_line')
        self.assertLessEqual(ps[1].target[0], -7+1.50+1e-5)

    def test_foot_hint_changes_with_body_side_no_fake_sdk_foot_arg(self):
        for y,foot in ((0.25,'left'),(-0.25,'right')):
            ctx,ps,_=scene(ball=(3,y),poses=((2.55,0,0),))
            ps[0].kick(0.0, 10.0)
            self.assertEqual(ps[0].foot_side_hint,foot)
            self.assertEqual(len(ps[0]._backend.commands[-1][1]),4)
            self.assertAlmostEqual(ps[0].kick_command[1],10)

    def test_near_ball_sidefoot_without_orbit(self):
        for y in (-.33,.33):
            ctx,ps,_=scene(ball=(3,0),poses=((2.65,y,0),))
            ps[0].attack()
            self.assertTrue(ps[0].is_kicking)
            self.assertNotEqual(ps[0].action,'attack:screen_orbit')

    def test_midfield_open_lane_shoots_hard(self):
        ctx,ps,_=scene(ball=(0.5,0),poses=((0.1,.15,0),(-6.5,0,0),(-1,-2,0)))
        ps[0].attack()
        self.assertEqual(ps[0].action,'attack:shoot')
        self.assertEqual(ps[0].kick_command[1],8)
        self.assertTrue(ps[0].kick_can_score(ps[0].kick_command[0]))

    def test_waiting_receiver_not_arbitrarily_sent_home(self):
        ctx,ps,_=scene(ball=(2,-1),poses=((1.4,-1,0),(-6.5,0,0),(3.5,-1,0)),now=5)
        receiver=ps[2]
        receiver.ball_velocity=(1.3,0)
        self.assertTrue(receiver.receive_pass((3.5,-1),6.3))
        self.assertIn(receiver.action,('receive:intercept','receive:hold'))
        self.assertTrue(receiver.target is not None)
        self.assertGreater(receiver.target[0],2)

if __name__=='__main__':
    unittest.main()
