"""V37 evidence-based regressions; tests command geometry, NOT physics outcomes."""
from __future__ import annotations
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.framework.types import GameControlState, GameState, SetPlay
from src.main import Phase, get_phase, _act_opp_set_play, _act_our_kickoff
from src.keeper_v33 import goalie_decision
from src.tactics import restart_retreat
from src.param import RESTART_V37_CLEARANCE_M

class V37RuleAndMatchReplay(unittest.TestCase):
    def test_opponent_throw_in_is_not_our_kickoff(self):
        g=GameControlState(state=GameState.PLAYING, set_play=SetPlay.THROW_IN,
                           kicking_team=2,secondary_time=8)
        ctx, ps, st=scene(ball=(-6.09,4.43),poses=((-5.91,4.7,0),(-6.57,0,0),(-5.6,3.9,0)),game=g)
        self.assertEqual(get_phase(ctx),Phase.OPP_SET_PLAY)
        st.prev_phase=Phase.OUR_KICKOFF
        _act_our_kickoff(ctx,ps,st)
        self.assertFalse(any(p.is_kicking for p in ps))
        self.assertEqual(ps[0].action,'kickoff:referee_not_ours_or_not_center')

    def test_restart_retreat_edge_ball_has_feasible_legal_point(self):
        ctx, ps, _=scene(ball=(-6.09,4.43))
        for wish in ((-6.1,4.45),(-6,3.9),(-5.7,4.2),(-6.4,4.3)):
            point=restart_retreat(ctx,wish,radius=RESTART_V37_CLEARANCE_M)
            self.assertIsNotNone(point)
            self.assertGreaterEqual(math.dist(point,(-6.09,4.43)),RESTART_V37_CLEARANCE_M-0.001)
            self.assertLessEqual(abs(point[0]),7-0.53+1e-6)
            self.assertLessEqual(abs(point[1]),4.5-0.53+1e-6)

    def test_restarter_avoids_touchline_and_restart_zone(self):
        g=GameControlState(state=GameState.PLAYING,set_play=SetPlay.THROW_IN,kicking_team=2,secondary_time=6)
        ctx,ps,st=scene(ball=(-6.09,4.43),poses=((-5.93,4.72,0),(-6.57,0,0),(-5.7,3.7,0)),game=g)
        _act_opp_set_play(ctx,ps,st)
        for p in ps:
            self.assertFalse(p.is_kicking)
            if p.target is not None:
                self.assertGreaterEqual(math.dist(p.target,(-6.09,4.43)),RESTART_V37_CLEARANCE_M-.001)
                self.assertLessEqual(abs(p.target[1]),4.5-0.20+1e-8)
        self.assertEqual(ps[0].action,'restart:evacuate_illegal')
        self.assertFalse(ps[0].can_leave_field())

    def test_opponent_kickoff_gated_by_owner(self):
        g=GameControlState(state=GameState.PLAYING,kicking_team=2,secondary_time=10)
        ctx,ps,st=scene(ball=(0,0),game=g)
        self.assertEqual(get_phase(ctx),Phase.OPP_KICKOFF)
        _act_our_kickoff(ctx,ps,st)
        self.assertFalse(ps[0].is_kicking)

    def test_real_our_kickoff_retains_power10(self):
        g=GameControlState(state=GameState.PLAYING,kicking_team=1,secondary_time=10)
        ctx,ps,st=scene(ball=(0,0),poses=((-0.5,0,0),(-6.57,0,0),(-1,-1.7,0)),game=g)
        st.prev_phase=Phase.READY
        self.assertEqual(get_phase(ctx),Phase.OUR_KICKOFF)
        _act_our_kickoff(ctx,ps,st)
        self.assertEqual(ps[0].action,'kickoff:direct_shoot')
        self.assertEqual(ps[0].kick_command[1],10)
        self.assertAlmostEqual(abs(st.kickoff_aim[1]),1.0)

    def test_midfield_incoming_ball_triggers_early_interception(self):
        ctx,ps,_=scene(ball=(-2.9139,0.3572),poses=((-2,1,0),(-6.57,0,0),(0,2,0)))
        dec=goalie_decision(ctx,(-1.0339,-0.236),())
        self.assertEqual(dec.action,'guard:early_cross')
        self.assertLess(dec.target[1],-0.25)
        self.assertLess(dec.target[0],-6.4)

    def test_keeper_turns_to_reach_goal_line_not_y_only(self):
        ctx,ps,_=scene(ball=(-2.9139,0.3572),poses=((-2,1,0),(-6.57,0,0),(0,2,0)))
        g=ps[1];g.ball_velocity=(-1.0339,-0.236)
        g.guard()
        self.assertEqual(g.action,'guard:early_cross')
        self.assertEqual(g.navigation,'keeper_v37_forward_gait')
        vx,vy,yaw=g.desired_velocity
        self.assertAlmostEqual(vy,0.0)
        self.assertLess(yaw,-0.5)

    def test_urgent_incoming_not_downgraded_to_early_cross(self):
        ctx,ps,_=scene(ball=(-5,0.8))
        dec=goalie_decision(ctx,(-3.5,-1.0),())
        self.assertEqual(dec.action,'guard:urgent_block')

    def test_near_ball_turned_goalie_does_not_kick_prematurely(self):
        ctx,ps,_=scene(ball=(-5.42,-0.28),poses=((-2,0,0),(-6.25,-0.04,0),(0,2,0)))
        g=ps[1];g.ball_velocity=(-.8,-.24)
        g.guard()
        self.assertNotEqual(g.action,'guard:clear_lease')
        self.assertFalse(g.is_kicking)

    def test_forward_goalline_drive_not_sidelong_nudge(self):
        ctx,ps,_=scene(ball=(1.1,2.0),poses=((0.63,2.0,0),(-6.57,0,0),(-1,-2,0)))
        d,power=ps[0].plan_kick()
        self.assertIn(ps[0].action,('attack:shoot','attack:goal_line_drive'))
        self.assertEqual(power,8.0)
        self.assertGreater(math.cos(d),0.85)
        self.assertEqual(ps[0].aim_target[0],7)

    def test_own_corners_do_not_allow_center_outside_touchline(self):
        g=GameControlState(state=GameState.PLAYING,set_play=SetPlay.CORNER_KICK,kicking_team=1)
        ctx,ps,_=scene(ball=(6.9,4.43),game=g)
        ps[0].restart_taker=True
        self.assertFalse(ps[0].can_leave_field())

if __name__=='__main__': unittest.main()
