"""真实策略函数 + 假底盘场景回归。SDK 动作和物理引擎不在测试范围。"""
import json
import math
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace, ModuleType
import unittest
from unittest.mock import patch

# 只替代入口导入依赖；不替代 Player、策略、规划和坐标变换实现。
try:
    import booster_agent_framework
except ImportError:
    sdk = ModuleType('booster_agent_framework')
    sdk.AgentBase = type('AgentBase', (), {})
    sdk.AgentFeatures = type('AgentFeatures', (), {})
    sys.modules['booster_agent_framework'] = sdk

from src.framework.config import SoccerConfig
from src.framework.types import *
from src.main import (SoccerSimAgent, Phase, _act_normal, _act_our_kickoff,
                      _act_opp_set_play, _act_our_set_play, _select_closest_attacker)
from src.player import Player
from src.tactics import update_ball_motion, intercept, keeper_target, lane_clearance


class Backend:
    mode = 'walk'
    fall_down_state = 'normal'
    _kicking = False

    def __init__(self):
        self.commands = []

    def kick(self, *args):
        self._kicking = True
        self.commands.append(('kick', args))

    def release_kick(self):
        self._kicking = False

    def set_velocity(self, *args):
        if not self._kicking:
            self.commands.append(('walk', args))

    def get_up(self):
        pass

    def request_mode(self, mode):
        pass


def scene(ball=(0, 0), poses=((-0.5, 0, 0), (-6.5, 0, 0), (-2, 2, 0)),
          opponents=(), now=1.0, game=None):
    ctx = Context(now=now, dt=1/30, team_id=1, field=ADULT_FIELD_DIMENSIONS,
                  ball=BallState(*ball, last_seen_at=now) if ball else None,
                  game=game or GameControlState(state=GameState.PLAYING),
                  teammates={i: RobotState(i, Pose2D(*p), last_seen_at=now) for i, p in enumerate(poses, 1)},
                  opponents={i: RobotState(i, Pose2D(*p), last_seen_at=now) for i, p in enumerate(opponents, 1)})
    players = [Player(i, SoccerConfig(), Backend()) for i in ctx.teammates]
    for p in players:
        p.context = ctx
    store = SimpleNamespace(cur_phase=Phase.NORMAL, prev_phase=Phase.NORMAL,
                            normal_attacker=None, kickoff_taker=None, ball_velocity=(0, 0))
    return ctx, players, store


class Scenarios(unittest.TestCase):
    def test_near_ball_kicks_without_retreat(self):
        ctx, ps, _ = scene()
        ps[0].attack()
        self.assertTrue(ps[0].is_kicking)
        self.assertEqual(ps[0]._backend.commands[-1][0], 'kick')

    def test_two_meters_does_not_start_manager(self):
        ctx, ps, _ = scene(poses=((-2, 0, 0),))
        ps[0].attack()
        self.assertFalse(ps[0].is_kicking)
        self.assertGreater(ps[0]._backend.commands[-1][1][0], 0)

    def test_kick_release_when_ball_escapes(self):
        ctx, ps, _ = scene()
        p = ps[0]
        p.attack()
        p.context = scene(ball=(3, 0))[0]
        p.attack()
        self.assertFalse(p._backend._kicking)
        self.assertEqual(p._backend.commands[-1][0], 'walk')

    def test_explicit_target_honored_and_body_transform(self):
        ctx, ps, _ = scene(poses=((-0.2, 0.4, math.pi/2),))
        p = ps[0]
        p.attack((1, -2), 1.2)
        direction, power, bx, by = p._backend.commands[-1][1]
        self.assertAlmostEqual(direction, math.atan2(-2, 1)-math.pi/2)
        self.assertAlmostEqual(power, 1.2)
        self.assertAlmostEqual(bx, -0.4)
        self.assertAlmostEqual(by, -0.2)

    def test_shot_reaims_every_tick_without_switching_power(self):
        ctx, ps, _ = scene(ball=(4, 0), poses=((3.5, 0, 0),))
        p = ps[0]
        p.attack()
        original = p.kick_command
        # v34 re-evaluates a power-shot target from live ball observations;
        # the unchanged ball should still produce the same command.
        p.attack()
        self.assertEqual(p.kick_command, original)

    def test_keeper_not_assigned_normal_chase(self):
        ctx, ps, st = scene(ball=(-5, 0))
        _act_normal(ctx, ps, st)
        self.assertNotEqual(st.normal_attacker, 2)
        self.assertTrue(ps[1].action.startswith('guard:'))
        self.assertLessEqual(sum(p.is_kicking for p in ps), 1)

    def test_keeper_safe_clear_has_single_owner(self):
        ctx, ps, st = scene(ball=(-6, 0), poses=((-2, 0, 0), (-6.5, 0, 0), (-1, 2, 0)))
        _act_normal(ctx, ps, st)
        self.assertNotEqual(st.normal_attacker, 2)
        self.assertEqual(ps[1].action, 'guard:emergency_clear')
        self.assertEqual(sum(p.is_kicking for p in ps), 1)
        self.assertGreater(math.cos(ps[1].kick_command[0]), 0)

    def test_outfield_recovers_when_ball_in_own_half(self):
        ctx, ps, st = scene(ball=(-2, 1), poses=((-2.5, 1, 0), (-6.5, 0, 0), (1, 2, 0)))
        _act_normal(ctx, ps, st)
        self.assertEqual(ps[2].action, 'press:chase')
        self.assertLess(math.dist(ps[2].target, (ctx.ball.x, ctx.ball.y)), 0.8)
        self.assertFalse(ps[2].is_kicking)

    def test_attacker_hysteresis_and_genuine_handoff(self):
        ctx, ps, _ = scene(poses=((-1, 0, 0), (-6.5, 0, 0), (-1.1, 0, 0)))
        self.assertEqual(_select_closest_attacker(ctx, [ps[0], ps[2]], 3).id, 3)
        ctx, ps, _ = scene(poses=((-0.5, 0, 0), (-6.5, 0, 0), (-4, 0, 0)))
        self.assertEqual(_select_closest_attacker(ctx, [ps[0], ps[2]], 3).id, 1)

    def test_kickoff_direct_corner_power10_and_receiver(self):
        ctx, ps, st = scene(poses=((-0.2083, .4545, 0), (-6.5,0,0), (-2,2,0)))
        st.prev_phase = Phase.READY
        _act_our_kickoff(ctx, ps, st)
        # Distant/sideways kickoff taker gets one straight approach, not orbit.
        self.assertEqual(ps[0].action, 'kickoff:direct_approach')
        self.assertFalse(ps[0].is_kicking)
        self.assertLess(ps[2].target[1], -1)

    def test_kickoff_moved_stops_repeated_kicks_and_follows(self):
        ctx, ps, st = scene(ball=(0.4, -1))
        st.prev_phase = Phase.OUR_KICKOFF
        st.kickoff_taker = 1
        st.kickoff_origin = (0, 0)
        _act_our_kickoff(ctx, ps, st)
        self.assertEqual(ps[0].action, 'kickoff:shot_follow')
        self.assertFalse(ps[0].is_kicking)
        self.assertGreater(ps[0].target[0], -2)
        self.assertLess(ps[2].target[1], 0)

    def test_kickoff_to_normal_retains_taker_when_competitive(self):
        ctx, ps, st = scene()
        st.prev_phase, st.kickoff_taker = Phase.OUR_KICKOFF, 1
        _act_normal(ctx, ps, st)
        self.assertEqual(st.normal_attacker, 1)
        self.assertFalse(ps[0].action.startswith('guard:'))

    def test_goal_target_within_posts_and_avoids_center_defender(self):
        ctx, ps, _ = scene(ball=(4, 0), poses=((3.5, 0, 0),), opponents=((6.8, 0, 0),))
        direction, power = ps[0].plan_kick()
        y = ctx.ball.y + math.tan(direction) * (7 - ctx.ball.x)
        self.assertGreater(abs(y), 0.4)
        self.assertLess(abs(y), 1.3)
        self.assertEqual(power, 8.0)  # V34: 半场射门改为大力档8

    def test_blocked_shot_chooses_clear_forward_pass(self):
        ctx, ps, _ = scene(ball=(2, 0), poses=((1.5, 0, 0), (-6.5, 0, 0), (4, 2, 0)),
                           opponents=((3, 0, 0),))
        direction, power = ps[0].plan_kick()
        self.assertEqual(ps[0].action, 'attack:pass')
        self.assertAlmostEqual(direction, math.pi/4)
        self.assertEqual(power, 4.0)  # V25 长传档 4，非射门不得强制 10

    def test_receiver_excluded_but_other_teammate_blocks(self):
        ctx, ps, _ = scene(poses=((-0.5, 0, 0), (1, 0, 0), (3, 0, 0)))
        self.assertLess(lane_clearance(ctx, (3, 0), 1, 3), 0.1)

    def test_short_advance_stays_forward(self):
        for ball in ((-5, 2), (0, -3), (6, 3)):
            ctx, ps, _ = scene(ball=ball, poses=((ball[0]-.5, ball[1], 0),))
            direction, power = ps[0].plan_kick()
            self.assertGreater(math.cos(direction), 0)
            self.assertGreaterEqual(power, 1)

    def test_keeper_predicts_crossing(self):
        ctx, ps, _ = scene(ball=(-4.5, 0.8))
        target, shot = keeper_target(ctx, (-3, -0.6))
        self.assertTrue(shot)
        # V31 门将站得稍前；投射交点随着封堵线 x 改变。
        self.assertAlmostEqual(target[1], 0.444, places=3)
        ps[1].ball_velocity = (-3, -0.6)
        ps[1].guard()
        self.assertEqual(ps[1].action, 'guard:urgent_block')
        self.assertFalse(ps[1].is_kicking)

    def test_keeper_sidestep_has_no_turn_only_pause(self):
        ctx, ps, _ = scene(ball=(-4.5, 1.2), poses=((-2, 0, 0), (-6.5, -1, 0), (-1, 3, 0)))
        ps[1].ball_velocity = (-3, 0)
        ps[1].guard()
        vx, vy, yaw = ps[1]._backend.commands[-1][1]
        # V36 lateral vy command failed to yield physical side motion.
        # V37 must turn to the interception point, then move with forward vx.
        self.assertAlmostEqual(vy, 0.0)
        self.assertGreater(abs(yaw), 0.25)
        self.assertLessEqual(abs(yaw), 2.4+1e-7)

    def test_motion_and_prediction_go_to_future_ball(self):
        ctx, ps, st = scene(ball=(0, 0), poses=((-2, 0, 0),), now=1)
        update_ball_motion(ctx, st)
        ctx2 = scene(ball=(-0.3, 0.1), now=1.1)[0]
        update_ball_motion(ctx2, st)
        self.assertLess(st.ball_velocity[0], -2)
        target, eta = intercept(ctx2, ps[0].pose, st.ball_velocity)
        self.assertLess(target[0], ctx2.ball.x)

    def test_motion_resets_on_teleport_loss_and_clock_reset(self):
        ctx, ps, st = scene(now=1)
        update_ball_motion(ctx, st)
        update_ball_motion(scene(ball=(6, 0), now=1.03)[0], st)
        self.assertEqual(st.ball_velocity, (0, 0))
        update_ball_motion(scene(now=.5)[0], st)
        self.assertEqual(st.ball_velocity, (0, 0))
        update_ball_motion(scene(ball=None, now=.6)[0], st)
        self.assertIsNone(st.ball_sample)

    def test_opponent_restart_does_not_attack(self):
        ctx, ps, st = scene(ball=(1, 1),game=GameControlState(state=GameState.PLAYING, set_play=SetPlay.THROW_IN, kicking_team=2))
        _act_opp_set_play(ctx, ps, st)
        self.assertFalse(any(p.is_kicking for p in ps))
        for p in (ps[0], ps[2]):
            self.assertGreaterEqual(math.dist(p.target, (1, 1)), 1.65)

    def test_indirect_restart_does_not_shoot_direct(self):
        game = GameControlState(state=GameState.PLAYING, set_play=SetPlay.INDIRECT_FREE_KICK, kicking_team=1)
        ctx, ps, st = scene(ball=(4, 0), poses=((3.7764, -.4472, 0), (-6.5, 0, 0), (5, 2, 0)), game=game)
        st.prev_phase = Phase.NORMAL
        _act_our_set_play(ctx, ps, st)
        self.assertAlmostEqual(ps[0].kick_command[0], math.atan2(2, 1))
        self.assertLess(ps[0].kick_command[1], 2)

    def test_missing_ball_and_single_player_safe(self):
        ctx, ps, st = scene(ball=None)
        _act_normal(ctx, ps, st)
        self.assertFalse(any(p.is_kicking for p in ps))
        ctx, ps, st = scene(poses=((-0.5, 0, 0),))
        _act_normal(ctx, ps, st)
        self.assertTrue(ps[0].is_kicking)

    def test_500_seeded_random_scenarios(self):
        import random
        rng = random.Random(19)
        for _ in range(500):
            ball = (rng.uniform(-6.7, 6.7), rng.uniform(-4.1, 4.1))
            poses = tuple((rng.uniform(-6.7, 6.7), rng.uniform(-4.1, 4.1),
                           rng.uniform(-math.pi, math.pi)) for _ in range(3))
            opponents = tuple((rng.uniform(-6.7, 6.7), rng.uniform(-4.1, 4.1), 0) for _ in range(3))
            ctx, ps, st = scene(ball=ball, poses=poses, opponents=opponents)
            for p in ps:
                p.ball_velocity = (rng.uniform(-4, 4), rng.uniform(-2, 2))
            _act_normal(ctx, ps, st)
            self.assertLessEqual(sum(p.is_kicking for p in ps), 1)
            for p in ps:
                for kind, args in p._backend.commands:
                    self.assertTrue(all(math.isfinite(a) for a in args))
                    if kind == 'kick':
                        self.assertTrue(1 <= args[1] <= 10)
                        if ball[0] < 0:
                            self.assertGreater(math.cos(args[0] + p.pose.theta), 0)
            target, _ = keeper_target(ctx, ps[1].ball_velocity)
            self.assertLessEqual(abs(target[1]), 1.1)

    def test_full_entry_writes_parseable_telemetry(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, WH_LOG_DIR=folder):
            ctx, ps, st = scene()
            SoccerSimAgent.play(ctx, ps, st)
            paths = list(Path(folder).glob('*.jsonl'))
            self.assertEqual(len(paths), 1)
            entry = json.loads(paths[0].read_text())
            self.assertEqual(entry['version'], 'V37-referee-first-preemptive-keeper')
            self.assertIsNone(entry['robots'][0]['velocity_command_body'])
            self.assertIsNone(entry['robots'][0]['observed_velocity_world'])
            for handler in st.telemetry_logger.handlers:
                handler.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
