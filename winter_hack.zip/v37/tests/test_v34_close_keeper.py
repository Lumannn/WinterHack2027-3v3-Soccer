"""V34 new requirements: near ball shot, dynamic aim, opponent wind-up block, legal field."""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.player import Player
from src.keeper_v33 import goalie_decision
from src.main import _select_closest_attacker
from src.param import SHOT_POWER, SHOT_NEAR_BALL_ENTER_M, SHOT_STABLE_HEADING_RAD
from src.framework.types import Pose2D, RobotState, Penalty


class V34CloseKeeper(unittest.TestCase):
    def test_close_shot_uses_eight_and_manager(self):
        ctx, ps, _ = scene(ball=(4,0), poses=((3.57,0,0),))
        ps[0].attack()
        self.assertEqual(ps[0].action,'attack:shoot')
        self.assertTrue(ps[0].is_kicking)
        self.assertEqual(ps[0].kick_command[1],8)
    def test_far_from_ball_never_starts_shooting_manager(self):
        ctx, ps, _ = scene(ball=(4,0), poses=((3.35,0,0),))
        ps[0].attack()
        self.assertFalse(ps[0].is_kicking)
        self.assertGreater(ps[0].desired_velocity[0],0)
    def test_shot_with_large_body_error_aligns_first(self):
        ctx, ps, _ = scene(ball=(4,0), poses=((3.6,0,0.8),))
        ps[0].attack()
        self.assertEqual(ps[0].action,'attack:shot_align')
        self.assertFalse(ps[0].is_kicking)
        self.assertEqual(ps[0].desired_velocity[:2],(0,0))
        self.assertLessEqual(abs(ps[0].desired_velocity[2]),1.6)
    def test_ball_behind_body_never_triggers_hard_shot(self):
        ctx, ps, _ = scene(ball=(4,0), poses=((4.15,0,0),))
        ps[0].attack()
        self.assertFalse(ps[0].is_kicking)
    def test_attacking_half_power_is_eight_and_kickoff_ten(self):
        ctx,ps,_=scene(ball=(3,0), poses=((2.5,0,0),))
        self.assertEqual(ps[0].plan_kick()[1],SHOT_POWER)
        from src.param import KICKOFF_SHOOT_POWER
        self.assertEqual(KICKOFF_SHOOT_POWER,10)
    def test_opponent_about_to_shoot_keeps_goalie_home(self):
        ctx,ps,_=scene(ball=(-4.2,0.2),poses=((-2,0,0),(-6.57,0,0),(0,1,0)),
                       opponents=((-4.25,0.2,0),))
        decision=goalie_decision(ctx,(0,0),tuple())
        self.assertEqual(decision.action,'guard:opp_winding_up')
        self.assertAlmostEqual(decision.target[0],-6.57)
    def test_wide_opponent_not_lure_keeper(self):
        ctx,ps,_=scene(ball=(-4.8,3.2),opponents=((-4.8,3.2,0),))
        dec=goalie_decision(ctx,(0,0),tuple())
        self.assertNotEqual(dec.action,'guard:opp_winding_up')
    def test_regular_play_keeps_robots_inside_touchline(self):
        ctx,ps,_=scene()
        self.assertFalse(ps[0].can_leave_field())
        self.assertLessEqual(ps[0].walk_point((200,100))[1],ctx.field.width/2)
    def test_fallen_player_releases_sdk_before_get_up(self):
        ctx,ps,_=scene()
        p=ps[0]
        p.attack()
        p._backend.fall_down_state='fallen'
        self.assertFalse(p.ensure_ready())
        self.assertFalse(p._backend._kicking)
    def test_attacker_only_field_robots(self):
        ctx,ps,_=scene(ball=(1,0),poses=((0,0,0),(-6,0,0),(0.5,0,0)))
        attacker=_select_closest_attacker(ctx,[ps[0],ps[2]])
        self.assertEqual(attacker.id,3)

if __name__=='__main__':unittest.main()
