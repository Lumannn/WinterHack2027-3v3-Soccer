"""针对场边罚站、开球越位和无进展退出的回归，仍不模拟 SDK 物理。"""
from dataclasses import replace
import math
import unittest
from unittest.mock import patch

from test_scenarios import scene, Phase, SoccerSimAgent
from src.framework.types import GameControlState, GameState, SetPlay, PlayerState, Penalty, TeamState
from src.main import (_act_our_kickoff, _act_our_set_play, _act_ready,
                      _act_opp_set_play, get_phase)
from src.param import KICK_SHORT, KICK_LONG, KICK_HARD, SHOT_POWER
from src.tactics import legal_walk_point, update_zone


def advance(ctx, ps, seconds, ball=None):
    ctx = replace(ctx, now=ctx.now+seconds,
                  ball=replace(ctx.ball, last_seen_at=ctx.now+seconds,
                               x=ball[0] if ball else ctx.ball.x, y=ball[1] if ball else ctx.ball.y))
    for p in ps:
        p.context = ctx
    return ctx


class RulesAndRecovery(unittest.TestCase):
    def test_stopped_overrides_ready_and_playing(self):
        for state in (GameState.READY, GameState.PLAYING, GameState.SET):
            ctx, _, _ = scene(game=GameControlState(state=state, stopped=True))
            self.assertEqual(get_phase(ctx), Phase.STOPPED)

    def test_penalized_players_only_receive_zero_velocity(self):
        penalty = PlayerState(penalty=Penalty.ILLEGAL_POSITIONING, secs_till_unpenalised=27)
        team = TeamState(team_number=1, players=(penalty, penalty, penalty))
        game = GameControlState(state=GameState.PLAYING, teams=(team, TeamState(team_number=2)))
        ctx, ps, st = scene(game=game)
        with patch('src.main.record_frame'):
            SoccerSimAgent.play(ctx, ps, st)
        for p in ps:
            self.assertIn('ILLEGAL_POSITIONING:27s', p.action)
            self.assertFalse(p.is_kicking)
            self.assertEqual(p._backend.commands, [('walk', (0, 0, 0))])

    def test_unpenalized_player_can_rejoin(self):
        ctx, ps, st = scene()
        with patch('src.main.record_frame'):
            SoccerSimAgent.play(ctx, ps, st)
        self.assertTrue(ps[0].is_kicking)
        self.assertNotIn('penalized', ps[0].action)

    def test_both_teams_stopped_by_referee_are_not_forced_to_move(self):
        ctx, ps, st = scene(game=GameControlState(state=GameState.PLAYING, stopped=True))
        with patch('src.main.record_frame'):
            SoccerSimAgent.play(ctx, ps, st)
        self.assertTrue(all(p.action == 'stopped' for p in ps))
        self.assertTrue(all(p.desired_velocity == (0, 0, 0) for p in ps))

    def test_kickoff_receiver_remains_legal_before_ball_free(self):
        game = GameControlState(state=GameState.PLAYING, secondary_time=9, kicking_team=1)
        ctx, ps, st = scene(game=game)
        st.prev_phase = Phase.READY
        _act_our_kickoff(ctx, ps, st)
        target = ps[2].target
        self.assertLess(target[0], 0)
        self.assertLess(target[1], -1)
        self.assertTrue(target[0] <= 0 or math.hypot(*target) <= 1.5)

    def test_kickoff_walk_path_cannot_cut_through_illegal_half(self):
        game = GameControlState(state=GameState.PLAYING, secondary_time=8, kicking_team=1)
        ctx, ps, _ = scene(poses=((-0.25, -2.8, 0),), game=game)
        p = ps[0]
        p.walk_to((2, -2.8), avoid_robots=True)
        self.assertLess(p.target[0], 0)
        vx, vy, _ = p.desired_velocity
        self.assertLessEqual(p.pose.x + vx * 0.3, 0)

    def test_opponent_kickoff_avoids_circle_and_their_half(self):
        game = GameControlState(state=GameState.PLAYING, secondary_time=8, kicking_team=2)
        ctx, _, _ = scene(game=game)
        for target in ((2, 2), (0, 0), (-0.2, 0), (1, -0.5)):
            safe = legal_walk_point(ctx, target)
            self.assertLess(safe[0], 0)
            self.assertGreaterEqual(math.hypot(*safe), 1.5)

    def test_boundary_velocity_stays_in_outside_band(self):
        for x, y, direction in ((0, 4.25, math.pi/2), (0, -4.25, -math.pi/2),
                                 (6.75, 2, 0), (-6.75, 2, math.pi)):
            ctx, ps, _ = scene(poses=((x, y, direction),))
            p = ps[0]
            p.set_velocity(2, 0, 0)
            vx, vy, _ = p.desired_velocity
            wx = math.cos(direction)*vx - math.sin(direction)*vy
            wy = math.sin(direction)*vx + math.cos(direction)*vy
            self.assertLessEqual(abs(x + wx * 0.3), 7.8+1e-8)
            self.assertLessEqual(abs(y + wy * 0.3), 5.3+1e-8)

    def test_local_heading_can_cross_line_within_outside_band(self):
        ctx, ps, _ = scene(poses=((0, 4.25, 0),))
        p = ps[0]
        heading = p._plan_heading(p.pose, math.pi/2, [])
        self.assertLessEqual(p.pose.y + math.sin(heading)*0.45, 5.3+1e-8)

    def test_ball_on_all_four_edges_approaches_within_outer_band(self):
        for ball in ((0, 4.45), (0, -4.45), (6.95, 3), (-6.95, 3)):
            ctx, ps, _ = scene(ball=ball, poses=((ball[0]*0.7, ball[1]*0.7, 0),))
            ps[0].attack()
            if ps[0].target:
                self.assertLessEqual(abs(ps[0].target[0]), 7.8)
                self.assertLessEqual(abs(ps[0].target[1]), 5.3)

    def test_frozen_kick_manager_is_released_and_retried(self):
        ctx, ps, _ = scene()
        p = ps[0]
        p.attack()
        self.assertTrue(p.is_kicking)
        ctx = advance(ctx, ps, 3.1)
        p.attack()
        self.assertEqual(p.action, 'attack:unstick')
        self.assertFalse(p.is_kicking)
        self.assertFalse(p._backend._kicking)
        self.assertEqual(p._backend.commands[-1][0], 'walk')
        advance(ctx, ps, 0.8)
        p.attack()
        self.assertTrue(p.is_kicking)

    def test_moving_ball_is_not_mistaken_for_frozen_kick(self):
        ctx, ps, _ = scene()
        p = ps[0]
        p.attack()
        advance(ctx, ps, 2.0, ball=(0.2, 0))
        p.attack()
        self.assertNotEqual(p.action, 'attack:unstick')
        self.assertFalse(p.is_kicking)  # ball moved outside close-shot SDK window

    def test_navigation_stall_stops_turn_only_loop(self):
        ctx, ps, _ = scene(poses=((0, 0, math.pi),))
        p = ps[0]
        p.walk_to((3, 0), avoid_robots=True)
        self.assertEqual(p.desired_velocity[:2], (0, 0))
        advance(ctx, ps, 1.6)
        p.walk_to((3, 0), avoid_robots=True)
        self.assertIn('retry', p.navigation)
        self.assertEqual(p.desired_velocity[:2], (0, 0))
        self.assertNotEqual(p.desired_velocity[2], 0)  # 不再靠倒走强行脱困
        from src.framework.types import Pose2D
        p.context = replace(p.context, teammates={1: replace(p.context.teammates[1], pose=Pose2D(0, 0, 0))})
        p.walk_to((3, 0), avoid_robots=True)
        self.assertGreater(p.desired_velocity[0], 0)

    def test_global_plan_is_cached_for_realtime_loop(self):
        ctx, ps, _ = scene(poses=((0, 0, 0),), opponents=((0.8, 0, 0),))
        p = ps[0]
        with patch('src.player.plan_global_path', return_value=[(0,0),(0,1),(3,0)]) as planner:
            p.walk_to((3, 0), avoid_robots=True)
            advance(ctx, ps, .1)
            p.walk_to((3, 0), avoid_robots=True)
            self.assertEqual(planner.call_count, 1)

    def test_restart_small_displacement_cannot_lock_follow_forever(self):
        game = GameControlState(state=GameState.PLAYING, set_play=SetPlay.THROW_IN, kicking_team=1)
        ctx, ps, st = scene(game=game)
        st.prev_phase = Phase.NORMAL
        _act_our_set_play(ctx, ps, st)
        st.prev_phase = Phase.OUR_SET_PLAY
        ctx = advance(ctx, ps, .1, ball=(.2, 0))
        _act_our_set_play(ctx, ps, st)
        self.assertEqual(ps[0].action, 'restart:follow')
        advance(ctx, ps, .8)
        _act_our_set_play(ps[0].context, ps, st)
        self.assertNotEqual(ps[0].action, 'restart:follow')
        self.assertGreater(sum(abs(v) for v in ps[0].desired_velocity), 0)  # 0.7m超出新的0.65m接管距离，先直接接近

    def test_corner_taker_avoids_becoming_outside_penalty(self):
        # V36 allowed the robot to run beyond x=7 or y=4.5 for a corner.
        # V37 intentionally gives up such a route when necessary for legality.
        game=GameControlState(state=GameState.PLAYING, set_play=SetPlay.CORNER_KICK, kicking_team=1)
        ctx, ps, st=scene(ball=(6.9,4.4), poses=((6.4,4.0,0),(-6,0,0),(4,1,0)),game=game)
        st.prev_phase=Phase.NORMAL
        _act_our_set_play(ctx,ps,st)
        self.assertTrue(ps[0].restart_taker)
        self.assertFalse(ps[0].can_leave_field())
        # May choose not to kick if physically impossible without going outside.
        for p in ps:
            if p.target is not None:
                self.assertLessEqual(abs(p.target[1]),4.5-.22+1e-9)
                self.assertLessEqual(abs(p.target[0]),7-.22+1e-9)

    def test_kick_power_selects_three_discrete_actions(self):
        near, ps, _ = scene(ball=(5, 0), poses=((4.5, 0, 0),))
        self.assertEqual(ps[0].plan_kick()[1], SHOT_POWER)
        far, ps, _ = scene(ball=(2, 0), poses=((1.5, 0, 0),))
        self.assertEqual(ps[0].plan_kick()[1], SHOT_POWER)
        middle, ps, _ = scene(ball=(0, 0), poses=((-0.5, 0, 0),))
        # V31 开放中场无阻挡远射；有效直射使用 power=10。
        self.assertEqual(ps[0].plan_kick()[1], SHOT_POWER)

    def test_ready_replacement_keeper_is_not_assigned_striker_slot(self):
        ctx, ps, _ = scene(poses=((-1, 0, 0), (-6.5, 0, 0), (-2, 2, 0)))
        active = [ps[0], ps[2]]
        _act_ready(ctx, active)
        # robot2 不可用，最靠己方门的 robot3 替补守门。
        self.assertEqual(ps[2].action, 'ready:keeper')
        self.assertLess(ps[2].target[0], -5)

    def test_zone_hysteresis(self):
        ctx, _, st = scene(ball=(-2.6, 0))
        self.assertEqual(update_zone(ctx, st), 'danger')
        self.assertEqual(update_zone(replace(ctx, ball=replace(ctx.ball, x=-2.4)), st), 'danger')
        self.assertEqual(update_zone(replace(ctx, ball=replace(ctx.ball, x=-2.0)), st), 'middle')

    def test_goal_line_direction_remains_forward(self):
        ctx, ps, _ = scene(ball=(7.01, 0), poses=((6.5, 0, 0),))
        direction, _ = ps[0].plan_kick()
        self.assertGreater(math.cos(direction), 0)

    def test_opponent_restart_guard_also_respects_avoidance_radius(self):
        game = GameControlState(state=GameState.PLAYING, set_play=SetPlay.CORNER_KICK, kicking_team=2)
        ctx, ps, st = scene(ball=(-6.5, 0), game=game)
        _act_opp_set_play(ctx, ps, st)
        for p in ps:
            self.assertFalse(p.is_kicking)
            self.assertGreaterEqual(math.dist(p.target, (-6.5, 0)), 1.65)

    def test_optimized_agent_id_is_independent(self):
        import tomllib
        from pathlib import Path
        root = Path(__file__).resolve().parents[1]
        metadata = tomllib.loads((root / 'agent.toml').read_text())
        self.assertNotIn(metadata['id'], {'com.example.lqinternalmatch', 'com.winterhack.red.goalline.v18'})
        self.assertEqual(metadata['entry'], 'src/main.py:SoccerSimAgent')

    def test_activation_still_starts_original_runtime(self):
        from types import SimpleNamespace
        called = []
        agent = SoccerSimAgent.__new__(SoccerSimAgent)
        agent.runtime = SimpleNamespace(start=lambda: called.append('started'))
        with self.assertLogs('src.main', level='INFO') as logs:
            agent.on_agent_activated()
        self.assertEqual(called, ['started'])
        self.assertTrue(any('com.winterhack.red.simple.v37' in msg for msg in logs.output))

    def test_sdk_is_not_cancelled_merely_for_crossing_line(self):
        ctx, ps, _ = scene(ball=(0, 4.45), poses=((0, 4.4, 0),))
        p = ps[0]
        p.kick(0, 1.5)
        self.assertTrue(p._backend._kicking)
        p.attack()
        self.assertFalse(p._backend._kicking)
        self.assertNotEqual(p.action, 'attack:edge_recover')

    def test_search_timeout_returns_to_local_motion(self):
        from src.utils.path_planner import plan_global_path
        ctx, ps, _ = scene(poses=((0, 0, 0),), opponents=((.8, 0, 0),))
        with patch('src.utils.path_planner.time.perf_counter', side_effect=[0.0, 1.0]):
            self.assertIsNone(plan_global_path(ctx, (0,0), (3,0), []))
        with patch('src.player.plan_global_path', return_value=None):
            ps[0].walk_to((3,0), avoid_robots=True, omni=True)
        self.assertEqual(ps[0].navigation, 'local')
        self.assertGreater(sum(abs(v) for v in ps[0].desired_velocity), 0)
        self.assertGreaterEqual(ps[0].desired_velocity[0], 0)

    def test_penalty_diagnostics_include_opponent(self):
        from src.telemetry import record_frame
        from pathlib import Path
        import tempfile, os, json
        penalty = PlayerState(penalty=Penalty.LEAVING_THE_FIELD, secs_till_unpenalised=19)
        game = GameControlState(state=GameState.PLAYING,
                                teams=(TeamState(team_number=1), TeamState(team_number=2, players=(penalty,))))
        ctx, ps, st = scene(game=game, opponents=((3, 1, 0),))
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, WH_LOG_DIR=folder):
            record_frame(ctx, ps, st)
            data = json.loads(next(Path(folder).glob('*.jsonl')).read_text())
            self.assertEqual(data['opponents'][0]['penalty'], 'LEAVING_THE_FIELD')
            self.assertEqual(data['opponents'][0]['penalty_seconds'], 19)
            self.assertEqual(data['robots'][0]['mode'], 'walk')
            for handler in st.telemetry_logger.handlers:
                handler.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
