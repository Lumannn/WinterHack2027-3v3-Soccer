import math
import unittest
from dataclasses import replace
from unittest.mock import patch
from test_scenarios import scene
from src.framework.types import GameControlState, GameState, SetPlay, Pose2D
from src.main import _act_normal, SoccerSimAgent
from src.param import CLEAR_POWER, ORBIT_BALL_KEEP_M


class CenterCompact(unittest.TestCase):
    def test_clearance_aims_center_before_flanks(self):
        ctx, ps, st = scene(ball=(-5, 2), poses=((-5.5, 2, 0),))
        self.assertEqual(ps[0].clearance_target(), (-2.1, 0.0))

    def test_advance_pulls_ball_toward_center(self):
        ctx, ps, st = scene(ball=(0, 3), poses=((-0.5, 3, 0),))
        ps[0].plan_kick()
        self.assertLess(abs(ps[0].aim_target[1]), 3)
        self.assertGreater(ps[0].aim_target[0], 0)

    def test_orbit_prefers_opponent_ball_line(self):
        for y in (-1.5, 1.5):
            ctx, ps, st = scene(ball=(0, 0), poses=((.7, 0, 0),), opponents=((0, y, 0),))
            target = ps[0].orbit_waypoint(0)
            self.assertGreater(target[1] * y, 0)

    def test_orbit_does_not_choose_screening_route_into_opponent(self):
        ctx, ps, st = scene(ball=(0, 0), poses=((.7, 0, 0),), opponents=((0, .6, 0),))
        self.assertLess(ps[0].orbit_waypoint(0)[1], 0)

    def test_command_integrated_orbit_keeps_ball_clearance(self):
        ctx, ps, st = scene(ball=(0, 0), poses=((.7, 0, 0),))
        p = ps[0]
        min_radius = math.inf
        # Kinematic integration checks our walk commands, not foot/ball physics.
        for i in range(500):
            p.attack((3, 0), 3)
            if p.is_kicking:
                break
            vx, vy, yaw = p.desired_velocity
            pose = p.pose
            dt = 1/30
            x = pose.x + (math.cos(pose.theta)*vx - math.sin(pose.theta)*vy)*dt
            y = pose.y + (math.sin(pose.theta)*vx + math.cos(pose.theta)*vy)*dt
            min_radius = min(min_radius, math.hypot(x, y))
            robot = replace(p.context.teammates[1], pose=Pose2D(x, y, pose.theta+yaw*dt))
            p.context = replace(p.context, now=p.context.now+dt, teammates={1: robot})
        self.assertTrue(p.is_kicking)
        self.assertGreaterEqual(min_radius, ORBIT_BALL_KEEP_M)
        self.assertLess(i, 200)

    def test_normal_touchline_ball_does_not_force_retreat(self):
        ctx, ps, st = scene(ball=(0, 4.45), poses=((-0.5, 4.6, 0),))
        ps[0].attack((2, 1), 3)
        self.assertNotEqual(ps[0].action, 'attack:edge_recover')
        self.assertFalse(ps[0].can_leave_field())

    def test_normal_outside_band_is_bounded(self):
        ctx, ps, st = scene()
        self.assertEqual(ps[0].walk_point((99, 99)), (6.78, 4.28))

    def test_kickoff_non_taker_cannot_cross_even_inside_circle(self):
        ctx, ps, st = scene(game=GameControlState(state=GameState.PLAYING, secondary_time=8, kicking_team=1))
        self.assertLess(ps[2].walk_point((.3, 0))[0], 0)
        ps[0].kickoff_taker = True
        self.assertGreater(ps[0].walk_point((.3, 0))[0], 0)

    def test_far_attack_chase_uses_speed_cap(self):
        ctx, ps, st = scene(ball=(3, 0), poses=((0, 0, 0),))
        ps[0].attack((7, 0), 10)
        self.assertAlmostEqual(ps[0].desired_velocity[0], 2)

    def test_fast_reachable_ball_is_emergency_clear_not_retreat(self):
        ctx, ps, st = scene(ball=(-6, .4), poses=((-1, 0, 0), (-6.4, 0, 0), (0, 2, 0)))
        ps[1].ball_velocity = (-6, 0)
        _act_normal(ctx, ps, st)
        p = ps[1]
        self.assertEqual(p.action, 'guard:emergency_clear')
        self.assertNotEqual(st.normal_attacker, 2)
        self.assertIsNone(p.desired_velocity)
        self.assertEqual(p.aim_target[1], 0)
        self.assertEqual(p.kick_command[1], 8.0)
        self.assertEqual(sum(p.is_kicking for p in ps), 1)

    def test_emergency_does_not_wait_for_behind_ball_or_clear_lane(self):
        ctx, ps, st = scene(ball=(-6.2, .2), poses=((-6.5, .2, 0), (-6, .2, 0), (0, 2, 0)),
                            opponents=((-5, .1, 0),))
        _act_normal(ctx, ps, st)
        # 球已到守门员身后，不能假装 SDK 能从背后踢出。
        self.assertEqual(ps[1].action, 'guard:mouth_rescue')
        self.assertFalse(ps[1].is_kicking)

    def test_emergency_still_respects_referee_restarts_and_stops(self):
        for game in (GameControlState(state=GameState.PLAYING, stopped=True),
                     GameControlState(state=GameState.PLAYING, set_play=SetPlay.DIRECT_FREE_KICK, kicking_team=2),
                     GameControlState(state=GameState.SET)):
            ctx, ps, st = scene(ball=(-6, .4), poses=((-1, 0, 0), (-6.4, 0, 0), (0, 2, 0)), game=game)
            self.assertFalse(ps[1].emergency_clear_ready())
            with patch('src.main.record_frame'):
                SoccerSimAgent.play(ctx, ps, st)
            self.assertFalse(ps[1].is_kicking)

    def test_ball_just_outside_reach_keeper_holds_line(self):
        ctx, ps, st = scene(ball=(-5, 0), poses=((-1, 0, 0), (-6, 0, 0), (0, 2, 0)))
        ps[1].ball_velocity = (-4, 0)
        ps[1].guard(allow_clear=False)
        self.assertEqual(ps[1].action, 'guard:urgent_block')
        self.assertLessEqual(ps[1].target[0], -6.0)


if __name__ == '__main__':
    unittest.main()
