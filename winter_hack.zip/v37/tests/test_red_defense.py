"""Regression cases from V20 defensive failures; no simulated kick physics."""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.main import _act_normal, validate_red_identity
from src.framework.config import SoccerConfig
from src.framework.types import Pose2D


class RedDefense(unittest.TestCase):
    def test_red_identity_rejects_blue_or_mixed_handles(self):
        validate_red_identity(SoccerConfig())
        for config in (SoccerConfig(team_id=2),
                       SoccerConfig(robot_names=('robot4', 'robot5', 'robot6')),
                       SoccerConfig(robot_names=('robot1', 'robot2', 'robot6'))):
            with self.assertRaisesRegex(ValueError, 'Red Challenger only'):
                validate_red_identity(config)

    def test_keeper_claims_slow_moving_ball_before_far_attacker(self):
        ctx, ps, st = scene(ball=(-5.7, .3),
                           poses=((-2, 0, 0), (-6.2, .3, 0), (-1, 2, 0)))
        for p in ps:
            p.ball_velocity = (-.8, 0)
        _act_normal(ctx, ps, st)
        self.assertNotEqual(st.normal_attacker, 2)
        self.assertEqual(ps[1].action, 'guard:emergency_clear')
        self.assertEqual(sum(p.is_kicking for p in ps), 1)

    def test_keeper_will_approach_claim_outside_old_point65_radius(self):
        ctx, ps, st = scene(ball=(-5.4, 0),
                           poses=((-2, 0, 0), (-6.5, 0, 0), (-1, 2, 0)))
        _act_normal(ctx, ps, st)
        self.assertNotEqual(st.normal_attacker, 2)
        self.assertEqual(ps[1].action, 'guard:claim_line')
        self.assertGreater(math.hypot(*ps[1].desired_velocity[:2]), 0)

    def test_fast_shot_stays_in_intercept_mode(self):
        ctx, ps, st = scene(ball=(-5.7, .3),
                           poses=((-2, 0, 0), (-6.5, 0, 0), (-1, 2, 0)))
        for p in ps:
            p.ball_velocity = (-4, 0)
        _act_normal(ctx, ps, st)
        # V32: 0.8m 的来球若已经位于脚前，可先主动解围；
        # 防守者不应绕球或退出拦截线。
        self.assertTrue(ps[1].action.startswith('guard:'))
        self.assertNotIn(ps[1].action, ('attack:screen_orbit','guard:claim'))

    def test_goal_side_attacker_keeps_ball_over_far_keeper(self):
        ctx, ps, st = scene(ball=(-5.7, .3),
                           poses=((-6, .3, 0), (-6.5, -.6, 0), (-1, 2, 0)))
        _act_normal(ctx, ps, st)
        self.assertEqual(st.normal_attacker, 1)
        self.assertEqual(sum(p.is_kicking for p in ps), 1)

    def test_attacker_in_front_of_own_half_ball_repositions_before_kick(self):
        ctx, ps, st = scene(ball=(-3, 0), poses=((-2.5, 0, math.pi),))
        ps[0].attack()
        self.assertFalse(ps[0].is_kicking)
        self.assertEqual(ps[0].action, 'attack:screen_orbit')
        self.assertLess(math.dist(ps[0].target, (ctx.ball.x, ctx.ball.y)), .6)

    def test_live_ball_not_obstacle_for_keeper(self):
        from unittest.mock import patch
        ctx, ps, st = scene(ball=(-6, .4))
        with patch.object(ps[1], 'walk_to') as walk:
            ps[1].guard(allow_clear=False)
        # V31 门将直接全向封堵，不调用绕球路径规划。
        walk.assert_not_called()
        self.assertEqual(ps[1].navigation, 'keeper_v37_forward_gait')
        self.assertIsNotNone(ps[1].target)

    def test_handoff_cancels_previous_kick_before_keeper_command(self):
        ctx, ps, st = scene(ball=(-5.7, .3),
                           poses=((-2, 0, 0), (-6.2, .3, 0), (-1, 2, 0)))
        ps[0]._kicking = ps[0]._backend._kicking = True
        original = ps[1]._backend.kick
        def checked(*args):
            # Keeper independently owns its SDK channel; never stops the other robot.
            self.assertTrue(ps[0]._backend._kicking)
            original(*args)
        ps[1]._backend.kick = checked
        _act_normal(ctx, ps, st)
        self.assertTrue(ps[1].is_kicking)

    def test_clearance_chooses_unblocked_flank(self):
        ctx, ps, st = scene(ball=(-5, 0), poses=((-5.5, 0, 0),),
                           opponents=((-3.5, 0, 0),))
        direction, power = ps[0].plan_kick()
        self.assertGreater(abs(direction), 0)
        self.assertEqual(power, 8)

    def test_recovery_stays_ahead_of_keeper_line(self):
        ctx, ps, st = scene(ball=(-6, 1))
        ps[2].support('danger')
        self.assertGreaterEqual(ps[2].target[0], -5)


if __name__ == '__main__':
    unittest.main()
