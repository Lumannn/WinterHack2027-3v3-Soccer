import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.tactics import goal_gap_target, lane_clearance
from src.main import _act_opp_set_play, _act_our_kickoff, Phase
from src.framework.types import GameControlState, GameState, SetPlay


class VideoAdjustments(unittest.TestCase):
    def test_open_goal_aim_is_central(self):
        ctx, ps, st = scene(ball=(4, 0), poses=((3.5, 0, 0),))
        target = goal_gap_target(ctx, 1)
        self.assertAlmostEqual(target[1], 0)

    def test_south_blocker_chooses_north_goal_gap(self):
        ctx, ps, st = scene(ball=(4, 0), poses=((3.5, 0, 0),), opponents=((6.6, -.45, 0),))
        direction, power = ps[0].plan_kick()
        self.assertEqual(ps[0].action, 'attack:shoot')
        self.assertGreater(ps[0].aim_target[1], 0)
        self.assertLessEqual(abs(ps[0].aim_target[1]), .85)
        self.assertEqual(power, 8)

    def test_north_blocker_chooses_south_without_fixed_bias(self):
        ctx, ps, st = scene(ball=(4, 0), poses=((3.5, 0, 0),), opponents=((6.6, .45, 0),))
        ps[0].plan_kick()
        self.assertLess(ps[0].aim_target[1], 0)

    def test_post_margin_for_ball_from_both_sides(self):
        for y in (-3, -1, 0, 1, 3):
            ctx, ps, st = scene(ball=(4, y), poses=((3.5, y, 0),))
            target = goal_gap_target(ctx, 1)
            self.assertIsNotNone(target)
            self.assertLessEqual(abs(target[1]), ctx.field.goal_width/2-.45+1e-8)

    def test_blocked_goal_does_not_force_shot(self):
        ctx, ps, st = scene(ball=(4, 0), poses=((3.5, 0, 0),),
                            opponents=((6, -.7, 0), (6, 0, 0), (6, .7, 0)))
        self.assertIsNone(goal_gap_target(ctx, 1))
        ps[0].plan_kick()
        self.assertNotEqual(ps[0].action, 'attack:shoot')

    def test_opponent_restart_cover_is_not_collinear(self):
        game = GameControlState(state=GameState.PLAYING, set_play=SetPlay.THROW_IN, kicking_team=2)
        ctx, ps, st = scene(ball=(3, -4.45), game=game)
        _act_opp_set_play(ctx, ps, st)
        a, b = ps[0].target, ps[2].target
        ax, ay, bx, by = a[0]-3, a[1]+4.45, b[0]-3, b[1]+4.45
        self.assertGreater(abs(ax*by-ay*bx)/math.hypot(ax, ay), .8)
        self.assertGreater(math.dist(a,b), 1)
        for p in ps:
            self.assertFalse(p.is_kicking)
            if p.target:
                self.assertGreaterEqual(math.dist(p.target, (3,-4.45)), 1.65)

    def test_support_recovers_before_opponent_crosses_midfield(self):
        ctx, ps, st = scene(ball=(2, 0), poses=((1.5,0,0),(-6.5,0,0),(3,2,0)),
                            opponents=((2.4,0,0),(0.5,-2,0),(6,0,0)))
        ps[2].support()
        self.assertEqual(ps[2].action, 'support:recover')
        self.assertLess(ps[2].target[0], ctx.ball.x)
        self.assertGreater(math.hypot(*ps[2].desired_velocity[:2])+abs(ps[2].desired_velocity[2]), 0)

    def test_kickoff_micro_displacement_keeps_short_kick(self):
        game = GameControlState(state=GameState.PLAYING, secondary_time=8, kicking_team=1)
        ctx, ps, st = scene(ball=(.2, 0), poses=((-0.05,.45,0),(-6.5,0,0),(-2,2,0)), game=game)
        st.prev_phase = Phase.OUR_KICKOFF
        st.kickoff_origin = (0,0)
        st.kickoff_taker = 1
        _act_our_kickoff(ctx, ps, st)
        self.assertIn(ps[0].action, ('kickoff:direct_shoot','kickoff:direct_approach','kickoff:align'))
        self.assertIsNone(getattr(st,'kickoff_moved_at',None))

    def test_follow_no_longer_targets_point_nine_behind_ball(self):
        ctx, ps, st = scene(ball=(.4,-.8))
        st.prev_phase=Phase.OUR_KICKOFF
        st.kickoff_origin=(0,0)
        st.kickoff_taker=1
        _act_our_kickoff(ctx, ps, st)
        if ps[0].target:
            self.assertLess(ps[0].target[0]-(.4), 2.0)


if __name__ == '__main__':
    unittest.main()
