"""Real Player state machine + fake SDK; NOT a physics simulation."""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.main import _act_our_kickoff,Phase
from src.framework.types import GameState


def advance(ctx,p,seconds,ball=None,pose=None):
    nt=ctx.now+seconds
    ball=ball if ball is not None else (ctx.ball.x,ctx.ball.y)
    bb=replace(ctx.ball,x=ball[0],y=ball[1],last_seen_at=nt)
    teammates=dict(ctx.teammates)
    if pose is not None:
        teammates[p.id]=replace(teammates[p.id],pose=replace(teammates[p.id].pose,
            x=pose[0],y=pose[1],theta=pose[2]),last_seen_at=nt)
    else:
        teammates[p.id]=replace(teammates[p.id],last_seen_at=nt)
    new=replace(ctx,now=nt,ball=bb,teammates=teammates)
    p.context=new
    return new


class V35Contact(unittest.TestCase):
    def test_previous_long_range_077_does_not_start_sdk(self):
        ctx,ps,_=scene(poses=((-0.77,0,0),))
        ps[0].kick_off_direct((7,1),0)
        self.assertFalse(ps[0].is_kicking)
        self.assertEqual(ps[0].action,'kickoff:direct_approach')

    def test_close_aligned_starts_power10_in_body_frame(self):
        ctx,ps,_=scene(poses=((-0.35,0,0),))
        ps[0].kick_off_direct((7,1),0)
        self.assertTrue(ps[0].is_kicking)
        self.assertEqual(ps[0].kick_command[1],10)
        self.assertAlmostEqual(ps[0]._backend.commands[-1][1][2],.35)
        self.assertAlmostEqual(ps[0]._backend.commands[-1][1][3],0)

    def test_sdk_lease_does_not_cancel_at_old_3p3_second_cutoff(self):
        ctx,ps,_=scene(poses=((-0.35,0,0),),now=4.)
        p=ps[0]
        p.kick_off_direct((7,1),3.2)
        ctx=advance(ctx,p,.17)
        p.kick_off_direct((7,1),3.37)
        self.assertTrue(p.is_kicking)
        self.assertEqual(p._ko35_attempts,1)
        self.assertEqual(p._ko35_mode,'sdk')

    def test_clean_fast_contact_is_verified_and_sdk_released(self):
        ctx,ps,_=scene(poses=((-0.36,0,0),),now=4)
        p=ps[0];p.kick_off_direct((7,1),0)
        ctx=advance(ctx,p,.1,ball=(.04,.007))
        p.kick_off_direct((7,1),.1)
        ctx=advance(ctx,p,.08,ball=(.24,.040))
        p.kick_off_direct((7,1),.18)
        self.assertTrue(p._ko35_verified)
        self.assertFalse(p.is_kicking)
        self.assertGreater(p._ko35_launch_speed,1.8)
        self.assertEqual(p._ko35_mode,'launched')

    def test_slow_body_nudge_is_not_confirmed(self):
        ctx,ps,_=scene(poses=((-0.36,0,0),),now=4)
        p=ps[0];p.kick_off_direct((7,1),0)
        ctx=advance(ctx,p,.2,ball=(.05,-.01))
        p.kick_off_direct((7,1),.2)
        self.assertFalse(p._ko35_verified)
        self.assertTrue(p.is_kicking)

    def test_only_one_restage_after_failed_sdk_lease(self):
        ctx,ps,_=scene(poses=((-0.36,0,0),),now=4)
        p=ps[0];p.kick_off_direct((7,1),0)
        ctx=advance(ctx,p,3.02)
        p.kick_off_direct((7,1),3.02)
        self.assertEqual(p._ko35_mode,'restage')
        self.assertFalse(p.is_kicking)
        ctx=advance(ctx,p,.2)
        p.kick_off_direct((7,1),3.22)
        self.assertIn(p._ko35_mode,('sdk','restage'))
        # Second SDK lease expires; no third infinite re-entry.
        if p._ko35_mode=='sdk':
            ctx=advance(ctx,p,3.02)
            p.kick_off_direct((7,1),6.24)
            self.assertEqual(p._ko35_mode,'failed')

    def test_entry_requires_alignment_and_slow_body(self):
        ctx,ps,_=scene(poses=((-0.4,0,1.3),))
        p=ps[0];p.kick_off_direct((7,1),0)
        self.assertFalse(p.is_kicking)
        self.assertEqual(p.action,'kickoff:align')
        ctx,ps,_=scene(poses=((-0.4,0,0),),now=1)
        p=ps[0];p.kick_off_direct((7,1),0)
        p.reset_kickoff_v35()
        p._ko35_last_pose = (1.0,-.4,0.0)
        ctx=advance(ctx,p,.05,pose=(-.30,0,0))
        p.kick_off_direct((7,1),.05)
        self.assertFalse(p.is_kicking)
        self.assertEqual(p.action,'kickoff:stabilize')

    def test_suspect_fall_releases_sdk(self):
        ctx,ps,_=scene(poses=((-0.36,0,0),),now=2)
        p=ps[0];p.kick_off_direct((7,1),0)
        p._backend.fall_down_state='fallen'
        ctx=advance(ctx,p,.08)
        p.kick_off_direct((7,1),.08)
        self.assertFalse(p.is_kicking)
        self.assertEqual(p._ko35_mode,'failed')

    def test_set_phase_never_kicks(self):
        ctx,ps,_=scene(poses=((-0.36,0,0),))
        p=ps[0];p.context=replace(ctx,game=replace(ctx.game,state=GameState.SET))
        p.kick_off_direct((7,1),0)
        self.assertFalse(p.is_kicking)

    def test_full_kickoff_aim_is_locked_and_taker_same(self):
        ctx,ps,st=scene(poses=((-0.36,0,0),(-6.5,0,0),(-2,-2,0)))
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        aim=st.kickoff_aim
        self.assertEqual(ps[0].kick_command[1],10)
        self.assertAlmostEqual(abs(aim[1]),1.0)
        ctx=advance(ctx,ps[0],.15)
        for p in ps:p.context=ctx
        st.prev_phase=Phase.OUR_KICKOFF
        _act_our_kickoff(ctx,ps,st)
        self.assertEqual(st.kickoff_aim,aim)
        self.assertEqual(st.kickoff_taker,1)
        self.assertTrue(ps[0].is_kicking)

if __name__=='__main__':unittest.main()
