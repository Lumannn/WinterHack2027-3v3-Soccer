import math
import unittest
from dataclasses import replace
from unittest.mock import patch
from test_scenarios import scene
from src.main import SoccerSimAgent, Phase, _act_our_set_play
from src.framework.types import GameControlState, GameState, SetPlay, Pose2D
from src.param import MAX_LINEAR, CLEAR_POWER


class DirectPlay(unittest.TestCase):
    def restart(self, kind=SetPlay.CORNER_KICK, team=1):
        ctx, ps, st = scene(ball=(6.9, 4.4), poses=((6.4, 4, 0), (-6, 0, 0), (4, 1, 0)),
                            game=GameControlState(state=GameState.PLAYING, set_play=kind, kicking_team=team))
        st.prev_phase = Phase.NORMAL
        return ctx, ps, st

    def test_playing_players_stay_in_field_even_for_own_restart(self):
        ctx, ps, st = self.restart()
        _act_our_set_play(ctx, ps, st)
        self.assertFalse(ps[0].can_leave_field())
        self.assertFalse(ps[1].can_leave_field())
        self.assertFalse(ps[2].can_leave_field())
        self.assertLessEqual(ps[0].walk_point((7.2, 4.8))[1], 4.28)
        self.assertLessEqual(ps[2].walk_point((7.2, 4.8))[1], 4.28)

    def test_velocity_guard_allows_taker_step_out(self):
        ctx, ps, st = self.restart()
        _act_our_set_play(ctx, ps, st)
        p = ps[0]
        robots = dict(ctx.teammates)
        robots[1] = replace(robots[1], pose=Pose2D(6.9, 4.4, 0))
        p.context = replace(ctx, teammates=robots)
        p.set_velocity(0, 1, 0)
        self.assertLessEqual(p.pose.y + p.desired_velocity[1] * .3, 4.88)

    def test_outside_band_does_not_depend_on_which_team_restarts(self):
        ctx, ps, st = self.restart(team=2)
        ps[0].restart_taker = True
        self.assertFalse(ps[0].can_leave_field())

    def test_restart_exception_cleared_by_next_normal_frame(self):
        ctx, ps, st = self.restart()
        _act_our_set_play(ctx, ps, st)
        self.assertTrue(ps[0].restart_taker)
        normal = replace(ctx, game=GameControlState(state=GameState.PLAYING))
        for p in ps:
            p.context = normal
        with patch('src.main.record_frame'):
            SoccerSimAgent.play(normal, ps, st)
        self.assertFalse(any(p.restart_taker for p in ps))

    def test_global_planner_preserves_outside_restart_target(self):
        from src.utils.path_planner import plan_global_path
        ctx, ps, st = self.restart()
        path = plan_global_path(ctx, (7.1, 4.6), (7.2, 4.8), [], outside_margin=.8)
        self.assertIsNotNone(path)
        self.assertEqual(path[-1], (7.2, 4.8))

    def test_one_close_approach_goes_directly_to_kick(self):
        ctx, ps, st = scene(ball=(1, 0), poses=((.25, 0, 0),))
        p = ps[0]
        p.attack((4, 0), 3)
        self.assertFalse(p.is_kicking)
        self.assertAlmostEqual(p.target[0], .72)
        robots = {1: replace(ctx.teammates[1], pose=Pose2D(.72, 0, 0))}
        p.context = replace(ctx, teammates=robots)
        p.attack((4, 0), 3)
        self.assertTrue(p.is_kicking)

    def test_near_ball_does_not_overshoot_with_long_prediction(self):
        ctx, ps, st = scene(ball=(1, 0), poses=((.25, 0, 0),))
        p = ps[0]
        p.ball_velocity = (4, 0)
        p.attack((4, 0), 3)
        self.assertAlmostEqual(p.target[0], .72)

    def test_long_recovery_forward_speed_at_cap(self):
        ctx, ps, st = scene(ball=(-2, 0), poses=((3, 0, math.pi),))
        p = ps[0]
        p.support('danger')
        self.assertAlmostEqual(p.desired_velocity[0], MAX_LINEAR)
        self.assertAlmostEqual(p.desired_velocity[1], 0)

    def test_no_backward_walk_when_facing_away_from_recovery(self):
        ctx, ps, st = scene(ball=(-2, 0), poses=((3, 0, 0),))
        p = ps[0]
        p.support('danger')
        self.assertEqual(p.desired_velocity[:2], (0, 0))
        self.assertNotEqual(p.desired_velocity[2], 0)

    def test_close_recovery_brakes_before_arrival(self):
        ctx, ps, st = scene(ball=(-2, 0), poses=((0, 0, 0),))
        ps[0].walk_to((.25, 0), sprint=True)
        self.assertLess(math.hypot(*ps[0].desired_velocity[:2]), MAX_LINEAR)

    def test_opponent_half_shots_use_ten(self):
        for x in (2, 4, 6):
            ctx, ps, st = scene(ball=(x, 0), poses=((x-.5, 0, 0),))
            self.assertEqual(ps[0].plan_kick()[1], 8)
            self.assertEqual(ps[0].action, 'attack:shoot')

    def test_clearance_and_goal_kick_use_long_pass(self):
        ctx, ps, st = scene(ball=(-5, 1), poses=((-5.5, 1, 0),))
        self.assertEqual(ps[0].plan_kick()[1], 8.0)
        game = GameControlState(state=GameState.PLAYING, set_play=SetPlay.GOAL_KICK, kicking_team=1)
        ps[0].context = replace(ctx, game=game)
        st.prev_phase = Phase.NORMAL
        _act_our_set_play(ps[0].context, ps, st)
        self.assertEqual(ps[0].kick_command[1], CLEAR_POWER)


if __name__ == '__main__':
    unittest.main()
