"""Calibration must be based on measured ball launch, not SDK commands."""
import math
import unittest
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from kickoff_precision_v35 import analyze


def event(fid, start, bias=0.016, polluted=False, speed=4.0):
    rows=[]
    for dt,x,y,state in ((0,0,0,'sdk_enter'),(.06,0,0,'sdk_active'),(.12,.20,.20*math.tan(bias),'sdk_active'),(.18,.45,.45*math.tan(bias),'verified_launch')):
        rows.append({'_file':fid,'t':start+dt,'ball':[x*speed/4,y*speed/4],
          'opponents':([{'id':4,'pose':(.2,0,0)}] if polluted else []),
          'robots':[{'id':1,'action':'kickoff:direct_shoot','kickoff_contact_event':state,
              'kickoff_command_heading':0,'kick_contact_body':[.35,0],
              'pose':[-.35,0,0]}, {'id':2,'pose':[-6.5,0,0]}]})
    return rows


class CalibrationTests(unittest.TestCase):
    def test_no_contact_never_becomes_precision_sample(self):
        rows=event('a',1,speed=.3)
        report=analyze(rows)
        self.assertEqual(report['summary']['candidate_count'],0)
        self.assertIsNone(report['summary']['proposed_command_compensation_degrees'])

    def test_four_clean_repeated_contacts_propose_negative_compensation(self):
        rows=[]
        for i in range(4):rows+=event('a',1+i*5,bias=.016)
        report=analyze(rows)
        self.assertEqual(report['summary']['candidate_count'],4)
        self.assertAlmostEqual(report['summary']['proposed_command_compensation_degrees'],
                               -math.degrees(.016),delta=.3)

    def test_nearby_opponent_prevents_calibration(self):
        rows=[]
        for i in range(4):rows+=event('a',i*5,bias=.016,polluted=True)
        report=analyze(rows)
        self.assertEqual(report['summary']['candidate_count'],0)

    def test_large_angle_error_not_automatically_calibrated(self):
        rows=[]
        for i in range(4):rows+=event('a',i*5,bias=math.radians(24))
        report=analyze(rows)
        self.assertEqual(report['summary']['candidate_count'],0)

if __name__=='__main__':unittest.main()
