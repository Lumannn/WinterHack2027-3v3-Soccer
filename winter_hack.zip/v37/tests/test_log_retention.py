import json
import os
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
from test_scenarios import scene
from src.telemetry import record_frame
from src.main import Phase
from src.framework.types import GameControlState, GameState


class LogRetention(unittest.TestCase):
    def test_finished_idle_frames_do_not_overwrite_match_history(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, WH_LOG_DIR=directory):
            ctx, ps, st = scene()
            record_frame(ctx, ps, st)
            finished = replace(ctx, now=2, game=GameControlState(state=GameState.FINISHED))
            st.cur_phase = Phase.STOPPED
            record_frame(finished, ps, st)
            for i in range(205):
                record_frame(replace(finished, now=3+i*.2), ps, st)
            path = next(Path(directory).glob('*.jsonl'))
            rows = [json.loads(l) for l in path.read_text().splitlines()]
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0]['state'], 'PLAYING')
            self.assertEqual(rows[-1]['state'], 'FINISHED')
            st.cur_phase = Phase.NORMAL
            record_frame(replace(ctx, now=50), ps, st)
            self.assertEqual(len(path.read_text().splitlines()), 3)
            for h in st.telemetry_logger.handlers:
                h.close()

    def test_kick_transition_logged_between_five_hz_samples(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, WH_LOG_DIR=directory):
            ctx, ps, st = scene()
            record_frame(ctx, ps, st)
            ps[0]._kicking = True
            record_frame(replace(ctx, now=ctx.now+.033), ps, st)
            path = next(Path(directory).glob('*.jsonl'))
            rows = [json.loads(l) for l in path.read_text().splitlines()]
            self.assertEqual(len(rows), 2)
            self.assertTrue(rows[-1]['robots'][0]['kick_requested'])
            self.assertIn('aim_target', rows[-1]['robots'][0])
            for h in st.telemetry_logger.handlers:
                h.close()
