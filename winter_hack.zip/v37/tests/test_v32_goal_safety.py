"""V32 red goal geometry and no-loop kickoff regression checks.

These fake-backend tests intentionally do not simulate the physical kick or score.
"""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.framework.types import GameControlState, GameState
from src.main import Phase, _act_our_kickoff, _act_normal
from src.param import (KICKOFF_CORNER_POST_MARGIN_M, SHOT_POST_MARGIN_M,
                       KEEPER_HOME_Y_LIMIT_M)
from src.tactics import goal_gap_target, lane_clearance


class V32GoalSafety(unittest.TestCase):
    def test_goal_mouth_geometry_goal_safety(self):
        ctx,ps,st=scene(ball=(3,0),poses=((2.5,0,0),))
        self.assertEqual(ctx.field.length/2,7)
        self.assertEqual(ctx.field.goal_width/2,1.3)
        aim=goal_gap_target(ctx,1)
        self.assertIsNotNone(aim)
        self.assertEqual(aim[0],7)
        self.assertLess(abs(aim[1]),1.3-SHOT_POST_MARGIN_M+1e-8)
        d,power=ps[0].plan_kick()
        self.assertEqual(power,8)
        impact=ctx.ball.y+math.tan(d)*(7-ctx.ball.x)
        self.assertLess(abs(impact),1.3-SHOT_POST_MARGIN_M)

    def test_kickoff_taker_fires_at_far_post_inside_mouth(self):
        ctx,ps,st=scene(poses=((-0.4,0,0),(-6.55,0,0),(-.55,-1.9,0)),now=5)
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        self.assertEqual(ps[0].action,'kickoff:direct_shoot')
        self.assertEqual(ps[0].kick_command[1],10.0)
        gx,gy=st.kickoff_aim
        self.assertEqual(gx,7)
        self.assertAlmostEqual(abs(gy),1.0)
        self.assertAlmostEqual(ps[0].kick_command[0],math.atan2(gy,gx))
        self.assertEqual(st.kickoff_taker,1)
        self.assertFalse(ps[2].is_kicking)

    def test_kickoff_aim_locked_and_no_orbit_for_9_seconds(self):
        ctx,ps,st=scene(poses=((-0.4,0,0),(-6.5,0,0),(-.55,-1.9,0)),now=5)
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        aim=st.kickoff_aim
        acts=[ps[0].action]
        for delta in (1,2.5,3.5,4.5,6,7,8,8.7,9):
            ctx=replace(ctx,now=5+delta,ball=replace(ctx.ball,last_seen_at=5+delta))
            for p in ps:p.context=ctx
            st.prev_phase=Phase.OUR_KICKOFF
            _act_our_kickoff(ctx,ps,st)
            acts.append(ps[0].action)
            self.assertEqual(st.kickoff_aim,aim)
        self.assertTrue(any(a=='kickoff:one_reposition' for a in acts))
        self.assertIn('kickoff:failed_wait_referee',acts)
        self.assertFalse(ps[0].is_kicking)
        self.assertFalse(any(a.startswith('attack:') for a in acts))

    def test_kickoff_chooses_less_obstructed_corner_once(self):
        ctx,ps,st=scene(poses=((-0.4,0,0),(-6.5,0,0),(-.55,-1.9,0)),
                        opponents=((4.8,0.6,0),(5.5,0.65,0)),now=5)
        st.prev_phase=Phase.READY
        _act_our_kickoff(ctx,ps,st)
        self.assertLess(st.kickoff_aim[1],0)

    def test_no_goalkeeper_wide_chase_stationary_ball(self):
        ctx,ps,st=scene(ball=(-5.81,1.94),poses=((-2,0,0),(-6.26,1.12,0),(1,2,0)),
                        opponents=((-5.7,1.7,0),))
        self.assertFalse(ps[1].can_claim_ball())
        ps[1].guard()
        self.assertFalse(ps[1].is_kicking)
        self.assertIn(ps[1].action, ('guard:step_block','guard:covered_line'))
        self.assertLessEqual(abs(ps[1].target[1]),1.13+1e-7)
        self.assertLessEqual(ps[1].target[0],-5.50+1e-7)

    def test_goalkeeper_blocked_middle_clears_to_sideline(self):
        ctx,ps,st=scene(ball=(-6.05,0),poses=((-2,2,0),(-6.45,0,0),(0,2,0)),
                        opponents=((-4.8,-.7,0),(-4.8,0,0),(-4.8,.7,0)))
        q=ps[1].clearance_target()
        self.assertGreater(q[0],ctx.ball.x)
        self.assertGreater(abs(q[1]),3.0)
        ps[1].emergency_clear()
        self.assertEqual(ps[1].kick_command[1],8)
        self.assertGreater(math.cos(ps[1].kick_command[0]),0.0)

    def test_no_shot_if_solid_wall_fills_goalmouth(self):
        ctx,ps,st=scene(ball=(4,0),poses=((3.5,0,0),),
                        opponents=((6,-.7,0),(6,0,0),(6,.7,0)))
        self.assertIsNone(goal_gap_target(ctx,1))
        ps[0].plan_kick()
        self.assertNotEqual(ps[0].action,'attack:shoot')

    def test_stationary_wide_ball_vs_dangerous_shot_different_response(self):
        ctx,ps,st=scene(ball=(-5.0,2.0),poses=((-1,0,0),(-6.57,0,0),(0,2,0)))
        ps[1].ball_velocity=(0,0)
        ps[1].guard(allow_clear=False)
        static_y=ps[1].target[1]
        ps[1].ball_velocity=(-2.5,-1.6)
        ps[1].guard(allow_clear=False)
        self.assertTrue(abs(ps[1].target[1])<=KEEPER_HOME_Y_LIMIT_M)
        self.assertEqual(ps[1].navigation,'keeper_v37_forward_gait')
        self.assertNotEqual(ps[1].action,'attack:screen_orbit')
        self.assertNotEqual(static_y,ps[1].target[1])

if __name__=='__main__':unittest.main()
