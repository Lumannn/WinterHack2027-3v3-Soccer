"""V34 last-pass tests on actual agent logic using the same fake backend.

No claims of physical balance or scoring certainty.
"""
import math
import unittest
from unittest.mock import patch
from dataclasses import replace
from test_scenarios import scene
from src.main import SoccerSimAgent, _select_closest_attacker
from src.framework.types import GameState, GameControlState, TeamState, PlayerState, Penalty, Pose2D
from src.param import SHOT_POWER, SHOT_NEAR_BALL_ENTER_M

class V34FinalRulesShots(unittest.TestCase):
    def test_attacker_with_ball_behind_loses_to_available_front_foot(self):
        ctx,ps,_=scene(ball=(0,0),poses=((.20,0,0),(-6.5,0,0),(-.36,.05,0)))
        self.assertEqual(_select_closest_attacker(ctx,[ps[0],ps[2]],1).id,3)

    def test_keep_opponent_ready_line_without_backtracking(self):
        ctx,ps,_=scene(ball=(-4.3,.6),poses=((-1,2,0),(-5.75,0,0),(0,2,0)),
                       opponents=((-4.3,.6,0),))
        ps[1].guard(forwards=(ps[0].pose,ps[2].pose))
        self.assertEqual(ps[1].keeper_decision,'guard:hold_shot_line')
        self.assertAlmostEqual(ps[1].target[0], -5.75)
        self.assertFalse(ps[1].is_kicking)

    def test_shot_reaims_on_subtle_ball_shift(self):
        ctx,ps,_=scene(ball=(4,0),poses=((3.57,0,0),))
        p=ps[0]; p.attack()
        initial=p.kick_command
        ctx=replace(ctx,now=ctx.now+.05,ball=replace(ctx.ball,x=4.05,y=.10))
        p.context=ctx; p.attack()
        self.assertEqual(p.kick_command[1],SHOT_POWER)
        self.assertNotAlmostEqual(initial[0],p.kick_command[0],places=5)
        self.assertLessEqual(math.dist((p.pose.x,p.pose.y),(ctx.ball.x,ctx.ball.y)),SHOT_NEAR_BALL_ENTER_M)

    def test_set_phase_releases_active_kick_without_getup(self):
        ctx,ps,st=scene()
        ps[0].attack(); self.assertTrue(ps[0].is_kicking)
        new=replace(ctx,game=replace(ctx.game,state=GameState.SET))
        for p in ps:p.context=new
        with patch('src.main.record_frame'):
            SoccerSimAgent.play(new,ps,st)
        self.assertFalse(any(p.is_kicking for p in ps))
        self.assertTrue(all(p.action=='stopped' for p in ps))

    def test_penalized_player_not_sent_movement_or_kick(self):
        ctx,ps,st=scene()
        ps[0].attack(); self.assertTrue(ps[0].is_kicking)
        first=PlayerState(penalty=Penalty.INCAPABLE_ROBOT,secs_till_unpenalised=15)
        teams=(TeamState(team_number=1,players=(first,PlayerState(),PlayerState())),TeamState(team_number=2))
        new=replace(ctx,game=replace(ctx.game,teams=teams))
        for p in ps:p.context=new
        ps[0]._backend.fall_down_state='fallen'
        with patch('src.main.record_frame'):
            SoccerSimAgent.play(new,ps,st)
        self.assertTrue(ps[0].action.startswith('penalized:INCAPABLE_ROBOT'))
        self.assertFalse(ps[0].is_kicking)

if __name__=='__main__':unittest.main()
