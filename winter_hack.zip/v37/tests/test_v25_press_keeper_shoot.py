"""V25 code-level regression tests. The fake backend does not model ball flight."""
import math
import unittest
from dataclasses import replace
from test_scenarios import scene
from src.main import _act_normal, _act_opp_set_play
from src.framework.types import GameControlState, GameState, SetPlay, Pose2D


class ActivePressKeeperShoot(unittest.TestCase):
    def test_counterattack_in_opponent_half_wakes_second_forward(self):
        ctx, ps, st = scene(ball=(2.5, .2),
                            poses=((2, .2, 0), (-6.5, 0, 0), (4.0, 1.5, 0)),
                            opponents=((2.7, .25, 0), (4, -2, 0)))
        _act_normal(ctx, ps, st)
        self.assertEqual(ps[2].action, 'press:chase')
        self.assertLess(math.dist(ps[2].target, (2.5, .2)), 0.75)
        self.assertEqual(sum(p.is_kicking for p in ps), 1)

    def test_backfield_both_forwards_chase_not_park(self):
        ctx, ps, st = scene(ball=(-3, 1),
                            poses=((-3.5, 1, 0), (-6.5, 0, 0), (2.0, -1, 0)),
                            opponents=((-3.2, 1.3, 0),))
        _act_normal(ctx, ps, st)
        self.assertIn(ps[0].action, ('attack:shoot', 'attack:clear', 'attack:advance', 'attack:intercept', 'attack:screen_orbit', 'attack:pressure_poke'))
        self.assertEqual(ps[2].action, 'press:chase')
        self.assertGreater(sum(v*v for v in ps[2].desired_velocity), 0)

    def test_approaching_keeper_uses_direct_path_not_orbit(self):
        ctx, ps, st = scene(ball=(-5.4, 0),
                            poses=((-2, 0, 0), (-6.5, 0, 0), (1, 2, 0)))
        _act_normal(ctx, ps, st)
        self.assertNotEqual(st.normal_attacker, 2)
        self.assertEqual(ps[1].action, 'guard:claim_line')
        self.assertLessEqual(ps[1].target[0], -7 + 1.50 + 1e-8)
        self.assertGreater(ps[1].target[0], -6.5)
        self.assertFalse(ps[1].is_kicking)
        self.assertTrue(any(p.action.startswith('attack:') for p in (ps[0], ps[2])))

    def test_keeper_direct_touch_even_on_wrong_side(self):
        ctx, ps, st = scene(ball=(-6.2, 0), poses=((-3,0,0), (-6.05,0,math.pi), (1,1,0)))
        _act_normal(ctx, ps, st)
        self.assertEqual(ps[1].action, 'guard:emergency_clear')
        self.assertTrue(ps[1].is_kicking)
        self.assertAlmostEqual(ps[1].kick_command[1], 8)
        self.assertGreater(math.cos(ps[1].kick_command[0]), .9)

    def test_keeper_does_not_chase_far_beyond_box(self):
        ctx, ps, st = scene(ball=(-4.4, 0),
                            poses=((-1, 0, 0), (-6.5,0,0), (-2, 1, 0)))
        for p in ps:
            p.ball_velocity = (-3, 0)
        _act_normal(ctx, ps, st)
        self.assertNotEqual(st.normal_attacker, 2)
        self.assertTrue(ps[1].action.startswith('guard:'))
        self.assertLessEqual(ps[1].target[0], -6.2)

    def test_only_real_shoot_uses_ten(self):
        ctx, ps, st = scene(ball=(3.5,0), poses=((3,0,0), (-6.5,0,0), (0, 2,0)))
        ps[0].attack()
        self.assertEqual(ps[0].action, 'attack:shoot')
        self.assertEqual(ps[0].kick_command[1], 8)
        # A clear-pass on the far side must not inherit 10 from field position.
        ps[0].kick(0.0, 4.0)
        self.assertEqual(ps[0].kick_command[1], 4)
        ctx2, other, st2 = scene(ball=(-6,0), poses=((-6.5,0,0),))
        other[0].attack()
        self.assertEqual(other[0].kick_command[1], 8)

    def test_near_ball_small_lateral_offset_kicks_without_orbit(self):
        ctx, ps, st = scene(ball=(3,0), poses=((2.7,.3,0),))
        ps[0].attack()
        self.assertTrue(ps[0].is_kicking)
        self.assertNotEqual(ps[0].action, 'attack:screen_orbit')

    def test_opponent_set_piece_still_stays_legal(self):
        game = GameControlState(state=GameState.PLAYING, set_play=SetPlay.CORNER_KICK, kicking_team=2)
        ctx, ps, st = scene(ball=(6.5,4.0), game=game)
        _act_opp_set_play(ctx, ps, st)
        self.assertFalse(any(p.is_kicking for p in ps))
        self.assertFalse(any(p.action == 'press:chase' for p in ps))


if __name__ == '__main__':
    unittest.main()
