# WinterHack V37 — 裁判安全优先 / 门将提前拦截 / 对方底线方向推进

版本：3.7.0。基于 V36 完整工程，目标是**消除已复现的违例站位根源、让门将更早封线，并提高危险进攻的指向性**。

## 证据与实装

### 1. 对方界外球与罚下
V36 录制的 `wh36_2582.jsonl`：对方 THROW_IN，`kicking_team=2`，在球 `(-6.09,4.43)` 附近 robot1 曾执行 `restart:block`，离球约 0.60–0.69m，同时有明显场界外 y 坐标。之后裁判记录 `ILLEGAL_POSITIONING`，惩罚约 30 秒。**不能仅由罚下名称确定是越界还是距离不足导致。**

V37：
- 优先依据裁判当前 `set_play` + `kicking_team` + `secondary_time` 分类；对方定位球不得执行踢球 SDK。开球直接函数也会拒绝明确的对方主罚指令。
- 对方定位球时最低目标安全圈 2.30 m（工程保守值，不宣称官方规则恰为该数）；仅选取裁剪后仍合规、距边线留有 0.53m 的候选目标，无法找到合法目标则停球。
- 若机器人已经站在危险范围，标记 `restart:evacuate_illegal`，向合法目标撤离。切勿为了争球继续靠近主罚球。
- 任何情况下 `can_leave_field()` 都返回 False。尤其取消旧版角球主罚者可以进入界外的特例，优先降低 `ILLEGAL_POSITIONING`、`LEAVING_THE_FIELD` 风险。
- 本队直射开球保留 `power=10`、`(7,±1.0)` 和 SDK 完整接管；对方开球不能以我方开球动作处理。

### 2. 门将 y 轴侧移无效
V36 在失球前约 227–231 秒，robot2 多次发出接近 -1.9m/s 的 `vy`（身体侧移）命令，日志测得 y 位移很小。SDK/步态是否严格支持该速度尚无接口保证。球从 `(-2.91,0.36)` 向 `(-7.0,-1.02)` 运动时，V36 起初目标 y 接近 0，直到球进门线附近才追。

V37：
- 改成更早的球路相交预判（最长 5.4 秒，仅在球朝我方运动且预测射门区合理时）。
- 门将走位优先“朝目标转身 + `vx` 前进”，不再假设 `vy=-1.9` 一定能侧移。失去面向球的瞬间是短暂换取更可靠的位置移动，不是弃守。
- 高速近门来球依旧优先紧急挡线；门线附近的 `guard:mouth_rescue` 仍拥有最高优先级。
- 解围 SDK 只有球进入更可靠触球区域（<=0.64m）才启用；对来球已继续向球门移动而又没有实际解围的租约，可更早释放 SDK 返回拦截。**踢球命令不等于成功触球**。

### 3. 射门偏向对方球门与底线
- 在无足够门内射线时、球位于 `x>=-1.2` 且出现安全的门线方向通道，增加 `attack:goal_line_drive`（power=8），瞄准 `(7,-0.65/0/+0.65)`，不再经常朝侧边做短距离推进。
- 有明确安全射门机会仍优先 `attack:shoot`（power=8）。开球专用 `power=10` 不变。
- 不能承诺每脚都过门线或必进：实际球接触/SDK 脚位及碰撞都需要录像和日志验证。

## 测试
- 196 项离线单元/场景测试全部通过（含 11 项 V37 新测试）。
- `python tools/offline_smoke.py`：600 帧假底盘状态切换通过。
- 使用 V36 历史日志做**反事实几何决策重放**：V37 在球 `(-2.9139,0.3572)`、速度约 `(-1.03,-0.236)` 时提前预置 y≈-0.41，而 V36 当时指向 y≈+0.04；不是仿真物理验证。
- **尚未**在 Booster Studio 对 V37 完成真实物理对战；不保证零犯规、零失球、零摔倒或空位必进。

## 文件
- `src/main.py`：阶段分派 + 开球主罚权硬保护 + 对方定位球合法站位。
- `src/player.py`：门将可靠前进步态 + SDK 触球区收紧 + 远底线方向有力推进。
- `src/keeper_v33.py`：提前横向射线落点预测。
- `src/tactics.py`：严格可行的对方定位球退让点搜索。
- `src/telemetry.py`：10Hz 正常阶段 / 约 30Hz 开球、对方定位球和危险动作，保留世界坐标球速度和运动实测。
- `tools/v37_diagnostics.py`：自动整理罚下变化、定位球近距风险、守门动作、踢球指令。
- `tools/replay_v36_decisions_v37.py`：旧日志下的几何决策反事实回放，不模拟足球物理。
- `tools/export_logs.ps1`：固定 V37 新日志位置并自动搜含 V37 日志的容器。

## 构建与导出
安装依赖、构建 Agent 的 Booster Studio 工作流与 V36 一致。必须 **重新构建**，且确认 `V37 build=3.7.0` 以及 `agent.toml` 的 version 为 `3.7.0`，不要将 V36 的 `.agent` 缓存复用。

运行一场新比赛后，在 **V37 工程根目录**执行：
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\export_logs.ps1
```
默认容器内位置为 `/tmp/winterhack_v37/wh37_<PID>.jsonl`。日志 `LastWriteTime` 为最后写入时刻，不是导出时刻。

生成诊断报告：
```powershell
python .\tools\v37_diagnostics.py .\wh37_logs_XXXX\wh37_YYYY.jsonl -o diagnosis.json
```

重点核对 `penalties`（必须不是通过静止被动逃避）、`risky_opponent_restarts`、`goalkeeper_interventions`、`observed_motion`、`kickoff_events` 和 `shooting_events`。这些字段提供分析依据，不代表物理引擎已验证行动成功。
