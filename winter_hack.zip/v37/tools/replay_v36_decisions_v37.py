"""Counterfactual geometric decision replay. Does not simulate robot motion."""
import argparse,json,math
from pathlib import Path
from types import SimpleNamespace as NS
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from src.keeper_v33 import goalie_decision
from src.tactics import restart_retreat
from src.framework.types import ADULT_FIELD_DIMENSIONS

def run(logfile):
    rows=[json.loads(s) for s in open(logfile,encoding='utf8') if s.strip()]
    start=rows[0]['t'];wanted=(135.4, 136.0, 138.5, 224.5,225.5,226.5,228.5,229.5,230.5,231.5)
    result=[]
    for sec in wanted:
        e=min(rows,key=lambda r:abs(r['t']-start-sec))
        ball=e.get('ball');v=e.get('ball_velocity_estimate') or (0,0)
        if ball is None: continue
        ctx=NS(field=ADULT_FIELD_DIMENSIONS,ball=NS(x=ball[0],y=ball[1]),opponents={})
        d=goalie_decision(ctx,v)
        rec={'elapsed':round(e['t']-start,3),'ball':ball,'velocity':v,
             'old_goalie':next(({'action':r['action'],'target':r.get('target'),'pose':r.get('pose')}
                                for r in e.get('robots',[]) if r['id']==2),None),
             'new_goalie':{'action':d.action,'target':d.target}}
        if e.get('phase')=='opp_set_play':
            rec['old_field']=next(({'pose':r.get('pose'),'target':r.get('target')}
                                   for r in e.get('robots',[]) if r['id']==1),None)
            if rec['old_field']:
                pos=rec['old_field']['pose']
                safe=restart_retreat(ctx,(ball[0]-2.4,ball[1]-0.7),radius=2.30)
                rec['safe_restart_target']=safe
                rec['old_restart_current_distance']=math.hypot(pos[0]-ball[0],pos[1]-ball[1])
                rec['new_target_distance']=math.dist(safe,ball) if safe else None
        result.append(rec)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('log');p.add_argument('-o','--output',default='v37_replay.json');a=p.parse_args()
    res=run(a.log);Path(a.output).write_text(json.dumps(res,indent=2,ensure_ascii=False),encoding='utf8')
    print('Saved replay:',a.output)
