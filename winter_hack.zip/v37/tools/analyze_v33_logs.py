"""Analyze a match-log directory or JSONL; requests are not proven physical kicks."""
from __future__ import annotations
import collections
import json
import math
import sys
from pathlib import Path


def load(path):
    files = sorted(path.glob('*.jsonl*')) if path.is_dir() else [path]
    rows = {}
    for fp in files:
        for line in fp.open('r',encoding='utf-8',errors='replace'):
            try: d=json.loads(line)
            except (json.JSONDecodeError,UnicodeDecodeError):continue
            if not isinstance(d,dict) or not isinstance(d.get('t'),(int,float)) or not 'robots' in d:continue
            # Rotating logs or duplicate copies may overlap.
            rows[(d['t'], d.get('version'), d.get('team_id'))] = d
    return sorted(rows.values(),key=lambda r:r['t'])


def analyze(rows):
    if not rows:print('No readable frames');return
    phases=collections.Counter(x.get('phase') for x in rows)
    acts={i:collections.Counter() for i in (1,2,3)}
    kicks=collections.Counter()
    feet=collections.Counter()
    goal_events=[]
    prev=None
    for r in rows:
        for p in r.get('robots',[]):
            pid=p.get('id')
            if pid not in acts:continue
            acts[pid][p.get('action')]+=1
            command=p.get('kick_command_world')
            if p.get('kick_requested') and command:
                power=command[1]
                kicks[(pid,'shot(hard)' if power>5 else 'long' if power>=2 else 'short')]+=1
                feet[(pid,p.get('foot_side_hint'))]+=1
        score=r.get('scores')
        if prev is not None and score and prev.get('scores') and score!=prev.get('scores'):
            before=[x for x in rows if r['t']-2 <= x['t'] < r['t']]
            last=before[0] if before else prev
            keeper=last['robots'][1] if len(last.get('robots',[]))>=2 else {}
            goal_events.append((r.get('seconds_remaining'),score,keeper.get('action'),
                                keeper.get('pose'),last.get('ball')))
        if score: prev=r
    print('Samples:',len(rows),'versions:',set(r.get('version') for r in rows))
    print('Phases:', dict(phases))
    for pid in (1,2,3):
        print('robot%d frequent actions:'%pid, acts[pid].most_common(9))
    print('Kick REQUEST samples:',dict(kicks))
    print('Foot HINT samples (not actual hardware feet):',dict(feet))
    print('Goals / score changes observed (game seconds remaining, score, keeper action ~2s prior, keeper pose, ball):')
    for event in goal_events:print(' ',event)
    print('IMPORTANT: samples are not kicks, kick requests are not contacts or goals; also inspect video.')


if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: python tools/analyze_v33_logs.py logfile_or_dir')
    analyze(load(Path(sys.argv[1])))
