"""Conservative post-match shot feedback. Never auto-modifies strategy parameters.

Example: python tools/shot_feedback.py path/to/wh34_1234.jsonl
Candidate errors must also be confirmed in video before any compensation is used.
"""
import argparse
from collections import Counter
import json
import math
import statistics
from pathlib import Path


def wrap(a):
    return (a+math.pi)%(2*math.pi)-math.pi


def analyze(rows):
    rows=[x for x in rows if x.get('ball') is not None and x.get('robots')]
    events=[]; seen={}
    for i,r in enumerate(rows):
        for p in r['robots']:
            if not (p.get('action') in ('attack:shoot','kickoff:direct_shoot')
                    and p.get('kick_command_world')):
                continue
            key=p['id'],p['action']
            if key in seen and 0<=r['t']-seen[key]<0.7:
                seen[key]=r['t']; continue
            seen[key]=r['t']
            bx,by=r['ball'][:2];cmd=float(p['kick_command_world'][0]);d=p.get('kick_contact_distance')
            if d is None and p.get('pose'):
                d=math.hypot(bx-p['pose'][0],by-p['pose'][1])
            out=dict(t=round(r['t']-rows[0]['t'],2),robot=p['id'],action=p['action'],
                     command_deg=round(math.degrees(cmd),2),distance=d,classification=None,
                     error_deg=None)
            if d is None or d>.75:
                out['classification']='contact_too_far_or_unknown'
            else:
                trajectory=None
                for q in rows[i+1:]:
                    dt=q['t']-r['t'];
                    if dt>1.0:break
                    if dt<.08 or q.get('ball') is None:continue
                    dx,dy=q['ball'][0]-bx,q['ball'][1]-by
                    if dt<=.8 and math.hypot(dx,dy)>.22 and math.hypot(dx,dy)/dt>1.15:
                        trajectory=(dx,dy,dt);break
                if trajectory is None:
                    out['classification']='no_confirmed_contact'
                else:
                    dx,dy,dt=trajectory
                    near_opp=any(q.get('pose') and math.hypot(q['pose'][0]-bx,q['pose'][1]-by)<.95
                                 for q in r.get('opponents',[]))
                    near_mate=any(q.get('id')!=p['id'] and q.get('pose') and
                                  math.hypot(q['pose'][0]-bx,q['pose'][1]-by)<.85
                                  for q in r['robots'])
                    err=wrap(math.atan2(dy,dx)-cmd)
                    if dx<=0:
                        out['classification']='backwards_or_other_contact'
                    elif near_opp or near_mate:
                        out['classification']='crowded_ambiguous'
                    elif abs(err)>math.radians(15):
                        out['classification']='deviation_too_large_ambiguous'
                    else:
                        out['classification']='candidate_video_review_needed'
                        out['error_deg']=round(math.degrees(err),2)
            events.append(out)
    candidates=[x['error_deg'] for x in events if x['classification']=='candidate_video_review_needed']
    correction=-statistics.median(candidates) if len(candidates)>=3 else None
    return {'events':events,'summary':dict(total=len(events),classifications=dict(Counter(
           x['classification'] for x in events)),candidate_count=len(candidates),
           proposed_compensation_deg=(round(max(-3.44,min(3.44,correction)),2)
                                       if correction is not None else None),
           note='Unverified trajectory candidates only. Do not apply without checking video and actual contact.')}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('jsonl',nargs='+')
    ap.add_argument('--output',default='shot_feedback_report.json')
    a=ap.parse_args()
    rows=[]
    for path in a.jsonl:
        for line in Path(path).open(encoding='utf8'):
            try: rows.append(json.loads(line))
            except ValueError: pass
    out=analyze(rows)
    Path(a.output).write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf8')
    print(json.dumps(out['summary'],ensure_ascii=False,indent=2))

if __name__=='__main__':main()
