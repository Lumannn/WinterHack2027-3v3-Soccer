"""V37 offline match log triage: no claim of physical contact from commands alone.
Usage: python tools/v37_diagnostics.py wh37_1234.jsonl -o report.json
"""
import argparse, collections, json, math
from pathlib import Path

def inspect_log(path):
    entries=[]
    with open(path,encoding='utf8') as f:
        for n,line in enumerate(f,1):
            try: entries.append(json.loads(line))
            except json.JSONDecodeError: pass  # Rotating logs can contain an unfinished final line
    if not entries: raise ValueError('No usable JSONL records')
    entries.sort(key=lambda e:e.get('t',0))
    out={'source':str(path),'version_counts':dict(collections.Counter(e.get('version') for e in entries)),
         'frames':len(entries),'match_events':[],'penalties':[],'risky_opponent_restarts':[],
         'goalkeeper_interventions':[],'kickoff_events':[],'shooting_events':[], 'observed_motion':{}}
    last_penalty={};last_score=None; last_keeper=None; last_kickoff=None
    velocities=collections.defaultdict(list)
    for e in entries:
        t=e.get('t');b=e.get('ball');robots=e.get('robots') or []
        scores=e.get('scores')
        if scores!=last_score and scores is not None:
            out['match_events'].append({'t':t,'event':'score_snapshot','scores':scores,'ball':b})
            last_score=scores
        phase=e.get('phase')
        for r in robots:
            pid=r.get('id');pen=r.get('penalty','NONE')
            if pid not in last_penalty: last_penalty[pid]=pen
            elif pen!=last_penalty[pid]:
                out['penalties'].append({'t':t,'robot':pid,'from':last_penalty[pid], 'to':pen,
                                         'state':e.get('state'),'set_play':e.get('set_play'),
                                         'kicking_team':e.get('kicking_team'),'pose':r.get('pose'),'ball':b})
                last_penalty[pid]=pen
            pose=r.get('pose');observed=r.get('observed_velocity_world');cmd=r.get('velocity_command_body')
            if pose and observed and cmd:
                ct,st=math.cos(pose[2]),math.sin(pose[2]); commanded=(ct*cmd[0]-st*cmd[1],st*cmd[0]+ct*cmd[1])
                dot=sum(a*b for a,b in zip(commanded,observed))
                norm=math.hypot(*commanded)
                if norm>0.5: velocities[pid].append(dot/norm)
            if phase=='opp_set_play' and b and pose:
                separation=math.hypot(pose[0]-b[0],pose[1]-b[1])
                if separation<2.3 or abs(pose[1])>4.30:
                    if len(out['risky_opponent_restarts'])<150:
                        out['risky_opponent_restarts'].append({'t':t,'robot':pid,'separation':round(separation,3),
                                         'y':pose[1],'action':r.get('action'),'target':r.get('target')})
            if pid==2:
                action=r.get('action')
                if action != last_keeper:
                    out['goalkeeper_interventions'].append({'t':t,'action':action,'ball':b,
                                             'pose':pose,'target':r.get('target'),
                                             'estimated_ball_velocity':e.get('ball_velocity_estimate')})
                    last_keeper=action
            if r.get('action','').startswith('kickoff:'):
                event=(r.get('action'),r.get('kickoff_contact_event'),r.get('kickoff_verified'))
                if event != last_kickoff:
                    out['kickoff_events'].append({'t':t,'robot':pid,'phase':phase, 'owner':e.get('kicking_team'),
                                    'action':event[0],'sdk_event':event[1], 'verified':event[2],
                                    'ball':b,'pose':pose,'heading':r.get('kickoff_command_heading'),
                                    'speed':r.get('kickoff_launch_speed'),'error':r.get('kickoff_launch_error_rad')})
                    last_kickoff=event
            if (r.get('kick_requested') and 'shoot' in r.get('action','')):
                if len(out['shooting_events'])<250:
                    out['shooting_events'].append({'t':t,'robot':pid,'action':r.get('action'),
                                      'kick_command':r.get('kick_command_world'),
                                      'predicted_goal_y':r.get('predicted_goal_line_y'),
                                      'ball':b,'ball_velocity':e.get('ball_velocity_estimate')})
    for pid,speeds in velocities.items():
        sorted_s=sorted(speeds)
        out['observed_motion'][str(pid)]={'samples':len(speeds),
            'median_progress_mps':sorted_s[len(sorted_s)//2] if speeds else None}
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('log');p.add_argument('-o','--output',default='v37_diagnosis.json')
    args=p.parse_args();result=inspect_log(args.log)
    Path(args.output).write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
    print(f"Wrote {args.output}; frames={result['frames']} penalties={len(result['penalties'])} "
          f"risky restart samples={len(result['risky_opponent_restarts'])}")
