"""600帧策略状态切换/算法耗时；假底盘、关闭日志，不模拟物理或 SDK。"""
import random
import statistics
import sys
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from test_scenarios import scene
from src.main import SoccerSimAgent
from src.framework.types import GameControlState, GameState, SetPlay

rng = random.Random(20)
ctx, ps, _ = scene()
store = SimpleNamespace()
SoccerSimAgent.init_store(None, store)
samples = []
with patch('src.main.record_frame'):
    for i in range(600):
        phase = i // 30 % 7
        game = GameControlState(
            state=GameState.PLAYING if phase < 5 else GameState.READY if phase == 5 else GameState.SET,
            set_play=SetPlay.CORNER_KICK if phase in (3, 4) else SetPlay.NONE,
            secondary_time=8 if phase in (1, 2) else 0,
            kicking_team=1 if phase in (1, 3) else 2 if phase in (2, 4) else 255)
        poses = tuple((rng.uniform(-6.5, 6.5), rng.uniform(-4, 4), rng.uniform(-3.14, 3.14)) for _ in range(3))
        opponents = tuple((rng.uniform(-6.5, 6.5), rng.uniform(-4, 4), 0) for _ in range(3))
        ctx, _, _ = scene(ball=(rng.uniform(-6.8, 6.8), rng.uniform(-4.4, 4.4)), poses=poses,
                          opponents=opponents, now=10+i/30, game=game)
        for p in ps:
            p.context = ctx
        start = time.perf_counter()
        SoccerSimAgent.play(ctx, ps, store)
        samples.append((time.perf_counter() - start) * 1000)
        assert sum(p.is_kicking for p in ps if p.id in (1, 3)) <= 1  # independent keeper may kick simultaneously
print('600 mixed-phase offline frames, seed=20: PASS')
print(f'mean={statistics.mean(samples):.3f}ms, p95={sorted(samples)[570]:.3f}ms, max={max(samples):.3f}ms')
print('Fake backend, telemetry disabled. Excludes SDK/ROS; does not prove real-time match performance.')
