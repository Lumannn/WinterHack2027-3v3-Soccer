"""Candidate shot-direction diagnostics from official agent JSONL.

The console report is *observational only*. The observed ball trajectory can
include spin, obstacles, other kicks, physics, and delayed automatic kicking;
never treat a single difference as a calibrated direction offset.
"""
import argparse
import json
import math
import statistics
from pathlib import Path


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def sample(rows, i):
    r = rows[i]
    if r.get('phase') != 'normal' or r.get('ball') is None:
        return None
    for rob in r.get('robots', []):
        if not rob.get('action','').startswith('attack:shoot') or not rob.get('kick_requested'):
            continue
        cmd = rob.get('kick_command_world')
        if not cmd or cmd[1] < 5.0: continue
        if rob.get('kick_contact_distance',float('inf')) > 0.60:continue
        if sum(bool(x.get('kick_requested')) for x in r['robots']) != 1: continue
        if any(op.get('pose') and math.dist(op['pose'][:2], r['ball']) < 0.95
               for op in r.get('opponents',[])):
            continue
        for q in rows[i+1:i+8]:
            dt=q.get('t',0)-r.get('t',0)
            if not 0.08<=dt<=0.95 or q.get('ball') is None:continue
            if q.get('phase') != 'normal' or q.get('scores') != r.get('scores'):break
            step=(q['ball'][0]-r['ball'][0],q['ball'][1]-r['ball'][1])
            travel=math.hypot(*step)
            if travel<0.17:continue
            # This is raw displacement, *not* a guarantee of clean contact.
            angle=math.atan2(step[1],step[0]); err=wrap(angle-cmd[0])
            if abs(err)>0.80:break
            return (r['t'],rob['id'],round(cmd[0],4),round(angle,4),round(err,4),round(travel,3),round(dt,3))
    return None


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('jsonl',type=Path)
    args=ap.parse_args()
    rows=[]
    with args.jsonl.open(encoding='utf8') as f:
        for l in f:
            try:
                r=json.loads(l)
                if r.get('version','').startswith('V34'):rows.append(r)
            except json.JSONDecodeError:pass
    candidates=[];last=(-100,None)
    for i in range(len(rows)):
        r=sample(rows,i)
        if r and (r[1]!=last[1] or r[0]-last[0]>1.0):
            candidates.append(r);last=(r[0],r[1])
    print('候选出脚轨迹（非确证接触）:',len(candidates))
    print('time  robot  cmd_rad  move_rad  error_rad  travel_m  dt_s')
    for r in candidates[:80]:print(*r)
    if len(candidates)>=5:
        errs=[r[4] for r in candidates]
        med=statistics.median(errs)
        mad=statistics.median(abs(x-med) for x in errs)
        print(f'候选角偏差中位数={med:+.3f}rad; MAD={mad:.3f}rad。请先人工核对录像/接触，勿直接套用。')
    else:print('有效样本不足。不能自动修改 SHOT_EMPIRICAL_BIAS_RAD。')

if __name__=='__main__':main()
