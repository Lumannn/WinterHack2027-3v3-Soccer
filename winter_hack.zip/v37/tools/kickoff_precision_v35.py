"""V35 kickoff contact diagnostics and optional angle calibration.

Usage:
    python tools/kickoff_precision_v35.py wh35_1234.jsonl -o kickoff_report.json

IMPORTANT: reads actual BALL movement, not kick *commands*. A completed SDK
command does not prove a kick. Suggestions never auto-edit src/param.py.
Launch bias is only suggested after multiple isolated high-rate kick events.
"""
import argparse
import json
import math
import statistics
from collections import Counter
from pathlib import Path


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def dist(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])


def analyze(rows):
    # Keep sessions separate, even when timestamps between sessions happen to overlap.
    clean=[];events=[]
    by_file={}
    for r in rows:
        if r.get('ball') is None or not r.get('robots'):
            continue
        by_file.setdefault(r.get('_file', ''), []).append(r)
    for filename, frames in by_file.items():
        frames.sort(key=lambda q:q.get('t',0))
        starts=[]
        for i,r in enumerate(frames):
            p=next((x for x in r['robots'] if x.get('id')==1),None)
            if p is None:continue
            if p.get('kickoff_contact_event') in ('sdk_enter','sdk_near_enter'):
                if starts and r['t']-starts[-1][1]['t'] < .48:
                    continue
                starts.append((i,r,p))
        for idx,entry,player in starts:
            start_t=entry['t']; origin=entry['ball']; command=player.get('kickoff_command_heading')
            contact=player.get('kick_contact_body')
            record=dict(file=filename,t=start_t,command_rad=command,
                        contact_body=contact,classification='unknown',
                        measured_speed=None,launch_heading_rad=None,error_deg=None,
                        projected_goal_y=None)
            if command is None or contact is None:
                record['classification']='missing_direction_or_contact'
                events.append(record);continue
            d=math.hypot(*contact)
            if not (.13 <= contact[0] <= .57 and abs(contact[1])<=.22 and d<=.58):
                record['classification']='unsupported_contact_geometry'
                events.append(record);continue
            # Avoid contact contamination by opponents, other teammates.
            others=[q['pose'] for q in entry.get('opponents',[]) if q.get('pose')]
            others += [q['pose'] for q in entry.get('robots',[]) if q.get('id')!=1 and q.get('pose')]
            if any(dist(q,origin)<.94 for q in others):
                record['classification']='nearby_other_player'
                events.append(record);continue
            obs=[]
            prev=entry
            # Use neighboring high-rate observations. The mean displacement
            # since *command issuance* is NOT launch velocity: SDK warmup may
            # be >1 s before the real foot-ball contact.
            for later in frames[idx+1:]:
                elapsed=later['t']-start_t
                if elapsed>2.0:break
                if later.get('ball') is None:continue
                dt=later['t']-prev['t']
                if not (.015<=dt<=.19):
                    prev=later;continue
                dx=later['ball'][0]-prev['ball'][0]
                dy=later['ball'][1]-prev['ball'][1]
                v=math.hypot(dx,dy)/dt
                moved=dist(later['ball'],origin)
                if v>=1.8 and moved>=.13:
                    obs.append((elapsed,v,math.atan2(dy,dx),later['ball']))
                    if len(obs)>=2:break
                prev=later
            if not obs:
                record['classification']='no_verified_high_speed_contact'
                events.append(record);continue
            elapsed,speed,angle,ball=obs[0]
            err=wrap(angle-command)
            record['measured_speed']=round(speed,3)
            record['launch_heading_rad']=round(angle,5)
            record['error_deg']=round(math.degrees(err),3)
            record['projected_goal_y']=round(origin[1]+math.tan(angle)*(7-origin[0]),3) if math.cos(angle)>.3 else None
            # A large discrepancy means a body deflection or another cause,
            # NOT evidence of a consistent 24-degree SDK rotation bias.
            if speed<1.8 or math.cos(angle)<=0 or abs(err)>math.radians(12):
                record['classification']='large_error_or_reverse_check_video'
            else:
                # More than one high-rate point improves confidence, but
                # a single point still needs human video corroboration.
                record['classification']='candidate_video_review' if len(obs)>1 else 'low_sample_rate_video_review'
                clean.append(err)
            events.append(record)
    proposed=None
    estimated_bias_deg=None
    if len(clean)>=4:
        med=statistics.median(clean)
        mad=statistics.median(abs(v-med) for v in clean)
        if mad<=math.radians(1.5) and abs(med)<=math.radians(3.44):
            estimated_bias_deg=round(math.degrees(med),3)
            proposed=round(-math.degrees(med),3)
    return dict(events=events,summary=dict(total_attempts=len(events),classifications=dict(Counter(e['classification'] for e in events)),
          candidate_count=len(clean),estimated_actual_minus_command_bias_degrees=estimated_bias_deg,
          proposed_command_compensation_degrees=proposed,
          caveat='Suggestions require video confirmation of SDK foot contact; never auto-applied. No simulator collision impulse data is exposed.'))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('files',nargs='+');ap.add_argument('-o','--output',default='kickoff_v35_report.json')
    args=ap.parse_args();rows=[]
    for filename in args.files:
        with open(filename,encoding='utf-8') as f:
            for line in f:
                try:
                    r=json.loads(line);r['_file']=Path(filename).name;rows.append(r)
                except json.JSONDecodeError:pass
    result=analyze(rows)
    Path(args.output).write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(result['summary'],indent=2,ensure_ascii=False))

if __name__=='__main__':main()
