# Booster WinterHack V37: export verified V37 telemetry only.
# Examples:
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\export_logs.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\export_logs.ps1 -Container "59d22f005598"
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\export_logs.ps1 -Container "59d22f005598" -LogDir "/custom/log/dir"
param(
    [string]$Container = "",
    [string]$LogDir = "/tmp/winterhack_v37",
    [string]$Destination = ""
)
$ErrorActionPreference = "Stop"
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw "Docker CLI not found." }
if (-not $Destination) { $Destination = Join-Path (Get-Location).Path ("wh37_logs_" + (Get-Date -Format "yyyyMMdd_HHmmss")) }
$Destination = [System.IO.Path]::GetFullPath($Destination)

# Autodiscovery scans running containers only; it does not guess from the current v37 folder.
if (-not $Container) {
    $running = @(docker ps --format '{{.Names}}')
    if ($LASTEXITCODE -ne 0) { throw "docker ps failed. Check that Docker Desktop is running." }
    $found = @()
    foreach ($name in $running) {
        if (-not $name) { continue }
        $cmd = "test -d '$LogDir' && ls '$LogDir'/wh37_*.jsonl* >/dev/null 2>&1"
        $null = docker exec $name sh -c $cmd 2>$null
        if ($LASTEXITCODE -eq 0) { $found += $name }
    }
    if ($found.Count -eq 0) {
        Write-Host "No running container currently has a wh37_*.jsonl file in $LogDir"
        Write-Host "Inspect running containers: docker ps --format '{{.ID}} {{.Names}} {{.Status}}'"
        Write-Host "To export from a stopped container, specify -Container <ID> (docker cp supports stopped containers)."
        Write-Host "If the agent uses WH_LOG_DIR, supply -LogDir <actual-directory>."
        throw "No V37 logs found. Run a V37 match and verify its runtime container first."
    }
    if ($found.Count -gt 1) {
        Write-Host "Multiple containers contain V37 logs: $($found -join ', ')"
        throw "Please specify -Container <name-or-ID> to avoid exporting an old match."
    }
    $Container = $found[0]
}

# Check container existence even if it is stopped (docker cp can access stopped containers).
$containerId = @(docker ps -a --filter "id=$Container" --format '{{.ID}}')
if (-not $containerId) {
    $containerId = @(docker ps -a --filter "name=$Container" --format '{{.ID}}')
}
if (-not $containerId) { throw "Container '$Container' was not found in docker ps -a." }

New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$source = "${Container}:${LogDir}/."
Write-Host "Exporting from $source"
docker cp $source $Destination
if ($LASTEXITCODE -ne 0) { throw "docker cp failed. Verify -Container and -LogDir." }
$logs = @(Get-ChildItem -Path $Destination -File | Where-Object { $_.Name -match '^wh37_.*\.jsonl(\.\d+)?$' })
if ($logs.Count -eq 0) { throw "Copied directory, but no wh37_*.jsonl files found. Check whether V37 telemetry ran." }
Write-Host "V37 log export successful from container: $Container"
$logs | Sort-Object LastWriteTime -Descending | Select-Object Name, LastWriteTime, Length | Format-Table -AutoSize
Write-Host "Saved to: $Destination"
Write-Host "File LastWriteTime is the last log write, NOT the export time."
