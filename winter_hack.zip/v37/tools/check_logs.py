"""python tools/check_logs.py <导出的日志目录或单个JSONL文件>"""
import json
from pathlib import Path
import sys

source = Path(sys.argv[1])
files = sorted(source.glob('*.jsonl*')) if source.is_dir() else [source]
rows = []
for file in files:
    for line in file.read_text(encoding='utf-8').splitlines():
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            print('Skipped incomplete line:', file.name)
rows.sort(key=lambda q: q['t'])
previous = {}
recoveries = 0
for row in rows:
    for group in ('robots', 'opponents'):
        for robot in row.get(group, []):
            key = (group, robot['id'])
            state = robot.get('penalty')
            if state and state != previous.get((key, 'penalty')):
                print(f"t={row['t']:.2f} {key}: penalty={state}, seconds={robot.get('penalty_seconds')}")
            previous[(key, 'penalty')] = state
            action = robot.get('action', '')
            if action in ('attack:unstick', 'attack:edge_recover') and action != previous.get((key, 'action')):
                print(f"t={row['t']:.2f} {key}: {action}, phase={row['phase']}")
                recoveries += 1
            previous[(key, 'action')] = action
if rows:
    last = rows[-1]
    print('frames=', len(rows), 'recovery entries=', recoveries)
    print('last state=', last.get('state'), 'stopped=', last.get('stopped'),
          'phase=', last.get('phase'), 'scores=', last.get('scores'))
else:
    print('No readable JSONL frames found')
print('Sampled diagnostics; recovery counts and kick requests are not verified contacts or shots.')
