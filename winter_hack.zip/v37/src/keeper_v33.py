"""Independent red goalkeeper geometry. No action selection or position commands for strikers.

All locations come from public game context. ``covered_by_forward`` means a
striker geometrically lies BETWEEN ball and own goal, not merely near the ball.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from .utils.geom import clamp
from .param import (
    KEEPER_ACTIVE_DISTANCE_FROM_GOAL_M, KEEPER_BLOCK_X_FROM_GOAL_M,
    KEEPER_HOME_X_FROM_GOAL_M, KEEPER_HOME_Y_LIMIT_M,
    KEEPER_LANE_BLOCK_WIDTH_M, KEEPER_PRESS_MAX_ADVANCE_M,
    KEEPER_PRESS_LATERAL_LIMIT_M, KEEPER_PRESS_MIN_BALL_GAP_M,
    KEEPER_PREDICT_MAX_SEC, KEEPER_PREDICT_URGENT_SEC,
    KEEPER_THREAT_SPEED_MPS, KEEPER_DANGER_NEAR_GOAL_M,
    KEEPER_OPP_FOOT_TRIGGER_M, KEEPER_OPP_SHOT_ZONE_M,
    KEEPER_V36_MIN_LEGAL_X_OFFSET_M, KEEPER_V36_RESCUE_BALL_X_M,
    KEEPER_V36_RESCUE_POST_MARGIN_M, KEEPER_V36_RESCUE_BACK_OFFSET_M,
    KEEPER_V36_RESCUE_LEAD_S,
    KEEPER_V37_PREVIEW_MAX_S, KEEPER_V37_INCOMING_MIN_MPS,
)


@dataclass(frozen=True)
class KeeperDecision:
    target: tuple[float, float]
    action: str
    dangerous: bool
    covered_by_forward: bool
    predicted_y: float | None
    shooting_lane: tuple[tuple[float, float], tuple[float, float]] | None


def segment_distance(point, a, b) -> tuple[float, float]:
    vx,vy=b[0]-a[0],b[1]-a[1]
    u=clamp(((point[0]-a[0])*vx+(point[1]-a[1])*vy)/max(vx*vx+vy*vy,1e-6),0.0,1.0)
    return math.hypot(point[0]-a[0]-u*vx,point[1]-a[1]-u*vy), u


def goalie_decision(ctx, velocity, forward_poses=()) -> KeeperDecision:
    gx=-ctx.field.length/2
    home_x=gx+KEEPER_HOME_X_FROM_GOAL_M
    ball=ctx.ball
    if ball is None:
        return KeeperDecision((home_x,0.0),'guard:home',False,False,None,None)
    b=(ball.x,ball.y)
    # A shot may aim at either goal corner: a striker covers the actual corridor
    # only if closer to the ball than the goalie and within a useful tube.
    goal=(gx,0.0)
    blocker=False
    for p in forward_poses:
        if p is None:continue
        d,u=segment_distance((p.x,p.y),b,goal)
        if 0.12 < u < 0.89 and d < KEEPER_LANE_BLOCK_WIDTH_M:
            blocker=True
            break
    vx,vy=velocity
    predicted_y=None
    imminent=False
    if vx < -KEEPER_THREAT_SPEED_MPS and ball.x > gx + 0.15:
        eta=(gx+KEEPER_BLOCK_X_FROM_GOAL_M-ball.x)/vx
        if 0.0 <= eta <= KEEPER_PREDICT_MAX_SEC:
            yy=ball.y+vy*eta
            if abs(yy) <= ctx.field.goal_width/2+0.35:
                predicted_y=yy
                imminent=eta < KEEPER_PREDICT_URGENT_SEC
    # V37 early predicted cross: V36 reacted too late (at t≈225-231) and
    # high lateral velocity commands did not translate to physical sideways
    # displacement. Start a heading-and-forward relocation from >3s away.
    early_y = None
    if vx < -KEEPER_V37_INCOMING_MIN_MPS and ball.x > gx + 0.26:
        t_cross = (gx + KEEPER_BLOCK_X_FROM_GOAL_M - ball.x) / vx
        if 0 < t_cross <= KEEPER_V37_PREVIEW_MAX_S:
            yy = ball.y + vy * t_cross
            if abs(yy) <= ctx.field.goal_width/2 + 0.32:
                early_y = clamp(yy, -KEEPER_HOME_Y_LIMIT_M, KEEPER_HOME_Y_LIMIT_M)
                predicted_y = yy
    # A long-distance, moving goal threat takes priority over stationary track,
    # but NOT over a ball that has already reached the mouth.
    # V36: rescue the goal MOUTH as soon as a live ball reaches its depth.
    # It outranks cover by a striker, static home position and ordinary pressing.
    # Command a point just behind the ball (own-goal side), but never outside
    # the field boundary. Once the ball has crossed the goal line it is too late.
    if (gx - 0.01 <= ball.x <= gx + KEEPER_V36_RESCUE_BALL_X_M
            and abs(ball.y) <= ctx.field.goal_width/2 + KEEPER_V36_RESCUE_POST_MARGIN_M):
        target_x=clamp(ball.x-KEEPER_V36_RESCUE_BACK_OFFSET_M,
                       gx+KEEPER_V36_MIN_LEGAL_X_OFFSET_M,home_x)
        target_y=clamp(ball.y+vy*KEEPER_V36_RESCUE_LEAD_S,
                       -KEEPER_HOME_Y_LIMIT_M,KEEPER_HOME_Y_LIMIT_M)
        return KeeperDecision((target_x,target_y),'guard:mouth_rescue',True,
                              blocker,predicted_y,(b,goal))
    if (early_y is not None and not imminent
            and ball.x > gx + 2.0):
        return KeeperDecision((home_x,early_y),'guard:early_cross',True,
                              blocker,predicted_y,(b,goal))
    opponent_ready = (ball.x <= gx + KEEPER_OPP_SHOT_ZONE_M and
                      abs(ball.y) <= ctx.field.goal_width/2+0.50 and
                      any(r.pose is not None and math.hypot(r.pose.x-ball.x, r.pose.y-ball.y)
                          <= KEEPER_OPP_FOOT_TRIGGER_M for r in ctx.opponents.values()))
    danger=(ball.x <= gx + KEEPER_ACTIVE_DISTANCE_FROM_GOAL_M
            or (predicted_y is not None and ball.x <= gx + KEEPER_ACTIVE_DISTANCE_FROM_GOAL_M+1.25))
    # Block/track quietly outside the danger zone, but don't freeze near goal.
    if not danger:
        yy=clamp(ball.y*KEEPER_HOME_X_FROM_GOAL_M/max(ball.x-gx,0.4),
                 -KEEPER_HOME_Y_LIMIT_M, KEEPER_HOME_Y_LIMIT_M)
        return KeeperDecision((home_x,yy),'guard:track',False,blocker,predicted_y,(b,goal))
    # Urgent incoming shot, striker already intercepting, or ball behind goalie:
    # protect the goal line rather than rushing toward the opponent's foot.
    if imminent or opponent_ready or blocker or ball.x <= gx+KEEPER_DANGER_NEAR_GOAL_M:
        goal_y=(predicted_y if predicted_y is not None else
                ball.y*KEEPER_HOME_X_FROM_GOAL_M/max(ball.x-gx,0.2))
        yy=clamp(goal_y,-KEEPER_HOME_Y_LIMIT_M,KEEPER_HOME_Y_LIMIT_M)
        action=('guard:urgent_block' if imminent else 'guard:opp_winding_up' if opponent_ready
                else 'guard:covered_line' if blocker else 'guard:goal_mouth')
        # If the ball slipped behind the home line inside the mouth, retreat
        # just short of the goal net instead of staying in front of the ball.
        ret_x = home_x
        if ball.x < home_x-0.10 and abs(ball.y) < ctx.field.goal_width/2+0.12:
            ret_x = clamp(ball.x+0.10,gx+0.22,home_x)
            action='guard:recover_mouth'
        return KeeperDecision((ret_x,yy),action,True,blocker,predicted_y,(b,goal))
    # No striker covering the line: step toward ball and occupy shot corridor,
    # not the sideline! The goalie never chases past the ball or too far from goal.
    max_x=min(gx+KEEPER_PRESS_MAX_ADVANCE_M,ball.x-KEEPER_PRESS_MIN_BALL_GAP_M)
    approach=max(0.0, min(1.4,(ball.x-home_x)*0.43))
    tx=clamp(home_x+approach,gx+KEEPER_HOME_X_FROM_GOAL_M,max(max_x,gx+KEEPER_HOME_X_FROM_GOAL_M))
    if predicted_y is not None:
        # A moving ball going to goal overrides stationary positioning.
        ty=predicted_y
    else:
        ty=ball.y*(tx-gx)/max(ball.x-gx,0.20)
    ty=clamp(ty,-KEEPER_PRESS_LATERAL_LIMIT_M,KEEPER_PRESS_LATERAL_LIMIT_M)
    return KeeperDecision((tx,ty),'guard:step_block',True,False,predicted_y,(b,goal))
