"""集中调参入口。

这里放策略、走位、踢球和避障的可调参数。数值迁移自当前代码文件,
以后优先在本文件调整参数。
"""

from __future__ import annotations

import math


# ======================================================================
# 踢球力度
# ======================================================================

# Player.kick() 会把力度夹到这个范围内。如果超过范围，因为控制接口不支持，可能会摔倒。
KICK_POWER_MIN = 1.0
KICK_POWER_MAX = 10.0

# 普通比赛踢球力度。
KICK_POWER_DEFAULT = 4.0
KICK_POWER_BACKFIELD = 4.0
KICK_POWER_OUR_KICKOFF = 10.0  # direct-shot kickoff; separate from ordinary match shots


# ======================================================================
# Player 走位控制
# ======================================================================

ARRIVE_DIST = 0.15             # 到达目标点阈值 (m)
OMNI_DIST = 1.0                # 距目标小于该值时使用全向近距控制
TURN_THRESHOLD = 0.5           # 远距离行走时,角差超过该值先原地转向 (rad)
MAX_LINEAR = 2.0               # 指令前进速度上限 (m/s)
MAX_ANGULAR = 2.0              # 指令转向速度上限 (rad/s)
LINEAR_GAIN = 2.5              # 平移 P 增益
ANGULAR_GAIN = 3.0             # 转向 P 增益


# ======================================================================
# Player 踢球 / 射门规划
# ======================================================================

KICK_ENTER_M = 0.53             # 距球小于该值才交给 SDK 踢球
KICK_EXIT_M = 0.72              # 踢球中距球大于该值才退出踢球状态
CHASE_BEHIND_M = 0.35          # 追球时站到球后方的距离


# ======================================================================
# Player 技术动作参数：守门 / 支援 
# ======================================================================

GUARD_FACE_BALL = True
GUARD_THREAT_ENTER_X = -1.0
GUARD_THREAT_EXIT_X = -0.7

SUPPORT_DIST_M = 3.0

# ======================================================================
# Normal 阶段策略
# ======================================================================

ATTACKER_KEEP_ETA_MARGIN_SEC = 0.25  # 到球时间相近时保留当前抢球队员

FALLEN_COST = 10.0  # 摔倒球员的距离惩罚值(米)


# ======================================================================
# 开球 / 定位球策略
# ======================================================================

# 开球
KICKOFF_STAGE_M = 2.0
KICKOFF_FRONT_MARGIN = 0.1
KICKOFF_LATERAL_TOL = 0.35

CENTER_LEAVE_DIST_M = 0.15 # 球离开中心点多少距离，认为球已经动了

OPP_SET_WALL_DIST_M = 2.0 # 对方开球时，在多少距离之后阻挡


# ======================================================================
# 站位 / 避让
# ======================================================================

OPPONENT_RESTART_AVOID_M = 1.65
CIRCLE_MARGIN_M = 0.3


# ======================================================================
# 踢球目标几何
# ======================================================================

GOAL_TARGET_DEPTH_M = 0.25              # 踢球目标点在球门内的深度 (m)

# ======================================================================
# 障碍物几何参数
# ======================================================================

BALL_OBSTACLE_RADIUS = 0.5              # 球的障碍半径 (m)；用于避障计算
OPPONENT_RADIUS = 0.55                  # 对手机器人半径 (m)
TEAMMATE_RADIUS = 0.48                  # 队友机器人半径 (m)
SAFETY_MARGIN = 0.22                    # 通用安全余量 (m)

GOAL_DEPTH = 0.6                        # 球门深度 (m)；用于球门障碍建模
POST_RADIUS = 0.18                      # 门柱半径 (m)
NET_RADIUS = 0.20                       # 球网半径 (m)
NET_STEP = 0.35                         # 球网离散化步长 (m)

START_IGNORE = 0.0                      # 起点忽略半径 (m)；起点附近障碍不参与规划
TARGET_IGNORE = 0.0                     # 终点忽略半径 (m)；终点附近障碍不参与规划

# ======================================================================
# 全局路径规划器 (A* Grid Planner)
# ======================================================================

USE_GLOBAL_PATH_PLANNER = True          # 是否启用全局规划器；False 时回退到局部 VFH
GLOBAL_GRID_RESOLUTION_M = 0.35         # 栅格分辨率 (m/格)；越小路径越精细，但计算量越大
GLOBAL_FIELD_MARGIN_M = 0.30            # 场地边界外扩余量 (m)；确保边界附近路径可行
GLOBAL_OBSTACLE_MARGIN_M = 0.10         # 障碍物膨胀余量 (m)；在障碍半径上额外扩大多少
GLOBAL_PATH_LOOKAHEAD_M = 0.9           # 从规划路径中提取前方多远的路径点 (m)

# ======================================================================
# 局部路径规划器 (VFH Direction Scan)
# ======================================================================

PLAN_LOOKAHEAD = 1.2                    # 前方探测射线长度 (m)；规划器"看"的范围
PLAN_CLEARANCE = 0.35                   # 最小安全余量 (m)；候选方向前方必须大于此值
PLAN_STEP = math.radians(15)            # 候选方向扫描步长 (rad)；越小方向越精细
PLAN_MAX_OFFSET = math.pi     # 最大偏离目标方向的角度 (rad)；全周扫描供边界脱困

# ======================================================================
# 可视化
# ======================================================================

KICK_TARGET_MARK_SIZE_M = 0.18

# V19 简洁策略；均为待实战校准的策略值，并非 SDK/物理常数。
KEEPER_ID = 2
INTERCEPT_SPEED_MPS = 1.2       # ETA 估计速度，不代表实际速度上限
BALL_PREDICT_SEC = 1.2          # 只做短时匀速外推
SHOT_RANGE_M = 7.1
KICK_LANE_CLEARANCE_M = 0.65
KICK_PLAN_HOLD_SEC = 0.45       # 短时固定意图，减少踢球中途换目标
KICKOFF_FORWARD_M = 0.55
KICKOFF_SOUTH_M = 1.20

# V20：PDF 的实验结论是三档动作，并非连续力度。
KICK_SHORT = 1.5              # <2：短传/调整
KICK_LONG = 4.0               # 2..5：长传/近射
KICK_HARD = 8.0               # 实射/紧急解围的强力档，不用于一般传球
FIELD_WALK_MARGIN_M = 0.22
KICK_NO_PROGRESS_SEC = 3.0
KICK_RETRY_SEC = 0.7
NAV_NO_PROGRESS_SEC = 1.5
GLOBAL_REPLAN_SEC = 0.6
DANGER_ZONE_X = -2.5
ATTACK_ZONE_X = 2.5
ZONE_HYSTERESIS_M = 0.3

GLOBAL_PLAN_BUDGET_SEC = 0.004  # A* 每次搜索预算4ms；超时退回局部避障

# V22: 指令上限不变，回防大于减速区时用满速度。
RESTART_OUTSIDE_M = 0.8
APPROACH_OFFSET_M = 0.28
BALL_REPLAN_M = 0.12
RECOVER_BRAKE_M = 0.6
SHOT_POWER = 8.0    # V34: 半场内有机会的射门使用高功率档8；开球仍独立10
CLEAR_POWER = 4.0   # 一般解围/推进仍是长传档；我方半场危险解围另用8

# V23: 中路优先、正常活球可出线处理；不是裁判规则常数。
PLAY_OUTSIDE_M = 0.8
ORBIT_RADIUS_M = 0.46
ORBIT_BALL_KEEP_M = 0.34
ORBIT_STEP_RAD = 0.45

ALLOW_PLAY_OUTSIDE = False  # V34: 禁止主动出界，减少离场判罚风险

KEEPER_EMERGENCY_REACH_M = 0.9

# V24: 录像指出的射偏/控球/重叠站位参数；未经实战标定。
SHOT_POST_MARGIN_M = 0.45
SHOT_CLEARANCE_M = 0.55
CONTROL_PREDICT_SEC = 0.25

# V25: 两前锋动态压迫、门前解围与快速射门；现场表现仍需仿真校准。
SHOT_MIN_X_M = 0.6          # 真正射门的最低前场位置，避免太远处盲射
PRESS_OPPONENT_NEAR_M = 1.35
PRESS_BACKWARD_VX_MPS = 0.3
PRESS_DEFENSIVE_X_M = -0.6
PRESS_PREDICT_MAX_SEC = 0.42
PRESS_SIDE_OFFSET_M = 0.33 # 轻微错位逼抢，不返回防守槽
PRESS_TRAILING_OFFSET_M = 0.12
KEEPER_CLAIM_MAX_X_M = 1.85 # 从本方门线起可离门的距离上限
KEEPER_MIN_X_M = 0.27
KEEPER_CLAIM_LATERAL_M = 0.75
KEEPER_CLAIM_REACH_M = 1.65
KEEPER_CLAIM_BALL_SPEED_MPS = 2.1
KEEPER_ETA_ADVANTAGE_SEC = 0.18
KEEPER_PRESS_FORWARD_M = 1.0
KEEPER_PRESS_SIDE_M = 0.75
FAST_KICK_DISTANCE_M = 0.64
FAST_KICK_LATERAL_M = 0.39
FAST_APPROACH_OFFSET_M = 0.17

# V31: 视频/日志反馈。力度在 Booster SDK 中选择动作档位，并非连续加倍距离。
KICKOFF_FORWARD_M = 1.10             # 历史参数，V32 开球不再读取
KICKOFF_SOUTH_M = 2.40                # 历史参数，V32 开球不再读取
KICKOFF_RECEIVER_X = -0.55
KICKOFF_RECEIVER_Y = -1.95
KICKOFF_RUN_AHEAD_M = 1.3
KICKOFF_FOLLOW_SEC = 3.2
KICKOFF_MOVE_CONFIRM_M = 0.40

SHOT_MIN_X_M = -0.25                # 中路清晰、有角度即启动 power=10
SHOT_RANGE_M = 8.6
SHOT_CLEARANCE_M = 0.43
SHOT_LANE_URGENCY_M = 0.44
RECEIVE_HOLD_MAX_SEC = 1.35         # 接传球前短暂等球，不无条件返回支援槽
RECEIVE_BALL_NEAR_M = 0.90
RECEIVE_PASS_ALIGN_COS = 0.38
RECEIVE_EXPECTED_MAX_M = 4.4

KEEPER_BLOCK_X_FROM_GOAL_M = 0.72   # 常态封堵线，降低前冲后被打身后的概率
KEEPER_MAX_ADVANCE_FROM_GOAL_M = 1.07
KEEPER_PREPARE_RANGE_X_M = 3.5
KEEPER_THREAT_SPEED_MPS = 0.28
KEEPER_PREDICT_MAX_SEC = 3.5
KEEPER_SAFE_TOUCH_M = 0.60
KEEPER_DANGER_CLEAR_DIST_M = 0.95
KEEPER_CLAIM_REACH_M = 1.35
KEEPER_CLAIM_MAX_X_M = 1.85
KICK_FOOT_LATERAL_REACH_M = 0.52
KICK_FOOT_FORWARD_REACH_M = 0.84
KICK_FOOT_BACKWARD_TOL_M = 0.15
FAST_KICK_FRONT_ALLOW_M = 0.24


# V32: direct goal-mouth kickoffs / keeper central safety / angle-verified shots.
# The field half-length and goal width come from ctx.field, not these constants.
KICKOFF_CORNER_POST_MARGIN_M = 0.46  # center aims ~+/-0.84m on the x=7 goal line
KICKOFF_DIRECT_ENTER_M = 0.77
KICKOFF_STAGE_BEHIND_M = 0.44
KICKOFF_DIRECT_MAX_SEC = 3.3
KICKOFF_TOTAL_MAX_SEC = 8.5
KICKOFF_ONE_RETRY_AT_SEC = 3.4
KICKOFF_ONE_RETRY_SEC = 1.25
KICKOFF_SHOOT_POWER = 10.0
SHOT_DIRECTION_TOL_RAD = 0.034  # geometric robustness, not a guaranteed SDK error bound
SHOT_MIN_OPEN_ANGLE_RAD = 0.029
KEEPER_HOME_X_FROM_GOAL_M = 0.43
KEEPER_HOME_Y_LIMIT_M = 0.95
KEEPER_WIDE_BALL_Y_M = 1.42
KEEPER_WIDE_CLAIM_DIST_M = 0.68
KEEPER_WIDE_CLAIM_X_MAX_M = 0.97
KEEPER_PREVENT_PRESS_M = 0.95
KEEPER_GUARD_MAX_ANGULAR = 2.4
KEEPER_CLEAR_FORWARD_X_M = 2.9
KEEPER_CLEAR_SIDE_X_M = 2.5
KEEPER_CLEAR_SIDE_Y_M = 3.5
KEEPER_CLEAR_LANE_MIN_M = 0.70


# V33: goalie is an independent control system. Relative distance = 1/4 pitch
# measured FROM OUR GOAL LINE along x (7-3.5=-3.5 in the red field).
KEEPER_ACTIVE_DISTANCE_FROM_GOAL_M = 3.50
KEEPER_PRESS_MAX_ADVANCE_M = 1.50
KEEPER_PRESS_MIN_BALL_GAP_M = 0.32
KEEPER_PRESS_LATERAL_LIMIT_M = 1.13
KEEPER_LANE_BLOCK_WIDTH_M = 0.64
KEEPER_PREDICT_URGENT_SEC = 0.9
KEEPER_DANGER_NEAR_GOAL_M = 0.78
KEEPER_FACE_NEAR_GOAL_M = 0.82
KEEPER_ACTIVE_HOME_BIAS = 0.15
KEEPER_ENGAGE_POS_GAIN = 4.7
KEEPER_ADVANCE_RATE = 0.40
KEEPER_HOME_Y_MOVING_FACTOR = 0.38
FORWARD_SEPARATION_M = 1.55
FORWARD_SUPPORT_SIDE_M = 1.60
FORWARD_SUPPORT_LEAD_M = 1.60
KICKOFF_GOAL_Y_M = 1.0
KICKOFF_AIM_ERROR_RESERVE_M = 0.15  # target +/-1.0 leaves 0.3m geometric goal margin

KICKOFF_FACE_TOL_RAD = 0.19    # heading alignment before direct-power kick; never enter orbit

# V34 near-ball controlled strike. All thresholds are hypotheses for real-match validation.
SHOT_NEAR_BALL_ENTER_M = 0.54        # regular shot SDK engagement only within 54cm
SHOT_BODY_FORWARD_MIN_M = -0.09     # ball should not be significantly behind kicking feet
SHOT_BODY_FORWARD_MAX_M = 0.60
SHOT_BODY_LATERAL_MAX_M = 0.35
SHOT_STABLE_HEADING_RAD = 0.36      # don't begin a powerful kick sideways relative to torso
SHOT_ALIGN_MAX_YAW_RAD_S = 1.6      # align smoothly, without running during pre-shot
SHOT_REPLAN_BALL_MOVED_M = 0.055    # recompute goal direction on small live ball movements
SHOT_PLAN_MAX_HOLD_SEC = 0.14
SHOT_GOAL_ERROR_RAD = 0.018         # conservative angular deviation budget; not SDK guarantee
SHOT_GOAL_POST_EXTRA_M = 0.03
KEEPER_OPP_FOOT_TRIGGER_M = 0.92    # opponent near ball => shooting imminent; keep blocking lane
KEEPER_OPP_SHOT_ZONE_M = 4.2
KEEPER_DANGER_KICK_REACH_M = 0.70
KEEPER_SAFE_LINE_BIAS_M = 0.10
CLEAR_IN_OUR_HALF_POWER = 8.0

# Calibrate ONLY from independently confirmed clean contacts, never from a stalled SDK
# command, deflection, opponent touch or a ball going backwards. See tools/shot_calibration.py.
SHOT_EMPIRICAL_BIAS_RAD = 0.0  # actual_launch_angle - sdk_command; >0 means drifts to +Y
SHOT_BIAS_MAX_RAD = 0.060     # guardrail for manually importing a validated correction
ATTACKER_FOOT_CONTROL_BONUS_SEC = 0.16
ATTACKER_BALL_BEHIND_COST_SEC = 0.31
ATTACKER_ATTACK_SIDE_COST_SEC = 0.22
KEEPER_OPP_LANE_HOLD_MAX_FORWARD_M = 0.88

SHOT_MAX_ENTRY_RUNNING_SPEED_MPS = 1.45 # estimated displacement speed; don't start power kick during max sprint


# V35 contact-controlled kickoff: dimensions and time constants are calibration
# hypotheses (not documented SDK internal thresholds). Check real match logs.
KICKOFF_V35_CONTACT_MIN_M = 0.19
KICKOFF_V35_CONTACT_MAX_M = 0.72  # V36: restored the earlier direct-shot SDK engagement envelope
KICKOFF_V35_STAGE_M = 0.55  # stage directly behind ball; avoid body shoving
KICKOFF_V35_LATERAL_MAX_M = 0.24
KICKOFF_V35_YAW_ERROR_MAX_RAD = 0.21
KICKOFF_V35_ENTRY_SPEED_MAX_MPS = 1.05  # allow early SDK takeover after aligned approach
KICKOFF_V35_BRAKE_TIME_S = 0.16
KICKOFF_V35_SDK_MIN_HOLD_S = 0.72
KICKOFF_V35_SDK_ATTEMPT_S = 2.15  # do not cancel full automatic kick too early
KICKOFF_V35_RETRY_LIMIT = 1
KICKOFF_V35_VERIFIED_SPEED_MPS = 1.8
KICKOFF_V35_VERIFIED_MOVE_M = 0.18
KICKOFF_V35_CLEAN_ANGLE_MAX_RAD = 0.19
KICKOFF_V35_MAX_STALE_BALL_S = 0.30
KICKOFF_V35_RESTAGE_TIMEOUT_S = 1.15
KICKOFF_V35_TOTAL_LIMIT_S = 9.0
# A separately validated empirical bias can be applied here; 0 is intentional.
# Bias convention: measured exit angle MINUS SDK commanded world angle.
KICKOFF_EMPIRICAL_BIAS_RAD = 0.0
KICKOFF_BIAS_MAX_RAD = 0.060

# V36 keeper legal goal-line intervention and quick opponent-pressure toe poke.
# Player center remains inside the field; entering the net risks LEAVING_THE_FIELD.
KEEPER_V36_MIN_LEGAL_X_OFFSET_M = 0.15
KEEPER_V36_RESCUE_BALL_X_M = 0.88
KEEPER_V36_RESCUE_POST_MARGIN_M = 0.12
KEEPER_V36_RESCUE_LEAD_S = 0.25
KEEPER_V36_RESCUE_BACK_OFFSET_M = 0.13
KEEPER_V36_CLEAR_TIMEOUT_S = 1.05
PRESS_V36_POKE_OPPONENT_M = 0.95
PRESS_V36_POKE_BALL_MAX_M = 0.50
PRESS_V36_POKE_BODY_FRONT_MIN_M = 0.07
PRESS_V36_POKE_BODY_FRONT_MAX_M = 0.52
PRESS_V36_POKE_BODY_LATERAL_M = 0.24
PRESS_V36_POKE_POWER = 1.5
PRESS_V36_POKE_X_LIMIT_M = -5.0  # do not blindly poke near our goal
PRESS_V36_POKE_LEASE_S = 0.78

# V37 referee-first and observed-locomotion control (engineering safeguards).
RESTART_V37_CLEARANCE_M = 2.30  # > observed 1.65m legacy buffer, includes extra safety
RESTART_V37_FIELD_MARGIN_M = 0.53 # keeps robot centers away from touchline
RESTART_V37_PANIC_RADIUS_M = 2.42
RESTART_V37_HOLD_EPS_M = 0.10
KEEPER_V37_PREVIEW_MAX_S = 5.4   # anticipate goal-line crossing before close-range danger
KEEPER_V37_INCOMING_MIN_MPS = 0.33
KEEPER_V37_SWEEP_Y_MIN_M = 0.11
KEEPER_V37_FRONT_SPEED_MPS = 1.4
KEEPER_V37_TURN_ONLY_RAD = 0.66  # turn and walk forward; lateral gait underperforms in V36 log
KEEPER_V37_CRITICAL_DANGER_M = 1.35
KEEPER_V37_CLEAR_LEASE_UNDER_THREAT_S = 0.32
KEEPER_V37_CLEAR_CONTACT_MAX_M = 0.64
SHOT_V37_GOALLINE_MARGIN_M = 0.26
