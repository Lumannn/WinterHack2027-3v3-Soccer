"""5 Hz JSONL 诊断，不把指令当成实测；文件初始化失败则关闭诊断。"""
import json
import logging
import math
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
from .param import SHOT_EMPIRICAL_BIAS_RAD, RESTART_V37_CLEARANCE_M

_log = logging.getLogger(__name__)


def record_frame(ctx, players, store):
    if getattr(store, 'telemetry_failed', False):
        return
    finished = ctx.game is not None and ctx.game.state.value == 'FINISHED'
    if finished and getattr(store, 'telemetry_finished', False):
        return
    if not finished:
        store.telemetry_finished = False
    signature = (store.cur_phase.value, tuple((p.id, p.is_kicking, p.penalty.value) for p in players))
    changed = signature != getattr(store, 'telemetry_signature', None)
    last = getattr(store, 'telemetry_time', None)
    # At 5 Hz the actual contact transient (<100 ms) can be missed entirely.
    # Record kickoff near 30 Hz while SDK is active; normal play stays 5 Hz.
    high_rate = store.cur_phase.value in ('our_kickoff','opp_kickoff','opp_set_play') or any(
        (p.action in ('attack:shoot','attack:goal_line_drive') and p.is_kicking) or
        p.action in ('guard:mouth_rescue','guard:emergency_clear','guard:clear_lease')
        for p in players)
    period = 0.031 if high_rate else 0.10
    if not changed and last is not None and 0 <= ctx.now - last < period:
        return
    if not hasattr(store, 'telemetry_logger'):
        try:
            directory = Path(os.environ.get('WH_LOG_DIR', '/tmp/winterhack_v37'))
            directory.mkdir(parents=True, exist_ok=True)
            path = directory / f'wh37_{os.getpid()}.jsonl'
            logger = logging.Logger(f'wh36.{os.getpid()}')
            logger.addHandler(RotatingFileHandler(path, maxBytes=12_000_000, backupCount=4, encoding='utf-8'))
            store.telemetry_logger = logger
            store.telemetry_previous = {}
            _log.info('V37 JSONL log: %s', path)
        except OSError as exc:
            store.telemetry_failed = True
            _log.warning('V36 telemetry disabled: %s', exc)
            return
    rows = []
    for p in players:
        pose = p.pose
        previous = store.telemetry_previous.get(p.id)
        observed = None
        robot = ctx.teammates.get(p.id)
        stamp = robot.last_seen_at if robot else ctx.now
        if pose and previous and 0.01 < stamp - previous[0] <= 0.6:
            obs_dt = stamp - previous[0]
            delta = (pose.x - previous[1], pose.y - previous[2])
            if delta[0] ** 2 + delta[1] ** 2 <= (12 * obs_dt) ** 2:
                observed = (delta[0] / obs_dt, delta[1] / obs_dt)
        store.telemetry_previous[p.id] = (stamp, pose.x, pose.y) if pose else None
        hit_y = None
        shot_safe = None
        if p.kick_command is not None and ctx.ball is not None:
            direction = p.kick_command[0]
            dx = math.cos(direction)
            if dx > 0.00001 and ctx.ball.x < ctx.field.length/2:
                hit_y = ctx.ball.y + math.sin(direction)*(ctx.field.length/2-ctx.ball.x)/dx
                from .param import SHOT_POST_MARGIN_M
                shot_safe = abs(hit_y) < ctx.field.goal_width/2-SHOT_POST_MARGIN_M
        rows.append(dict(id=p.id, action=p.action, pose=(pose.x, pose.y, pose.theta) if pose else None,
                         penalty=p.penalty.value,
                         penalty_seconds=(ctx.game.get_player_state(ctx.team_id, p.id).secs_till_unpenalised
                                          if ctx.game and ctx.game.get_player_state(ctx.team_id, p.id) else None),
                         mode=p.mode, navigation=p.navigation,
                         kickoff_contact_state=getattr(p,'_ko35_mode',None),
                         kickoff_contact_event=getattr(p,'_ko35_event',None),
                         kickoff_sdk_started=getattr(p,'_ko35_sdk_started',None),
                         kickoff_attempts=getattr(p,'_ko35_attempts',None),
                         kickoff_verified=getattr(p,'_ko35_verified',None),
                         kickoff_launch_speed=getattr(p,'_ko35_launch_speed',None),
                         kickoff_launch_error_rad=getattr(p,'_ko35_launch_error_rad',None),
                         kickoff_command_heading=getattr(p,'_ko35_command_heading',None),
                         kickoff_observed_body_speed=getattr(p,'_ko35_motion_speed',None),
                         keeper_decision=getattr(p,'keeper_decision',None),
                         distance_to_ball=(math.hypot(pose.x-ctx.ball.x,pose.y-ctx.ball.y)
                                           if pose is not None and ctx.ball is not None else None),
                         restart_clearance_target=(math.hypot(p.target[0]-ctx.ball.x,p.target[1]-ctx.ball.y)
                                                   if p.target is not None and ctx.ball is not None else None),
                         restart_current_clearance=(math.hypot(pose.x-ctx.ball.x,pose.y-ctx.ball.y)
                                                    if pose is not None and ctx.ball is not None else None),
                         restart_required_clearance=(RESTART_V37_CLEARANCE_M
                                                     if store.cur_phase.value == 'opp_set_play' else None),
                         keeper_line_covered=getattr(p,'keeper_line_covered',None),
                         fall_down_state=p.fall_down_state,
                         foot_side_hint=getattr(p,'foot_side_hint',None),
                         shot_preparation_speed_estimate=getattr(p,'shot_preparation_speed_estimate',None),
                         shot_calibration_bias_rad=(SHOT_EMPIRICAL_BIAS_RAD if p.action == 'attack:shoot' else None),
                         kick_direction_body=(None if p.kick_command is None or p.pose is None else
                             (p.kick_command[0]-p.pose.theta+math.pi)%(2*math.pi)-math.pi),
                         target=p.target, aim_target=getattr(p, "aim_target", None), velocity_command_body=p.desired_velocity,
                         observed_velocity_world=observed, kick_command_world=p.kick_command,
                         kick_contact_distance=(math.hypot(pose.x-ctx.ball.x, pose.y-ctx.ball.y)
                             if pose is not None and ctx.ball is not None else None),
                         kick_contact_body=(
                             ((ctx.ball.x-pose.x)*math.cos(pose.theta)+(ctx.ball.y-pose.y)*math.sin(pose.theta),
                              -(ctx.ball.x-pose.x)*math.sin(pose.theta)+(ctx.ball.y-pose.y)*math.cos(pose.theta))
                             if pose is not None and ctx.ball is not None else None),
                         shot_heading_error=(
                             (p.kick_command[0]-pose.theta+math.pi)%(2*math.pi)-math.pi
                             if p.kick_command is not None and pose is not None else None),
                         kick_requested=p.is_kicking,
                         backend_kicking=getattr(p._backend, '_kicking', None),
                         predicted_goal_line_y=hit_y, geometric_goal_window=shot_safe))
    store.telemetry_time = ctx.now
    store.telemetry_signature = signature
    opponents = []
    team = next((t for t in ctx.game.teams if t.team_number != ctx.team_id), None) if ctx.game else None
    for pid, q in ctx.opponents.items():
        status = ctx.game.get_player_state(team.team_number, pid) if team else None
        opponents.append(dict(id=pid, pose=(q.pose.x, q.pose.y, q.pose.theta) if q.pose else None,
                              penalty=status.penalty.value if status else None,
                              penalty_seconds=status.secs_till_unpenalised if status else None))
    entry = dict(version='V37-referee-first-preemptive-keeper', t=ctx.now, phase=store.cur_phase.value,
                 team_id=ctx.team_id, scores={t.team_number: t.score for t in ctx.game.teams} if ctx.game else {},
                 seconds_remaining=ctx.game.secs_remaining if ctx.game else None,
                 state=ctx.game.state.value if ctx.game else None,
                 stopped=ctx.game.stopped if ctx.game else None,
                 set_play=ctx.game.set_play.value if ctx.game else None,
                 referee_owner_verified=(ctx.game.kicking_team == ctx.team_id if ctx.game else None),
                 dangerous_goal_line_prediction=(
                     (ctx.ball.y + store.ball_velocity[1]*((-ctx.field.length/2+0.4-ctx.ball.x)/store.ball_velocity[0]))
                     if (ctx.ball is not None and store.ball_velocity[0] < -0.15
                         and ctx.ball.x > -ctx.field.length/2+0.4) else None),
                 secondary_time=ctx.game.secondary_time if ctx.game else None,
                 kicking_team=ctx.game.kicking_team if ctx.game else None,
                 opponents=opponents,
                 ball=(ctx.ball.x, ctx.ball.y) if ctx.ball else None,
                 ball_last_seen_at=(ctx.ball.last_seen_at if ctx.ball else None),
                 ball_velocity_estimate=store.ball_velocity, robots=rows,
                 kickoff_aim=getattr(store,'kickoff_aim',None),
                 kickoff_elapsed=(max(0.0,ctx.now-store.kickoff_started_at)
                                  if getattr(store,'kickoff_started_at',None) is not None
                                     and store.cur_phase.value == 'our_kickoff' else None))
    store.telemetry_logger.info(json.dumps(entry, ensure_ascii=False))
    store.telemetry_finished = finished
