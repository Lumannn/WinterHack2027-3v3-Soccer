"""Player:单个机器人的控制 handle —— 用户可直接编辑这个类。

平台原语(set_velocity / kick / release_kick / request_mode / get_up)委托给注入的
``_backend``(framework 层);状态 property(pose / mode / is_fallen / penalty)从
``self.context`` 或 backend 读。

走位行为(walk_to / face_to / ensure_ready)也是 Player 方法:它们本质是"对本
球员下命令的动词",且未来加迟滞/避障需要的跨帧状态可直接挂 ``self``。纯坐标计算
(dist / angle_to / 球门坐标等)才放 utils/geom。

实例跨整场比赛存活;``self.context`` 每帧被框架覆写。用户想加自己的拐棍方法直接
在这里加。
"""

from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING

from .framework.types import Context, Penalty, Pose2D, GameState, SetPlay
from .framework import debugdraw

from .param import *
from .utils.geom import (
    angle_to,
    clamp,
    dist,
    normalize_angle,
    opponent_goal,
    own_goal,
    own_goal_area_center,
)
from .tactics import inside, intercept, keeper_target, lane_clearance, legal_walk_point, goal_gap_target, defensive_cover
from .utils.obstacles import collect_obstacles, Obstacle
from .utils.path_planner import plan_global_path

if TYPE_CHECKING:
    from .framework.config import SoccerConfig


__all__ = ["Player"]


_log = logging.getLogger(__name__)

def _heading_clearance(
    px: float, py: float, heading: float, obstacles: list, lookahead: float = PLAN_LOOKAHEAD,
) -> float:
    """用于局部避障。沿 (px,py) 朝 ``heading`` 的 lookahead 射线,到最近障碍的余量(dist - radius)。

    只考虑**前方**(投影 t>0)的障碍;身后 / 侧后的障碍不挡这个方向,跳过——否则贴近
    任何障碍(哪怕正后方)都会把所有方向的余量拉低,误判"全堵"。
    无障碍返回 inf;越大越空,负值表示会撞。
    """
    ux, uy = math.cos(heading), math.sin(heading)
    min_clear = math.inf
    for obs in obstacles:
        t = (obs.x - px) * ux + (obs.y - py) * uy
        if t <= 0.0:
            continue                      # 障碍在身后/侧后,不挡此方向
        if t > lookahead:
            t = lookahead
        nx, ny = px + ux * t, py + uy * t
        clear = math.hypot(obs.x - nx, obs.y - ny) - obs.radius + PLAN_CLEARANCE - obs.clearance
        if clear < min_clear:
            min_clear = clear
    return min_clear


def _behind_ball(
    ball_x: float, ball_y: float, aim: tuple[float, float], offset: float,
) -> tuple[float, float]:
    """用于计算站位。球在 球→``aim`` 连线上的"后方"点:从球沿【背离 aim】方向退 ``offset`` 米。

    追球走位目标用它:球落在机器人与 ``aim`` 之间,到位时天然对准 aim 方向。
    aim 与球重合(退化)时,方向不定,直接返回球位。
    """
    dx, dy = aim[0] - ball_x, aim[1] - ball_y
    d = math.hypot(dx, dy)
    if d < 1e-6:
        return (ball_x, ball_y)
    ux, uy = dx / d, dy / d              # 球指向 aim 的单位向量
    return (ball_x - ux * offset, ball_y - uy * offset)   # 背离 aim 退 offset


class Player:
    """单个球员的 handle。可以在这里加入新的技术动作。
    """

    def __init__(
        self,
        player_id: int,
        config: "SoccerConfig",
        _backend: object | None,
    ) -> None:
        self.id: int = player_id
        self.config: "SoccerConfig" = config
        self._backend = _backend           # 机器人控制接口的包装，通常不用改
        self.context: Context | None = None

        # 当前高层动作名(仅供可视化/调试)。策略分派层每帧写入;有子状态的动作
        # (如 guard)在方法内部细化。可视化 pass 读它标注文字,见 main.py。
        self.action: str = "init"

        # SDK 缓存字段,框架后台会自动更新
        self._mode: str | None = None
        self._fall_down_state: str | None = None

        # 避障绕行侧记忆(跨帧;None=当前无绕行)
        self._avoid_side: float | None = None

        # 踢球迟滞状态(跨帧)
        self._kicking: bool = False
        self.ball_velocity = (0.0, 0.0)
        self._kick_plan = None
        self._kick_plan_until = 0.0
        self._kick_plan_ball = None
        self.target = None
        self.restart_taker = False
        self.kickoff_taker = False
        self._orbit_side = None
        self._orbit_ball = None
        self.desired_velocity = (0.0, 0.0, 0.0)
        self.kick_command = None
        self._kick_watch = None
        self._kick_retry_until = 0.0
        self._recovery_target = None
        self._nav_watch = None
        self._global_plan_at = -math.inf
        self._global_plan_target = None
        self._global_path = None
        self.navigation = "idle"
        self.foot_side_hint = None
        self._kick_foot_last = None
        self._receive_wait_until = 0.0
        self._receive_wait_point = None
        self.keeper_decision = None
        self.keeper_line_covered = None
        # V35 restart-specific controller. Persist across 30-Hz control ticks;
        # do not mix its SDK lease with ordinary attack/orbit controllers.
        self._ko35_mode = 'stage'
        self._ko35_sdk_started = None
        self._ko35_attempts = 0
        self._ko35_last_pose = None
        self._ko35_motion_speed = None
        self._ko35_brake_until = 0.0
        self._ko35_restage_started = None
        self._ko35_entry_ball = None
        self._ko35_last_ball = None
        self._ko35_verified = False
        self._ko35_launch_speed = None
        self._ko35_launch_error_rad = None
        self._ko35_command_heading = None
        self._ko35_event = 'idle'
        self._v36_poke_until = -math.inf
        self._v36_poke_origin = None
        self._v36_keeper_clear_origin = None
        self._v36_keeper_retry_after = -math.inf

        # block/guard 的跨帧迟滞状态
        self._block_pressing: bool = False
        self._guard_threatened: bool = False
        # 门线撞球进门迟滞状态
        self._goal_line_push: bool = False
        # support 卡住后临时转 attack 的跨帧状态
        self._support_last_pos: tuple[float, float] | None = None
        self._support_stationary_since: float | None = None
        self._support_last_update_at: float | None = None

    # ------------------------------------------------------------------
    # 状态读取
    # ------------------------------------------------------------------

    @property
    def is_kicking(self) -> bool:
        """当前是否处于踢球状态。"""
        return self._kicking

    @property
    def pose(self) -> Pose2D | None:
        ctx = self.context
        if ctx is None:
            return None
        robot = ctx.teammates.get(self.id)
        return None if robot is None else robot.pose

    @property
    def mode(self) -> str | None:
        if self._backend is not None:
            return self._backend.mode
        return self._mode

    @property
    def is_fallen(self) -> bool:
        return self.fall_down_state in ('falling', 'fallen', 'getting_up')

    @property
    def fall_down_state(self) -> str | None:
        if self._backend is not None:
            return getattr(self._backend, "fall_down_state", None)
        return self._fall_down_state

    @property
    def penalty(self) -> Penalty:
        ctx = self.context
        if ctx is None or ctx.game is None:
            return Penalty.NONE
        state = ctx.game.get_player_state(self.config.team_id, self.id)
        return Penalty.NONE if state is None else state.penalty

    @property
    def is_penalized(self) -> bool:
        return self.penalty != Penalty.NONE

    # ------------------------------------------------------------------
    # 底盘控制
    # ------------------------------------------------------------------

    def can_leave_field(self):
        """V37 hard safety: no planned touchline/net excursions even at own restarts."""
        return False

    def walk_point(self, target):
        margin = (-min(PLAY_OUTSIDE_M,0.38) if self.can_leave_field() else FIELD_WALK_MARGIN_M)
        return legal_walk_point(self.context, target, margin,
                                kickoff_taker=self.kickoff_taker)

    def set_velocity(self, vx: float, vy: float, vyaw: float) -> None:
        ctx, pose = self.context, self.pose
        if (ctx is not None and pose is not None and math.hypot(vx, vy) > 1e-6
                and not self.is_penalized and ctx.game is not None
                and ctx.game.state in (GameState.READY, GameState.PLAYING) and not ctx.game.stopped):
            c, sn = math.cos(pose.theta), math.sin(pose.theta)
            wx, wy = c * vx - sn * vy, sn * vx + c * vy
            horizon = 0.3
            end = self.walk_point((pose.x + wx * horizon, pose.y + wy * horizon))
            wx, wy = (end[0] - pose.x) / horizon, (end[1] - pose.y) / horizon
            scale = min(1.0, MAX_LINEAR / max(math.hypot(wx, wy), 1e-6))
            vx, vy = (c * wx + sn * wy) * scale, (-sn * wx + c * wy) * scale
        self.desired_velocity = (vx, vy, vyaw)
        if self._backend is None:
            _log.debug(
                "player %d set_velocity vx=%.3f vy=%.3f vyaw=%.3f (no backend)",
                self.id, vx, vy, vyaw,
            )
            return
        self._backend.set_velocity(vx, vy, vyaw)

    def stop(self) -> None:
        self.release_kick()
        self.set_velocity(0.0, 0.0, 0.0)

    # ------------------------------------------------------------------
    # 踢球
    # ------------------------------------------------------------------

    def kick(
        self,
        kick_direction: float | None = None,
        power: float = KICK_POWER_DEFAULT,
    ) -> None:
        pose = self.pose
        if pose is None:
            _log.warning("player %d kick skipped: pose unknown", self.id)
            return

        ball = self.context.ball if self.context is not None else None
        if ball is None:
            _log.warning("player %d kick skipped: ball unknown", self.id)
            return

        if kick_direction is None:
            kick_plan = self.plan_kick()
            if kick_plan is None:
                _log.warning("player %d kick skipped: kick plan unavailable", self.id)
                return
            kick_direction, power = kick_plan

        if self._backend is None:
            _log.debug(
                "player %d kick ball=(%.3f, %.3f) dir=%.3f (no backend)",
                self.id, ball.x, ball.y, kick_direction,
            )
            return
        # 场地坐标 → 体坐标(用当前 pose)
        dx = ball.x - pose.x
        dy = ball.y - pose.y
        cos_t = math.cos(pose.theta)
        sin_t = math.sin(pose.theta)
        ball_x_body = dx * cos_t + dy * sin_t
        ball_y_body = -dx * sin_t + dy * cos_t
        kick_direction = normalize_angle(kick_direction)
        direction_body = normalize_angle(kick_direction - pose.theta)
        # SDK 不暴露选择左/右脚的参数，只接受体坐标球位和射门方向。
        # 横向球位用于推断最容易直接触球的一侧，SDK 自主完成实际选脚。
        self.foot_side_hint = "left" if ball_y_body >= 0.0 else "right"
        self._kick_foot_last = self.foot_side_hint
        # 功率按具体意图选择：只有明确射门用 10；不再因球在敌方半场强制覆盖。
        power_clamped = max(KICK_POWER_MIN, min(KICK_POWER_MAX, power))
        self._kicking = True
        self.desired_velocity = None  # SDK 接管，不能把上一条步行命令当作当前速度
        self.kick_command = (kick_direction, power_clamped)
        self._backend.kick(direction_body, power_clamped, ball_x_body, ball_y_body)
        # SDK may reject this command when it has not entered walk mode.
        # Record the *backend's* lease status rather than assuming command==kick.
        self._kicking = bool(getattr(self._backend, '_kicking', self._kicking))

    def plan_kick(self) -> tuple[float, float] | None:
        """三条门内射线 + 可行前传；无球路时短距离向前拨球。"""
        ctx = self.context
        if ctx is None or ctx.ball is None:
            return None
        ball = ctx.ball
        if ball.x < -ctx.field.length / 2 + ctx.field.penalty_area_length:
            target = self.clearance_target()
            self.action = "attack:clear"
            self._draw_kick_target(target)
            return angle_to(ball.x, ball.y, *target), CLEAR_IN_OUR_HALF_POWER
        gx = ctx.field.length / 2
        if ball.x >= gx - 0.05 and abs(ball.y) <= ctx.field.goal_width / 2 - SHOT_POST_MARGIN_M:
            # 球已在门线边缘时只轻推入网，不因场内夹取反向踢回。
            target = (max(gx + 0.35, ball.x + 0.15), 0.0)
            self.action = "attack:finish"
            self._draw_kick_target(target)
            return angle_to(ball.x, ball.y, *target), KICK_SHORT
        target = goal_gap_target(ctx, self.id)
        shoot = (target is not None and ball.x >= SHOT_MIN_X_M
                 and dist(ball.x, ball.y, *target) <= SHOT_RANGE_M
                 and self.kick_can_score(angle_to(ball.x, ball.y, *target)))
        if shoot:
            power = SHOT_POWER
            self.action = "attack:shoot"
        else:
            passes = [r.pose for pid, r in ctx.teammates.items()
                      if pid != self.id and r.pose is not None
                      and (ctx.game is None or ctx.game.get_player_state(ctx.team_id, pid) is None
                           or ctx.game.get_player_state(ctx.team_id, pid).penalty == Penalty.NONE)
                      and r.pose.x > ball.x + 0.7
                      and 1.2 < dist(ball.x, ball.y, r.pose.x, r.pose.y) < 4.5
                      and lane_clearance(ctx, (r.pose.x, r.pose.y), self.id, pid) >= KICK_LANE_CLEARANCE_M]
            # 接球者本身不算阻挡：lane_clearance 的终点处理在传球时排除接球者。
            # V37: when a forward has a direct clean lane but no guaranteed
            # finishing window, drive towards the far goal/endline instead of
            # a diagonal x+1.5m sideline nudge. This is NOT called a goal shot
            # unless the stricter goal_gap_target() criteria passed above.
            forward_lanes = [(lane_clearance(ctx,(gx,y),self.id), (gx,y))
                             for y in (-0.65,0.0,0.65)]
            long_clearance,long_goal = max(forward_lanes,key=lambda pair:
                                           (pair[0],-abs(pair[1][1])))
            forward_drive = (ball.x >= -1.2 and abs(ball.y) <= 3.5
                             and long_clearance >= SHOT_V37_GOALLINE_MARGIN_M
                             and ball.x < gx-0.30)
            if forward_drive:
                target = long_goal
                power = SHOT_POWER
                self.action = 'attack:goal_line_drive'
            elif passes:
                receiver = max(passes, key=lambda p: p.x - 0.65 * abs(p.y))
                target = (receiver.x, receiver.y)
                power = KICK_SHORT if dist(ball.x, ball.y, *target) <= 2.2 else KICK_LONG
                self.action = "attack:pass"
            else:
                candidates = [inside(ctx, (ball.x + 1.5, y))
                              for y in (ball.y * 0.45, ball.y * 0.7, ball.y)]
                safe = [q for q in candidates if lane_clearance(ctx, q, self.id) >= KICK_LANE_CLEARANCE_M]
                target = min(safe, key=lambda q: abs(q[1])) if safe else max(candidates, key=lambda q: min(lane_clearance(ctx, q, self.id), 2.0) - 0.2 * abs(q[1]))
                power = KICK_LONG if ball.x < -0.3 and safe else KICK_SHORT
                self.action = "attack:advance"
        self._draw_kick_target(target)
        direction = angle_to(ball.x, ball.y, *target)
        if self.action in ('attack:shoot', 'attack:goal_line_drive'):
            # The bias is optional: 0 by default until clean contact samples
            # establish its sign. Rejection if the compensated ray is unsafe.
            bias = clamp(SHOT_EMPIRICAL_BIAS_RAD, -SHOT_BIAS_MAX_RAD, SHOT_BIAS_MAX_RAD)
            compensated = normalize_angle(direction - bias)
            # The intended ACTUAL trajectory remains directed at target;
            # observed_bias is estimated actual minus commanded angle.
            direction = compensated
        return direction, power

    def _goal_target_for_direction(
        self, kick_direction: float,
    ) -> tuple[float, float]:
        """把射门方向投到对方门线上,用于可视化踢球目标。"""
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return (0.0, 0.0)

        dx = math.cos(kick_direction)
        if dx <= 1e-6:
            return opponent_goal(ctx)
        goal_x = ctx.field.length / 2.0
        t = max(0.0, (goal_x - ball.x) / dx)
        return (goal_x, ball.y + math.sin(kick_direction) * t)

    def _in_backfield(self) -> bool:
        """球在我方后场时,默认踢球加大力度。"""
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return False
        # own_penalty_edge_x = -ctx.field.length / 2.0 + ctx.field.penalty_area_length
        # return ball.x < own_penalty_edge_x
        return ball.x < 0

    def _draw_kick_target(self, target: tuple[float, float]) -> None:
        """以 X 标出 plan_kick 选择的踢球目标。"""
        from .framework import debugdraw

        self.aim_target = target
        x, y = target
        s = KICK_TARGET_MARK_SIZE_M
        debugdraw.line(
            [(x - s, y - s), (x + s, y + s)],
            rgb=(1.0, 0.0, 1.0), ns="kick_target",
        )
        debugdraw.line(
            [(x - s, y + s), (x + s, y - s)],
            rgb=(1.0, 0.0, 1.0), ns="kick_target",
        )

    def release_kick(self) -> None:
        self._kicking = False  # 清除踢球迟滞标志(取消方块显示)
        self.kick_command = None
        self._kick_plan = None
        self._kick_watch = None
        if self._backend is None:
            _log.debug("player %d release_kick (no backend)", self.id)
            return
        self._backend.release_kick()

    def kick_can_score(self, kick_direction: float) -> bool:
        """判断从当前球位按 ``kick_direction`` 踢,直线轨迹是否能进对方球门。
        """
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return False

        goal_x = ctx.field.length / 2.0
        dx = math.cos(kick_direction)
        dy = math.sin(kick_direction)
        if dx <= 1e-6:
            return False

        half_goal = ctx.field.goal_width / 2.0
        if half_goal <= 0.0:
            return False
        if ball.x >= goal_x:
            y_at_goal = ball.y
        else:
            t = (goal_x - ball.x) / dx
            if t < 0.0:
                return False
            y_at_goal = ball.y + dy * t
        safe_half_goal = half_goal - SHOT_POST_MARGIN_M - SHOT_GOAL_POST_EXTRA_M
        if safe_half_goal <= 0:
            return False
        return abs(y_at_goal) + max(0.0, goal_x - ball.x)*math.tan(SHOT_GOAL_ERROR_RAD) <= safe_half_goal

    # ------------------------------------------------------------------
    # 慢操作（同步接口异步调取，使得不阻塞）
    # ------------------------------------------------------------------

    def request_mode(self, mode: str) -> None:
        if self._backend is None:
            _log.debug("player %d request_mode -> %s (no backend)", self.id, mode)
            return
        self._backend.request_mode(mode)

    def get_up(self) -> None:
        if self._backend is None:
            _log.debug("player %d get_up (no backend)", self.id)
            return
        self._backend.get_up()

    # ------------------------------------------------------------------
    # 走位
    # ------------------------------------------------------------------

    def ensure_ready(self) -> bool:
        """活性自理:摔倒→起身,非 walk→切模式(都异步、不产生移动)。

        返回本帧是否可执行动作(True=已就绪)。
        """
        if self.is_fallen:
            # Falling/getting up: don't restart a risky kick or queue repeated
            # get_up calls before the fall has settled.
            self.release_kick()
            self.stop()
            if self.fall_down_state == 'fallen':
                self.get_up()
            return False
        if self.mode != "walk":
            self.request_mode("walk")
            return False
        return True

    def face_to(self, target_theta: float) -> None:
        """原地转向到目标朝向。"""
        if self.pose is None:
            self.stop()
            return
        err = normalize_angle(target_theta - self.pose.theta)
        self.set_velocity(0.0, 0.0, self._angular(err))

    def walk_to(
        self,
        target: tuple[float, float],
        *,
        face: float | None = None,
        avoid_ball: bool = False,
        avoid_robots: bool = False,
        arrive_dist: float = ARRIVE_DIST,
        omni: bool = False,
        sprint: bool = False,
        compact_ball: bool = False,
    ) -> bool:
        """走向目标点。返回是否已到达。

        避障(局部规划器,简化版 VFH):``avoid_ball`` / ``avoid_robots`` 开启时,把
        球 / 机器人 / 球门结构收集成圆形障碍,在机器人周围扫一圈候选方向,选"最朝
        目标 + 前方 ``PLAN_LOOKAHEAD`` 内不撞障碍"的方向前进。能处理多障碍、凹形
        结构和对称冲突,比单障碍绕行 / 势场排斥稳。

        行走两种模式:近距离全向,远距离转身-走。``face`` 指定到达/近距离时的朝向。
        """
        self.release_kick() # 踢球状态下，走位会被覆盖，先取消踢球状态
        pose = self.pose
        if pose is None:
            self.stop()
            return False

        if self.context is not None:
            target = self.walk_point(target)
        self.target = target
        tx, ty = target
        dx = tx - pose.x
        dy = ty - pose.y
        distance = math.hypot(dx, dy)

        if distance < arrive_dist:
            # 已到达:按需转到目标朝向
            if face is not None:
                err = normalize_angle(face - pose.theta)
                if abs(err) > 0.1:
                    self.set_velocity(0.0, 0.0, self._angular(err))
                else:
                    self.stop()
            else:
                self.stop()
            return True

        now = self.context.now if self.context else 0.0
        watch = self._nav_watch
        if (watch is None or now < watch[0] or dist(pose.x, pose.y, watch[1], watch[2]) > 0.12
                or dist(tx, ty, watch[3], watch[4]) > 0.5):
            self._nav_watch = (now, pose.x, pose.y, tx, ty)
        stalled = self._nav_watch is not None and now - self._nav_watch[0] > NAV_NO_PROGRESS_SEC
        self.navigation = "retry" if stalled else "direct"

        # 通畅时直走；受阻才用原有 A*，缓存 0.6s，局部避障兜底。
        self._nav_lookahead = min(PLAN_LOOKAHEAD, max(0.25, distance))
        goal_dir = math.atan2(dy, dx)
        planned_path: list[tuple[float, float]] | None = None
        waypoint: tuple[float, float] | None = None
        if (avoid_ball or avoid_robots) and self.context is not None:
            obstacles = collect_obstacles(
                self.context, self.id,
                ball=avoid_ball, robots=avoid_robots,
                goals=(avoid_ball or avoid_robots),
            )
            if compact_ball and self.context.ball is not None:
                b = self.context.ball
                obstacles = [o for o in obstacles if not (o.x == b.x and o.y == b.y and o.radius == BALL_OBSTACLE_RADIUS)]
                obstacles.append(Obstacle(b.x, b.y, ORBIT_BALL_KEEP_M, clearance=0.0, inflation=0.02))
            g, ball = self.context.game, self.context.ball
            if (avoid_ball and ball is not None and g is not None and g.set_play != SetPlay.NONE
                    and g.kicking_team not in (self.context.team_id, 255)):
                # 防守定位球时连路径也绕开规则半径，而非仅约束终点。
                obstacles = [obs for obs in obstacles if not (obs.x == ball.x and obs.y == ball.y
                              and obs.radius == BALL_OBSTACLE_RADIUS)]
                obstacles.append(Obstacle(ball.x, ball.y, OPPONENT_RESTART_AVOID_M))
            direct_clear = _heading_clearance(pose.x, pose.y, goal_dir, obstacles, self._nav_lookahead)
            if USE_GLOBAL_PATH_PLANNER and (direct_clear < PLAN_CLEARANCE or stalled):
                changed = self._global_plan_target is None or dist(tx, ty, *self._global_plan_target) > 0.5
                if changed or now - self._global_plan_at >= GLOBAL_REPLAN_SEC or now < self._global_plan_at:
                    self._global_path = plan_global_path(self.context, (pose.x, pose.y), (tx, ty), obstacles,
                                                         outside_margin=PLAY_OUTSIDE_M if self.can_leave_field() else None)
                    self._global_plan_target, self._global_plan_at = (tx, ty), now
                planned_path = self._global_path
                if planned_path:
                    # 随机器人推进裁掉已过的路段，不反复瞄准缓存的起点。
                    nearest = min(range(len(planned_path)),
                                  key=lambda i: dist(pose.x, pose.y, *planned_path[i]))
                    planned_path = [(pose.x, pose.y)] + planned_path[min(nearest + 1, len(planned_path) - 1):]
                    waypoint = self._path_waypoint(pose, planned_path)
                    route_dir = angle_to(pose.x, pose.y, *waypoint)
                    heading = self._plan_heading(pose, route_dir, obstacles)
                    self.navigation = "global_retry" if stalled else "global"
                else:
                    heading = self._plan_heading(pose, goal_dir, obstacles)
                    self.navigation = "local_retry" if stalled else "local"
            else:
                heading = self._plan_heading(pose, goal_dir, obstacles)
        else:
            heading = goal_dir

        # 可视化:目标点(绿)、到目标连线(灰)、规划朝向(黄箭头)、
        # 前方探测射线(青,长度=lookahead;规划器"看"的范围,无 path/途径点概念)
        from .framework import debugdraw
        debugdraw.point(tx, ty, rgb=(0.0, 1.0, 0.0), scale=0.15, ns="target")
        debugdraw.line([(pose.x, pose.y), (tx, ty)], rgb=(0.4, 0.4, 0.4), ns="to_target")
        if planned_path is not None and len(planned_path) >= 2:
            debugdraw.line(planned_path, rgb=(0.2, 0.8, 1.0), ns="global_path")
        if waypoint is not None:
            debugdraw.point(
                waypoint[0], waypoint[1],
                rgb=(0.2, 0.8, 1.0), scale=0.12, ns="global_waypoint",
            )
        debugdraw.arrow(
            pose.x, pose.y,
            pose.x + math.cos(heading) * 0.6, pose.y + math.sin(heading) * 0.6,
            rgb=(1.0, 1.0, 0.0), ns="heading",
        )
        debugdraw.line(
            [(pose.x, pose.y),
             (pose.x + math.cos(heading) * PLAN_LOOKAHEAD,
              pose.y + math.sin(heading) * PLAN_LOOKAHEAD)],
            rgb=(0.0, 0.8, 0.8), ns="lookahead",
        )

        angle_err = normalize_angle(heading - pose.theta)
        # 长距离朝运动方向前进。近距也不一边面球一边长距离倒走。
        use_omni = (omni and (distance <= OMNI_DIST or abs(angle_err) <= math.pi / 2 + 1e-6)) or (distance <= 0.5 and abs(angle_err) <= math.pi / 2)
        if use_omni:
            speed = MAX_LINEAR if sprint and distance > RECOVER_BRAKE_M else min(MAX_LINEAR, LINEAR_GAIN * distance)
            c, sn = math.cos(pose.theta), math.sin(pose.theta)
            vx = speed * math.cos(heading - pose.theta)
            vy = speed * math.sin(heading - pose.theta)
            # 门将保留侧移，其他球员面对行走方向；只在最后0.3m对准球/脚。
            final_face = face if face is not None and (omni or distance < 0.3) else heading
            self.set_velocity(vx, vy, self._angular(normalize_angle(final_face - pose.theta)))
        else:
            # 朝向错误先转身，方向接近后边跑边转，禁止负向前进指令。
            speed = MAX_LINEAR if sprint and distance > RECOVER_BRAKE_M else min(MAX_LINEAR, LINEAR_GAIN * distance)
            if abs(angle_err) > math.pi / 2:
                self.set_velocity(0.0, 0.0, self._angular(angle_err))
            else:
                self.set_velocity(speed * max(0.0, math.cos(angle_err)), 0.0, self._angular(angle_err))
        return False

    def _path_waypoint(
        self, pose: Pose2D, path: list[tuple[float, float]],
    ) -> tuple[float, float]:
        """Pick a short lookahead waypoint from a planned global path."""
        if not path:
            return (pose.x, pose.y)
        prev = (pose.x, pose.y)
        points = path[1:] if len(path) > 1 else path
        for point in points:
            seg_len = dist(prev[0], prev[1], point[0], point[1])
            if seg_len >= GLOBAL_PATH_LOOKAHEAD_M:
                ratio = GLOBAL_PATH_LOOKAHEAD_M / max(seg_len, 1e-6)
                return (
                    prev[0] + (point[0] - prev[0]) * ratio,
                    prev[1] + (point[1] - prev[1]) * ratio,
                )
            prev = point
        return path[-1]

    def _plan_heading(
        self, pose: Pose2D, goal_dir: float, obstacles: list,
    ) -> float:
        """扫候选方向,选最朝目标且前方够空的方向;都不够空时返回最空的那个。

        候选按偏离目标方向 ``|offset|`` 从小到大试;先试哪一侧由 player_id 奇偶决定,
        用来打破两人同侧避让的对称。
        """
        sign_first = 1.0 if self.id % 2 == 0 else -1.0
        best_h = goal_dir
        best_clear = -math.inf

        offsets = [0.0]
        k = 1
        while k * PLAN_STEP <= PLAN_MAX_OFFSET + 1e-9:
            offsets.append(sign_first * k * PLAN_STEP)
            offsets.append(-sign_first * k * PLAN_STEP)
            k += 1

        for off in offsets:
            h = goal_dir + off
            if self.context is not None:
                end = (pose.x + math.cos(h) * 0.45, pose.y + math.sin(h) * 0.45)
                safe = self.walk_point(end)
                if dist(*end, *safe) > 1e-6:
                    continue
            clear = _heading_clearance(pose.x, pose.y, h, obstacles, getattr(self, "_nav_lookahead", PLAN_LOOKAHEAD))
            if clear >= PLAN_CLEARANCE:
                return h
            if clear > best_clear:
                best_clear, best_h = clear, h
        if best_clear == -math.inf and self.context is not None:
            return angle_to(pose.x, pose.y, *inside(self.context, (pose.x, pose.y), 0.7))
        return best_h

    # ------------------------------------------------------------------
    # 高层动作(策略在 main.py 里直接调这些)
    # ------------------------------------------------------------------


    def block_path_projection(
        self, opponent_id: int,
    ) -> tuple[float, float, float, float] | None:
        """自己到 对手→球 线段的垂足:返回 (x, y, 垂距, 线段参数 t)。"""
        ctx = self.context
        pose = self.pose
        ball = ctx.ball if ctx is not None else None
        opponent = ctx.opponents.get(opponent_id) if ctx is not None else None
        if ctx is None or pose is None or ball is None or opponent is None:
            return None
        if opponent.pose is None:
            return None

        ax, ay = opponent.pose.x, opponent.pose.y
        bx, by = ball.x, ball.y
        vx, vy = bx - ax, by - ay
        length2 = vx * vx + vy * vy
        if length2 < 1e-6:
            return None

        raw_t = ((pose.x - ax) * vx + (pose.y - ay) * vy) / length2
        t = clamp(raw_t, 0.0, 1.0)
        tx = ax + vx * t
        ty = ay + vy * t
        return tx, ty, dist(pose.x, pose.y, tx, ty), raw_t

    def _try_v36_pressure_poke(self) -> bool:
        """Short disruption only when an opponent will take the ball first.

        Avoid own-goal direction, do not override a clean open shot, and
        release the SDK as soon as the ball has actually moved forward.
        This is still SDK kicking, not an instantaneous physical toe-tap.
        """
        ctx, pose = self.context,self.pose
        if ctx is None or pose is None or ctx.ball is None or self.id == KEEPER_ID:
            return False
        ball = ctx.ball
        if self._v36_poke_origin is not None:
            started, origin = self._v36_poke_origin
            if (ctx.now-started < PRESS_V36_POKE_LEASE_S
                    and dist(ball.x,ball.y,*origin) < 0.30):
                self.action='attack:pressure_poke'
                self.kick(angle_to(ball.x,ball.y,min(ball.x+3.5,ctx.field.length/2),
                                   clamp(ball.y,-3.1,3.1)), PRESS_V36_POKE_POWER)
                return True
            self._v36_poke_origin=None
            self.release_kick()
            return False
        if ball.x < PRESS_V36_POKE_X_LIMIT_M:
            return False
        d=dist(pose.x,pose.y,ball.x,ball.y)
        if d>PRESS_V36_POKE_BALL_MAX_M:
            return False
        if not any(q.pose and dist(q.pose.x,q.pose.y,ball.x,ball.y) <= PRESS_V36_POKE_OPPONENT_M
                   for q in ctx.opponents.values()):
            return False
        # Don't replace a safe direct goal shot with an unnecessary poke.
        if ball.x > 0.8 and goal_gap_target(ctx,self.id) is not None:
            return False
        dx,dy=ball.x-pose.x,ball.y-pose.y
        front=math.cos(pose.theta)*dx+math.sin(pose.theta)*dy
        side=-math.sin(pose.theta)*dx+math.cos(pose.theta)*dy
        if not (PRESS_V36_POKE_BODY_FRONT_MIN_M <= front <= PRESS_V36_POKE_BODY_FRONT_MAX_M
                and abs(side)<=PRESS_V36_POKE_BODY_LATERAL_M):
            return False
        # Don't launch 180-degree SDK kick across the chest/into our own goal.
        if abs(normalize_angle(-pose.theta)) > 0.58:
            return False
        self._v36_poke_origin=(ctx.now,(ball.x,ball.y))
        self.action='attack:pressure_poke'
        self.kick(angle_to(ball.x,ball.y,min(ball.x+3.5,ctx.field.length/2),
                           clamp(ball.y,-3.1,3.1)), PRESS_V36_POKE_POWER)
        return True

    def attack(self, kick_target: tuple[float, float] | None = None,
               power: float | None = None) -> None:
        """自己快速接近，近距离才交给 SDK；短时保持目标但球一跑开立即追。"""
        ctx, pose = self.context, self.pose
        if ctx is None or ctx.ball is None or pose is None:
            self.stop()
            return
        ball = ctx.ball
        if self.can_leave_field() and (abs(pose.x) > ctx.field.length / 2 + PLAY_OUTSIDE_M
                or abs(pose.y) > ctx.field.width / 2 + PLAY_OUTSIDE_M):
            self.walk_to(inside(ctx, (pose.x, pose.y), 0.7),
                         avoid_ball=True, avoid_robots=True, omni=True)
            self.action = "attack:edge_recover"
            return
        if kick_target is None and self._try_v36_pressure_poke():
            return
        if ctx.now < self._kick_retry_until:
            self.walk_to(self._recovery_target, face=angle_to(ball.x, ball.y, *opponent_goal(ctx)),
                         avoid_ball=True, avoid_robots=True, omni=True, arrive_dist=0.08)
            self.action = "attack:unstick"
            return
        if self.is_kicking and self._kick_watch is not None:
            since, bx, by = self._kick_watch
            if ctx.now < since or dist(ball.x, ball.y, bx, by) > 0.15:
                self._kick_watch = (ctx.now, ball.x, ball.y)
            elif ctx.now - since >= KICK_NO_PROGRESS_SEC:
                aim = kick_target or opponent_goal(ctx)
                heading = angle_to(ball.x, ball.y, *aim)
                side = -1.0 if ball.y >= 0 else 1.0
                self._recovery_target = self.walk_point((ball.x - 0.4 * math.cos(heading),
                                                     ball.y - 0.4 * math.sin(heading) + side * 0.25))
                self._kick_retry_until = ctx.now + KICK_RETRY_SEC
                self.walk_to(self._recovery_target, avoid_ball=True, avoid_robots=True, omni=True, arrive_dist=0.08)
                self.action = "attack:unstick"
                return
        d = dist(pose.x, pose.y, ball.x, ball.y)
        explicit = kick_target is not None
        replan_limit = (SHOT_REPLAN_BALL_MOVED_M if self.action == 'attack:shoot'
                        and self._kick_plan is not None else BALL_REPLAN_M)
        moved = (self._kick_plan_ball is None or
                 dist(ball.x, ball.y, *self._kick_plan_ball) > replan_limit)
        if explicit:
            plan = (angle_to(ball.x, ball.y, *kick_target), KICK_POWER_DEFAULT if power is None else power)
            aim = kick_target
        elif (self.is_kicking and self._kick_plan is not None
              and ctx.now < self._kick_plan_until and not moved
              and self.action != 'attack:shoot'):
            # Keep short passes stable, but shooting direction is refreshed each tick.
            plan = self._kick_plan
            aim = getattr(self, 'aim_target', opponent_goal(ctx))
        else:
            plan = self.plan_kick()
            aim = self.aim_target
        direction = plan[0]
        ux, uy = math.cos(direction), math.sin(direction)
        front = (pose.x - ball.x) * ux + (pose.y - ball.y) * uy
        # 左右脚同等候选。球在左/右哪侧，只要在可靠触球包络内，直接交 SDK，
        # 不再为单一脚侧绕球；SDK 自己决定实际用脚（它没有 foot 参数）。
        lateral = abs((pose.x - ball.x) * -uy + (pose.y - ball.y) * ux)
        body_x = math.cos(pose.theta) * (ball.x-pose.x) + math.sin(pose.theta) * (ball.y-pose.y)
        body_y = -math.sin(pose.theta) * (ball.x-pose.x) + math.cos(pose.theta) * (ball.y-pose.y)
        self.foot_side_hint = "left" if body_y >= 0.0 else "right"
        available_foot = (-KICK_FOOT_BACKWARD_TOL_M <= body_x <= KICK_FOOT_FORWARD_REACH_M
                          and abs(body_y) <= KICK_FOOT_LATERAL_REACH_M)
        # V34: A regular power shot must be made from near the ball, with a
        # reachable body-frame foot position and a reasonably aligned torso.
        # This is a *precondition* for using the SDK, not a replacement kick API.
        shooting = self.action in ('attack:shoot', 'attack:goal_line_drive') and not explicit
        heading_error = normalize_angle(direction - pose.theta)
        close_shot = (d <= SHOT_NEAR_BALL_ENTER_M
                      and SHOT_BODY_FORWARD_MIN_M <= body_x <= SHOT_BODY_FORWARD_MAX_M
                      and abs(body_y) <= SHOT_BODY_LATERAL_MAX_M)
        # Estimate runner's world velocity from two distinct pose timestamps.
        # A fast-running robot should brake before committing to a power kick,
        # rather than asking KickManager to kick in the middle of a hard sprint.
        robot_state = ctx.teammates.get(self.id)
        stamp = robot_state.last_seen_at if robot_state else ctx.now
        last = getattr(self, '_shot_body_motion_sample', None)
        measured_speed = 0.0
        if last and 0.015 < stamp - last[0] <= 0.40:
            measured_speed = math.hypot(pose.x - last[1], pose.y - last[2]) / (stamp - last[0])
        self._shot_body_motion_sample = (stamp, pose.x, pose.y)
        self.shot_preparation_speed_estimate = measured_speed
        if shooting and close_shot and measured_speed > SHOT_MAX_ENTRY_RUNNING_SPEED_MPS:
            self.release_kick()
            self.action = 'attack:shot_brake'
            self.set_velocity(0.0, 0.0, 0.0)
            return
        if shooting and close_shot and abs(heading_error) > SHOT_STABLE_HEADING_RAD:
            self.release_kick()
            self.action='attack:shot_align'
            self.set_velocity(0.0, 0.0, clamp(ANGULAR_GAIN*heading_error,
                                             -SHOT_ALIGN_MAX_YAW_RAD_S,
                                              SHOT_ALIGN_MAX_YAW_RAD_S))
            return
        quick_contact = (d <= FAST_KICK_DISTANCE_M and available_foot
                         and front <= FAST_KICK_FRONT_ALLOW_M)
        lateral_limit = FAST_KICK_LATERAL_M if d <= FAST_KICK_DISTANCE_M else 0.26
        wrong_side = ((front > 0.12 or lateral > lateral_limit) and not self.is_kicking
                      and not quick_contact)
        enter_reach = (KICK_EXIT_M if self.is_kicking else KICK_ENTER_M)
        can_shoot_now = (not shooting or close_shot)
        if d <= enter_reach and not wrong_side and can_shoot_now:
            if explicit or self._kick_plan is None or ctx.now >= self._kick_plan_until or moved or shooting:
                self._kick_plan, self._kick_plan_ball = plan, (ball.x, ball.y)
                self._kick_plan_until = ctx.now + (SHOT_PLAN_MAX_HOLD_SEC if shooting
                                                    else KICK_PLAN_HOLD_SEC)
            if self._kick_watch is None:
                self._kick_watch = (ctx.now, ball.x, ball.y)
            self.kick(*self._kick_plan)
            return
        future, _ = intercept(ctx, pose, self.ball_velocity)
        if math.hypot(*self.ball_velocity) < 2.0:
            future = self.walk_point((ball.x + self.ball_velocity[0] * CONTROL_PREDICT_SEC,
                                      ball.y + self.ball_velocity[1] * CONTROL_PREDICT_SEC))
        bx, by = (ball.x, ball.y) if d < 1.2 else future
        # 对方争球时减少球后站位偏移量，远距离仍用原偏移保证出脚角度。
        opponent_near = any(q.pose and dist(q.pose.x, q.pose.y, ball.x, ball.y) <= PRESS_OPPONENT_NEAR_M
                            for q in ctx.opponents.values())
        offset = FAST_APPROACH_OFFSET_M if opponent_near and d < 1.6 else APPROACH_OFFSET_M
        if shooting and d < 1.0:
            # Keep the ball in front of either foot without stepping *through* it.
            offset = min(offset, 0.22)
        target = self.walk_point((bx - ux * offset, by - uy * offset))
        if wrong_side and d < 1.3 and not (available_foot and front < 0.40):
            target = self.orbit_waypoint(direction)
            self.action = "attack:screen_orbit"
            self.walk_to(target, face=direction, avoid_ball=True, compact_ball=True,
                         avoid_robots=True, arrive_dist=0.04, omni=True)
        else:
            self._orbit_side = None
            self.action = "attack:get_behind" if wrong_side else "attack:intercept"
            self.walk_to(target, face=direction, avoid_ball=wrong_side,
                         compact_ball=wrong_side, avoid_robots=True, arrive_dist=0.05,
                         sprint=d > 0.6)

    def clearance_target(self):
        """Never clear toward our goal. If midfield lanes are obstructed, clear wide.

        A dangerous throw-in is preferable to an own goal. Radii are conservative
        planning envelopes; actual collision geometry is not published in the API.
        """
        ctx, ball = self.context, self.context.ball
        gx = -ctx.field.length/2
        # Goalkeeper clears to the opponent's half direction, not toward our line.
        goal_danger = self.id == KEEPER_ID and ball.x < gx + 3.0
        reach_x = max(ball.x + KEEPER_CLEAR_FORWARD_X_M, gx + 2.3)
        targets = [inside(ctx, (reach_x, y), margin=0.20)
                   for y in (0.0, -0.65, 0.65)]
        lanes = [(lane_clearance(ctx, q, self.id),q) for q in targets]
        best_c, best_q = max(lanes, key=lambda k:(k[0],-abs(k[1][1])))
        if not goal_danger or best_c >= KEEPER_CLEAR_LANE_MIN_M:
            return best_q
        sideline_x = min(ctx.field.length/2-0.3,
                         ball.x + KEEPER_CLEAR_SIDE_X_M)
        edges = [inside(ctx, (sideline_x, sign*KEEPER_CLEAR_SIDE_Y_M), margin=0.20)
                 for sign in (-1.0, 1.0)]
        # Score corridor clearance first, then favor the nearer sideline.
        return max(edges, key=lambda q:(lane_clearance(ctx, q, self.id),
                                        -abs(q[1]-ball.y)))

    def orbit_waypoint(self, direction):
        """小圆弧去球后，安全可行时优先经过对手与球之间，锁定绕行侧。"""
        ctx, pose, ball = self.context, self.pose, self.context.ball
        start = math.atan2(pose.y - ball.y, pose.x - ball.x)
        end = normalize_angle(direction + math.pi)
        radius = ORBIT_RADIUS_M
        robots = [q.pose for pid, q in ctx.teammates.items() if pid != self.id and q.pose]
        enemies = [q.pose for q in ctx.opponents.values() if q.pose]
        robots += enemies
        closest = min(enemies, key=lambda q: dist(q.x, q.y, ball.x, ball.y), default=None)
        choices = []
        for sign in (-1, 1):
            sweep = (sign * (end - start)) % (2 * math.pi)
            n = max(1, math.ceil(sweep / ORBIT_STEP_RAD))
            samples = [(ball.x + radius * math.cos(start + sign * sweep * i / n),
                        ball.y + radius * math.sin(start + sign * sweep * i / n)) for i in range(1, n + 1)]
            # 不因卡位主动撞对手；不可行的一侧不能因奖励获选。
            safe = all(dist(x, y, *self.walk_point((x, y))) < 1e-6
                       and all(dist(x, y, q.x, q.y) >= 0.55 for q in robots) for x, y in samples)
            screen = False
            if closest and dist(closest.x, closest.y, ball.x, ball.y) < 2.5:
                enemy_angle = math.atan2(closest.y - ball.y, closest.x - ball.x)
                screen = (sign * (enemy_angle - start)) % (2 * math.pi) <= sweep
            score = radius * sweep - (0.22 if screen else 0.0)
            choices.append((not safe, score, sign, sweep))
        moved = self._orbit_ball is None or dist(ball.x, ball.y, *self._orbit_ball) > 0.15
        chosen = min(choices)
        held = next((q for q in choices if q[2] == self._orbit_side and not q[0]), None)
        if held is not None and not moved:
            chosen = held
        self._orbit_side, self._orbit_ball = chosen[2], (ball.x, ball.y)
        step = min(ORBIT_STEP_RAD, chosen[3])
        angle = start + chosen[2] * step
        return self.walk_point((ball.x + radius * math.cos(angle), ball.y + radius * math.sin(angle)))

    def can_claim_ball(self, field_eta: float = math.inf) -> bool:
        """禁区内只有安全可控球才允许门将接管，避免被拉出门前防线。"""
        ctx, pose = self.context, self.pose
        if ctx is None or pose is None or ctx.ball is None:
            return False
        g, ball = ctx.game, ctx.ball
        if g is None or g.state != GameState.PLAYING or g.stopped or g.set_play != SetPlay.NONE:
            return False
        if g.secondary_time > 0 and g.kicking_team != 255:
            return False
        gx = -ctx.field.length / 2
        if not (gx - 0.05 <= ball.x <= gx + KEEPER_CLAIM_MAX_X_M
                and abs(ball.y) <= ctx.field.goal_width / 2 + KEEPER_CLAIM_LATERAL_M):
            return False
        # 不可为了追球离开门线太远；球已有向门线的速度时保持封堵线。
        if pose.x > gx + KEEPER_MAX_ADVANCE_FROM_GOAL_M + 0.15:
            return False
        d = dist(pose.x, pose.y, ball.x, ball.y)
        if abs(ball.y) > KEEPER_WIDE_BALL_Y_M and (ball.x > gx + KEEPER_WIDE_CLAIM_X_MAX_M
                or d > KEEPER_WIDE_CLAIM_DIST_M):
            # Do not chase stationary wide balls away from the goalmouth.
            return False
        if d > KEEPER_CLAIM_REACH_M or self.is_penalized or self.is_fallen:
            return False
        # 高速来球但位于门将前方且近距：必须允许踢球，而非因为速度快一律放弃。
        if d <= KEEPER_SAFE_TOUCH_M:
            return True
        vx, vy = self.ball_velocity
        if vx < -KEEPER_THREAT_SPEED_MPS:
            # 当球向本方门线移动，先判断门将是否已占据拦截点。
            # 侧差大时绝不前冲到球身后，应横向补位。
            crossing_x = gx + KEEPER_BLOCK_X_FROM_GOAL_M
            t = max(0.0, (crossing_x-ball.x) / vx) if ball.x > crossing_x else 0.0
            crossing_y = ball.y + vy * min(t, KEEPER_PREDICT_MAX_SEC)
            if abs(pose.y - crossing_y) > KEEPER_SAFE_TOUCH_M:
                return False
            if d > KEEPER_DANGER_CLEAR_DIST_M:
                return False
        return intercept(ctx, pose, self.ball_velocity)[1] <= field_eta + KEEPER_ETA_ADVANTAGE_SEC

    def emergency_clear_ready(self):
        ctx, pose = self.context, self.pose
        if ctx is None or ctx.ball is None or pose is None:
            return False
        g = ctx.game
        if g is None or g.state != GameState.PLAYING or g.stopped or g.set_play != SetPlay.NONE:
            return False
        ball = ctx.ball
        d = dist(pose.x, pose.y, ball.x, ball.y)
        dx, dy = ball.x-pose.x, ball.y-pose.y
        bx = math.cos(pose.theta)*dx + math.sin(pose.theta)*dy
        by = -math.sin(pose.theta)*dx + math.cos(pose.theta)*dy
        return (d <= KEEPER_PREVENT_PRESS_M and bx >= -KICK_FOOT_BACKWARD_TOL_M
                and abs(by) <= KICK_FOOT_LATERAL_REACH_M)

    def emergency_clear(self):
        ball = self.context.ball
        target = self.clearance_target()
        self._draw_kick_target(target)
        self.kick(angle_to(ball.x, ball.y, *target),
                  CLEAR_IN_OUR_HALF_POWER if ball.x < 0 else CLEAR_POWER)
        self.action = "guard:emergency_clear"

    def _keeper_drive(self, target: tuple[float, float], *, face_ball: bool = True) -> None:
        """V37: use verified forward gait, NOT vy-only sidesteps.

        V36 requested ~-1.9m/s lateral movement but observed almost no y
        displacement. Turn toward interception point and advance using vx,
        yielding direction control even if the SDK ignores lateral velocity.
        """
        pose = self.pose
        if pose is None:
            self.stop()
            return
        self.release_kick()
        gx = -self.context.field.length/2
        min_x = (gx+KEEPER_V36_MIN_LEGAL_X_OFFSET_M if
                 self.keeper_decision == 'guard:mouth_rescue' else gx+0.22)
        target = (clamp(target[0], min_x, gx+KEEPER_PRESS_MAX_ADVANCE_M),
                  clamp(target[1], -KEEPER_PRESS_LATERAL_LIMIT_M, KEEPER_PRESS_LATERAL_LIMIT_M))
        self.target = target
        self.navigation = 'keeper_v37_forward_gait'
        dx,dy = target[0]-pose.x,target[1]-pose.y
        d = math.hypot(dx,dy)
        if d > KEEPER_V37_SWEEP_Y_MIN_M:
            # Turn toward WHERE we actually need to travel, not toward the ball.
            desired = math.atan2(dy,dx)
            error = normalize_angle(desired-pose.theta)
            yaw = clamp(3.5*error, -KEEPER_GUARD_MAX_ANGULAR, KEEPER_GUARD_MAX_ANGULAR)
            forward = min(KEEPER_V37_FRONT_SPEED_MPS, d*3.5) * max(0.0, math.cos(error))
            if abs(error) >= KEEPER_V37_TURN_ONLY_RAD:
                forward = 0.0
            self.set_velocity(forward,0.0,yaw)
            return
        ball = self.context.ball
        desired_face = (angle_to(pose.x,pose.y,ball.x,ball.y)
                        if face_ball and ball is not None else 0.0)
        self.set_velocity(0.0,0.0,clamp(3.5*normalize_angle(desired_face-pose.theta),
                                        -KEEPER_GUARD_MAX_ANGULAR,KEEPER_GUARD_MAX_ANGULAR))

    def guard(self, allow_clear: bool = True, *, claim: bool = False,
              forwards: tuple = ()) -> None:
        """V34 independent keeper: occupy shot lane, approach when no striker blocks it."""
        from .keeper_v33 import goalie_decision
        ctx, pose=self.context,self.pose
        if ctx is None or pose is None:
            self.stop()
            return
        ball=ctx.ball
        decision=goalie_decision(ctx,self.ball_velocity,forwards)
        self.keeper_decision=decision.action
        self.keeper_line_covered=decision.covered_by_forward
        if ball is None:
            self.action='guard:home'
            self._keeper_drive(decision.target,face_ball=False)
            return
        d=dist(pose.x,pose.y,ball.x,ball.y)
        gx=-ctx.field.length/2
        # V36 goalkeeper SDK lease: once emergency clearance begins, avoid
        # cancelling it on the next pose update simply because d changed.
        # Release on material ball motion, ball behind the kicking foot, a
        # referee/fall interruption, or a bounded timeout.
        lease=self._v36_keeper_clear_origin
        if lease is not None:
            began,original=lease
            ball_really_moved=dist(ball.x,ball.y,*original)>0.28
            incoming=(self.ball_velocity[0] < -KEEPER_V37_INCOMING_MIN_MPS
                      and ball.x < gx + KEEPER_V37_CRITICAL_DANGER_M)
            stale_under_threat = (incoming and ctx.now-began >= KEEPER_V37_CLEAR_LEASE_UNDER_THREAT_S
                                  and ball.x < original[0]-0.08)
            ball_behind=ball.x < pose.x-0.18
            invalid=(not allow_clear or self.is_fallen or self.is_penalized
                     or ctx.game is None or ctx.game.stopped
                     or ctx.game.state != GameState.PLAYING
                     or ctx.game.set_play != SetPlay.NONE)
            if (not invalid and not ball_behind and not ball_really_moved and not stale_under_threat
                    and ctx.now-began < KEEPER_V36_CLEAR_TIMEOUT_S
                    and d<1.16):
                self.emergency_clear()
                self.action='guard:clear_lease'
                return
            self._v36_keeper_clear_origin=None
            self.release_kick()
            self._v36_keeper_retry_after=ctx.now+0.18
        # Emergency kick while ball is within controlled foot reach. Don't assume
        # player kick controller will work if the ball is BEHIND the foot.
        # A ball between us and our goal cannot be ignored: move behind it
        # if possible (within legal field), then clear immediately forward.
        # Emergency clearance always outranks normal guard positioning.
        if (allow_clear and ctx.now >= self._v36_keeper_retry_after
                and d <= KEEPER_V37_CLEAR_CONTACT_MAX_M and self.emergency_clear_ready()):
            self._v36_keeper_clear_origin=(ctx.now,(ball.x,ball.y))
            self.emergency_clear()
            return
        # Short, independently triggered interception. Protect posts first when
        # a fast shot is already imminent, else approach shot line until clearable.
        target=decision.target
        if decision.action == 'guard:mouth_rescue':
            self.action='guard:mouth_rescue'
            self._keeper_drive(target,face_ball=False)
            return
        if decision.action == 'guard:opp_winding_up':
            # Most important: DO NOT abandon the line when an opponent starts
            # its shot. Going back to home_x at that moment can open a gap.
            # Retain the keeper's present interception depth if already legal,
            # and slide ON the ball-to-mouth ray instead of retreating sideways.
            max_depth = gx + KEEPER_HOME_X_FROM_GOAL_M + KEEPER_OPP_LANE_HOLD_MAX_FORWARD_M
            if (gx + 0.30 <= pose.x <= max_depth and pose.x <= ball.x - 0.16):
                line_y = ball.y * (pose.x - gx) / max(ball.x - gx, 0.20)
                target = (pose.x, clamp(line_y, -KEEPER_HOME_Y_LIMIT_M, KEEPER_HOME_Y_LIMIT_M))
                self.keeper_decision='guard:hold_shot_line'
        if (allow_clear and decision.dangerous and not decision.covered_by_forward
                and ball.x >= pose.x-0.05 and d <= KEEPER_CLAIM_REACH_M
                and abs(ball.y) <= ctx.field.goal_width/2+0.15
                and decision.action not in ('guard:urgent_block','guard:goal_mouth',
                                            'guard:opp_winding_up','guard:covered_line')):
            tx=clamp(ball.x-0.25, gx+KEEPER_HOME_X_FROM_GOAL_M,
                     gx+KEEPER_PRESS_MAX_ADVANCE_M)
            ty=clamp(ball.y,-KEEPER_PRESS_LATERAL_LIMIT_M,KEEPER_PRESS_LATERAL_LIMIT_M)
            # Never be sucked sideways all the way to a ball outside the posts.
            if abs(ball.y) > ctx.field.goal_width/2:
                ty=target[1]
            target=(tx,ty)
            self.action='guard:claim_line'
        else:
            self.action=decision.action
        self._keeper_drive(target,face_ball=(ball.x > gx + KEEPER_FACE_NEAR_GOAL_M))

    def receive_pass(self, expected_target: tuple[float,float], until: float) -> bool:
        """接球者有限时等待：来球才守候；球落到脚边立即尝试一脚处理。"""
        ctx, pose = self.context, self.pose
        if ctx is None or ctx.ball is None or pose is None or ctx.now > until:
            return False
        ball = ctx.ball
        d = dist(pose.x, pose.y, ball.x, ball.y)
        vx, vy = self.ball_velocity
        speed = math.hypot(vx, vy)
        toward = (vx*(pose.x-ball.x)+vy*(pose.y-ball.y)) / max(0.01,speed*d)
        if d <= RECEIVE_BALL_NEAR_M:
            self.action = 'receive:one_touch'
            self.attack()
            return True
        if speed >= 0.22 and toward >= RECEIVE_PASS_ALIGN_COS and d <= RECEIVE_EXPECTED_MAX_M:
            look = min(0.65, d/max(speed, 0.25))
            # 移到短时落点，但不会像 support() 那样折返到远离传球线的槽位。
            target = (ball.x+vx*look, ball.y+vy*look)
            target = inside(ctx, (0.65*target[0]+0.35*expected_target[0],
                                  0.65*target[1]+0.35*expected_target[1]))
            self.action = 'receive:intercept'
            if dist(pose.x, pose.y,*target) < 0.4:
                self.action = 'receive:hold'
                self.walk_to((pose.x,pose.y),face=angle_to(pose.x,pose.y,ball.x,ball.y),
                             avoid_ball=False)
            else:
                self.walk_to(target, face=None, avoid_ball=False, avoid_robots=True,
                             omni=True, sprint=True, arrive_dist=0.06)
            return True
        if speed < 0.22 and dist(pose.x,pose.y,*expected_target) < 0.85 and d <= 2.6:
            self.action = 'receive:wait'
            self.walk_to((pose.x,pose.y),face=angle_to(pose.x,pose.y,ball.x,ball.y))
            return True
        return False

    def press_ball(self, *, side: int = 1, keeper_owned: bool = False) -> None:
        """第二前锋的实时压迫：追逐球/对手下一步触球点，不能退到固定防守槽。

        此动作只下走路命令。主抢人每帧由到球 ETA 决定，避免同时发两个踢球动作。
        """
        ctx, pose = self.context, self.pose
        if ctx is None or pose is None or ctx.ball is None:
            self.stop()
            return
        ball = ctx.ball
        vx, vy = self.ball_velocity
        speed = math.hypot(vx, vy)
        horizon = min(PRESS_PREDICT_MAX_SEC, dist(pose.x, pose.y, ball.x, ball.y) / max(INTERCEPT_SPEED_MPS, 0.2) * 0.35)
        # 只短时预测，远处高速球不因线性外推跑到场边。
        bx, by = inside(ctx, (ball.x + vx * horizon, ball.y + vy * horizon))
        if keeper_owned:
            # 门将处理球时持续贴近动态二点，而非固定回防槽；让出门将脚前位置。
            gx = -ctx.field.length / 2
            bx = max(bx + KEEPER_PRESS_FORWARD_M, gx + KEEPER_CLAIM_MAX_X_M + 0.15)
            by += float(side) * KEEPER_PRESS_SIDE_M
        else:
            # 相对于主抢手略微错开，压住反攻外侧出球线，但始终跟着球运动。
            by += float(side) * PRESS_SIDE_OFFSET_M
            bx -= PRESS_TRAILING_OFFSET_M
            if speed > 1.8:
                bx = 0.65 * bx + 0.35 * ball.x
                by = 0.65 * by + 0.35 * ball.y
        target = self.walk_point((bx, by))
        self.action = "press:cover_clear" if keeper_owned else "press:chase"
        self.walk_to(target, face=None, avoid_ball=False, avoid_robots=True,
                     sprint=True, arrive_dist=0.08)

    def support(self, zone: str = "middle") -> None:
        ctx, pose = self.context, self.pose
        if ctx is None or pose is None or ctx.ball is None:
            self.stop()
            return
        ball = ctx.ball
        opponent_close = any(q.pose is not None and dist(q.pose.x, q.pose.y, ball.x, ball.y) < 1.1
                             for q in ctx.opponents.values())
        if zone == "danger" or ball.x < 0.0 or self.ball_velocity[0] < -0.35 or opponent_close:
            target = defensive_cover(ctx, self.ball_velocity)
            self.action = "support:recover"
        else:
            target = (ball.x + (0.6 if zone == "attack" else 1.2),
                      ball.y + (-1.7 if ball.y >= 0 else 1.7))
            self.action = "support:receive"
        self.move_to_position(inside(ctx, target), sprint=self.action == "support:recover")

    def reset_kickoff_v35(self) -> None:
        """New restart (or referee transition): forget old SDK lease."""
        self.release_kick()
        self._ko35_mode = 'stage'
        self._ko35_sdk_started = None
        self._ko35_attempts = 0
        self._ko35_last_pose = None
        self._ko35_motion_speed = None
        self._ko35_brake_until = 0.0
        self._ko35_restage_started = None
        self._ko35_entry_ball = None
        self._ko35_last_ball = None
        self._ko35_verified = False
        self._ko35_launch_speed = None
        self._ko35_launch_error_rad = None
        self._ko35_command_heading = None
        self._ko35_event = 'reset'

    def kick_off_direct(self, aim: tuple[float, float], elapsed: float, *, retry: bool = False) -> None:
        """V35: stage -> settle -> SDK lease -> verify or ONE bounded restage.

        Crucial: SDK lease expires relative to its OWN start, not the start of
        the kickoff phase. Continue update_ball() and update_command() every
        control tick until the referee changes phase or the shot is verified.
        Mere low-speed displacement is NOT sufficient evidence of a clean kick.
        The robot cannot choose a foot or bypass the SDK gait on this API.
        """
        ctx, pose = self.context, self.pose
        if ctx is None or ctx.ball is None or pose is None:
            self.stop()
            return
        ball, now = ctx.ball, ctx.now
        if ctx.game is None or ctx.game.state != GameState.PLAYING or ctx.game.stopped:
            self.release_kick()
            self.action = 'kickoff:referee_stop'
            return
        # Observe body motion only with FRESH independent simulator timestamps.
        state = ctx.teammates.get(self.id)
        stamp = state.last_seen_at if state is not None else now
        last = self._ko35_last_pose
        if last is not None and 0.015 < stamp - last[0] <= 0.45:
            self._ko35_motion_speed = math.hypot(pose.x-last[1], pose.y-last[2])/(stamp-last[0])
        self._ko35_last_pose = (stamp, pose.x, pose.y)
        heading = angle_to(ball.x, ball.y, *aim)
        bias = clamp(KICKOFF_EMPIRICAL_BIAS_RAD, -KICKOFF_BIAS_MAX_RAD, KICKOFF_BIAS_MAX_RAD)
        command_heading = normalize_angle(heading-bias)
        d = dist(pose.x, pose.y, ball.x, ball.y)
        dx, dy = ball.x-pose.x, ball.y-pose.y
        front = math.cos(pose.theta)*dx+math.sin(pose.theta)*dy
        side = -math.sin(pose.theta)*dx+math.cos(pose.theta)*dy
        err = normalize_angle(command_heading-pose.theta)
        stable = self._ko35_motion_speed is None or self._ko35_motion_speed <= KICKOFF_V35_ENTRY_SPEED_MAX_MPS
        fresh = now-ball.last_seen_at <= KICKOFF_V35_MAX_STALE_BALL_S
        self._ko35_command_heading = command_heading
        # While KickManager owns the chassis, DO NOT issue walking or face_to.
        if self._ko35_mode == 'sdk':
            since = now-self._ko35_sdk_started
            if self.is_fallen or self.is_penalized:
                self._ko35_event = 'interrupted_fall_or_penalty'
                self._ko35_mode = 'failed'
                self.release_kick()
                self.action = 'kickoff:failed_wait_referee'
                return
            if not fresh:
                # Do not inject stale, potentially incorrect body-frame ball coordinates.
                self._ko35_event = 'stale_ball'
                self.release_kick()
                self._ko35_mode = 'failed'
                self.action = 'kickoff:failed_wait_referee'
                return
            prev = self._ko35_last_ball
            # Strong, forward launch evidence measured at *new ball timestamps*.
            if prev is not None and ball.last_seen_at > prev[0]:
                dt = ball.last_seen_at-prev[0]
                if 0.012 <= dt <= .35:
                    vx=(ball.x-prev[1])/dt;vy=(ball.y-prev[2])/dt
                    v=math.hypot(vx,vy)
                    along=vx*math.cos(heading)+vy*math.sin(heading)
                    moved=dist(ball.x,ball.y,*self._ko35_entry_ball)
                    if (v>=KICKOFF_V35_VERIFIED_SPEED_MPS
                        and along >= KICKOFF_V35_VERIFIED_SPEED_MPS*.7
                        and moved>=KICKOFF_V35_VERIFIED_MOVE_M
                        and since>=.10):
                        actual=math.atan2(vy,vx)
                        self._ko35_launch_speed=v
                        self._ko35_launch_error_rad=normalize_angle(actual-command_heading)
                        self._ko35_verified=True
                        self._ko35_event='verified_launch'
                        self._ko35_mode='launched'
                        self.release_kick()
                        self.action='kickoff:launch_verified'
                        return
            self._ko35_last_ball = (ball.last_seen_at, ball.x, ball.y)
            if since >= KICKOFF_V35_SDK_ATTEMPT_S:
                self.release_kick()
                if self._ko35_attempts > KICKOFF_V35_RETRY_LIMIT or elapsed >= KICKOFF_V35_TOTAL_LIMIT_S-1.0:
                    self._ko35_mode='failed';self._ko35_event='contact_timeout'
                    self.action='kickoff:failed_wait_referee'
                    self.set_velocity(0,0,0)
                    return
                self._ko35_mode='restage'
                self._ko35_restage_started=now
                self._ko35_brake_until=now+KICKOFF_V35_BRAKE_TIME_S
                self._ko35_event='contact_timeout_restage'
                self.action='kickoff:one_reposition'
                self.set_velocity(0,0,0)
                return
            # Important: SDK is a closed-loop automatic controller, and needs
            # current body ball position and current robot-relative heading.
            self.action='kickoff:direct_shoot'
            self._ko35_event='sdk_active'
            self.kick(command_heading,KICKOFF_SHOOT_POWER)
            return
        if self._ko35_mode in ('failed','launched'):
            self.action=('kickoff:launch_verified' if self._ko35_mode=='launched'
                         else 'kickoff:failed_wait_referee')
            self.release_kick()
            self.set_velocity(0,0,0)
            return
        if elapsed >= KICKOFF_V35_TOTAL_LIMIT_S:
            self._ko35_mode='failed'
            self._ko35_event='total_timeout'
            self.action='kickoff:failed_wait_referee'
            self.stop()
            return
        if now < self._ko35_brake_until:
            self.action='kickoff:stabilize'
            self.set_velocity(0,0,0)
            return
        if self._ko35_mode=='restage' and self._ko35_restage_started is not None:
            if now-self._ko35_restage_started > KICKOFF_V35_RESTAGE_TIMEOUT_S:
                self._ko35_mode='failed'
                self._ko35_event='restage_timeout'
                self.action='kickoff:failed_wait_referee'
                self.stop()
                return
        aligned = abs(err) <= KICKOFF_V35_YAW_ERROR_MAX_RAD
        in_zone = (KICKOFF_V35_CONTACT_MIN_M <= front <= KICKOFF_V35_CONTACT_MAX_M
                   and d <= KICKOFF_V35_CONTACT_MAX_M
                   and abs(side) <= KICKOFF_V35_LATERAL_MAX_M)
        if in_zone and aligned and stable and fresh:
            self._ko35_mode='sdk'
            self._ko35_sdk_started=now
            self._ko35_attempts+=1
            self._ko35_entry_ball=(ball.x,ball.y)
            self._ko35_last_ball=(ball.last_seen_at,ball.x,ball.y)
            self._ko35_event='sdk_enter'
            self.action='kickoff:direct_shoot'
            self._draw_kick_target(aim)
            self.kick(command_heading,KICKOFF_SHOOT_POWER)
            return
        if in_zone and aligned and not stable:
            self.action='kickoff:stabilize'
            self._ko35_brake_until=now+KICKOFF_V35_BRAKE_TIME_S
            self.set_velocity(0,0,0)
            return
        if (in_zone or (d <= KICKOFF_V35_CONTACT_MAX_M and pose.x <= ball.x+0.05)) and not aligned:
            self.action='kickoff:align'
            self.face_to(command_heading)
            return
        # Ball too close: stop and let SDK resolve contact if still in kickable
        # range; avoid a dangerous hard backward reposition through the ball.
        if 0.13 <= front < KICKOFF_V35_CONTACT_MIN_M and abs(side)<.14 and aligned:
            self.action='kickoff:near_touch'
            self._ko35_mode='sdk'
            self._ko35_sdk_started=now
            self._ko35_attempts+=1
            self._ko35_entry_ball=(ball.x,ball.y)
            self._ko35_last_ball=(ball.last_seen_at,ball.x,ball.y)
            self._ko35_event='sdk_near_enter'
            self.kick(command_heading,KICKOFF_SHOOT_POWER)
            return
        # One straight stage behind the ball; never use attack/orbit/unstick.
        self.action=('kickoff:one_reposition' if self._ko35_mode=='restage'
                     else 'kickoff:direct_approach')
        point=(ball.x-KICKOFF_V35_STAGE_M*math.cos(heading),
               ball.y-KICKOFF_V35_STAGE_M*math.sin(heading))
        self.walk_to(point, face=command_heading, avoid_ball=False,
                     avoid_robots=False, omni=True, sprint=d>1.0,arrive_dist=.045)

    def take_kickoff(self, kick_target: tuple[float, float] | None = None) -> None:
        """我方开球/重开:未就位则绕到球后待命(避球不碰),就位后接近并踢。"""
        ball = self.context.ball if self.context is not None else None
        if ball is None or self.pose is None:
            self.stop()
            return
        if kick_target is None:
            kick_target = opponent_goal(self.context)
        kick_dir = angle_to(ball.x, ball.y, *kick_target)
        cos_k, sin_k = math.cos(kick_dir), math.sin(kick_dir)
        rel_x, rel_y = self.pose.x - ball.x, self.pose.y - ball.y
        behind = rel_x * cos_k + rel_y * sin_k          # <0 在球后方(己方侧)
        lateral = abs(-rel_x * sin_k + rel_y * cos_k)
        if behind > KICKOFF_FRONT_MARGIN or lateral > KICKOFF_LATERAL_TOL:
            stage = (
                ball.x - cos_k * KICKOFF_STAGE_M,
                ball.y - sin_k * KICKOFF_STAGE_M,
            )
            self.release_kick()
            self.walk_to(stage, face=kick_dir, avoid_ball=True)
        else:
            self.attack(kick_target)

    def move_to_position(self, target: tuple[float, float] | None, *, sprint: bool = False) -> None:
        """走到站位点(支援/防守/避让),面向球,避球+避机器人。"""
        if target is None:
            self.stop()
            return
        face = None
        ball = self.context.ball if self.context is not None else None
        if ball is not None and self.pose is not None:
            face = angle_to(self.pose.x, self.pose.y, ball.x, ball.y)
        self.release_kick()
        self.walk_to(target, face=face, avoid_ball=True, avoid_robots=True, sprint=sprint)

    @staticmethod
    def _angular(err: float) -> float:
        return clamp(ANGULAR_GAIN * err, -MAX_ANGULAR, MAX_ANGULAR)
