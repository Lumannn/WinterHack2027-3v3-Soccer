"""少量纯几何策略：短时预测、到球时间、球路余量、门前封堵。无 SDK 依赖。"""
import math

from .param import BALL_PREDICT_SEC, INTERCEPT_SPEED_MPS, MAX_ANGULAR
from .utils.geom import angle_to, clamp, dist, normalize_angle


def inside(ctx, target, margin=0.35):
    return (clamp(target[0], -ctx.field.length / 2 + margin, ctx.field.length / 2 - margin),
            clamp(target[1], -ctx.field.width / 2 + margin, ctx.field.width / 2 - margin))


def update_ball_motion(ctx, store):
    """只对新观测求差分；暂停、丢球、跳变和时钟复位时清空。"""
    ball = ctx.ball
    old = getattr(store, 'ball_sample', None)
    velocity = getattr(store, 'ball_velocity', (0.0, 0.0))
    if ball is None:
        store.ball_sample = None
        store.ball_velocity = (0.0, 0.0)
        return
    sample = (ball.last_seen_at, ball.x, ball.y)
    if old is None or ctx.game is None or ctx.game.stopped or ctx.game.state.value != 'PLAYING':
        velocity = (0.0, 0.0)
    elif sample[0] != old[0]:
        dt = sample[0] - old[0]
        dx, dy = sample[1] - old[1], sample[2] - old[2]
        if 0.01 <= dt <= 0.5 and math.hypot(dx, dy) / dt <= 12.0:
            # 优先响应新轨迹；不假设摩擦系数。
            velocity = (0.75 * dx / dt + 0.25 * velocity[0],
                        0.75 * dy / dt + 0.25 * velocity[1])
        else:
            velocity = (0.0, 0.0)
    if ctx.now - ball.last_seen_at > 0.25:
        velocity = (0.0, 0.0)
    store.ball_sample, store.ball_velocity = sample, velocity


def arrival_time(pose, target):
    d = dist(pose.x, pose.y, *target)
    turn = abs(normalize_angle(angle_to(pose.x, pose.y, *target) - pose.theta))
    return d / INTERCEPT_SPEED_MPS + 0.25 * turn / MAX_ANGULAR


def intercept(ctx, pose, velocity):
    """固定 7 个采样点，选择最早可达点；不可达则选时间差最小点。"""
    best, best_gap, best_eta = (ctx.ball.x, ctx.ball.y), math.inf, math.inf
    for i in range(7):
        t = BALL_PREDICT_SEC * i / 6
        target = inside(ctx, (ctx.ball.x + velocity[0] * t, ctx.ball.y + velocity[1] * t))
        eta = arrival_time(pose, target)
        if eta <= t + 0.15:
            return target, eta
        if eta - t < best_gap:
            best, best_gap, best_eta = target, eta - t, eta
    return best, best_eta


def lane_clearance(ctx, target, exclude_id=None, receiver_id=None):
    """球→目标线段内的机器人中心最小距离，队友也会挡球。"""
    bx, by = ctx.ball.x, ctx.ball.y
    dx, dy = target[0] - bx, target[1] - by
    length2 = dx * dx + dy * dy
    if length2 < 1e-6:
        return 0.0
    result = math.inf
    robots = [r for pid, r in ctx.teammates.items() if pid not in (exclude_id, receiver_id)]
    robots += list(ctx.opponents.values())
    for r in robots:
        if r.pose is None:
            continue
        t = ((r.pose.x - bx) * dx + (r.pose.y - by) * dy) / length2
        if 0.04 < t < 1.05:
            t = clamp(t, 0.0, 1.0)
            result = min(result, dist(r.pose.x, r.pose.y, bx + t * dx, by + t * dy))
    return result


def keeper_target(ctx, velocity):
    """提前预测门前落点：球还在禁区前时就沿封堵线横移，而非球越过身侧才追。"""
    from .param import (KEEPER_BLOCK_X_FROM_GOAL_M, KEEPER_PREDICT_MAX_SEC,
                        KEEPER_PREPARE_RANGE_X_M, KEEPER_THREAT_SPEED_MPS)
    gx = -ctx.field.length / 2
    x = gx + KEEPER_BLOCK_X_FROM_GOAL_M
    ball = ctx.ball
    if ball is None:
        return (x, 0.0), False
    # 静态时站在球→本方球门的连线，提升近门球的侧向覆盖。
    ratio = clamp((x - gx) / max(ball.x - gx, 0.10), 0.0, 1.0)
    y = ball.y * ratio
    vx, vy = velocity
    threat = False
    if vx < -KEEPER_THREAT_SPEED_MPS and ball.x > x:
        t = (x - ball.x) / vx
        if 0 <= t <= KEEPER_PREDICT_MAX_SEC:
            projected_y = ball.y + vy * t
            # 只对可能进入门框周围的轨迹抢先封堵，防止被边线球骗离球门。
            if abs(projected_y) <= ctx.field.goal_width / 2 + 0.55:
                y, threat = projected_y, True
    # 对手持球停在本方禁区外时也提前预置，不再始终守在门框中心。
    if not threat and ball.x < gx + KEEPER_PREPARE_RANGE_X_M:
        near_opp = any(q.pose and math.hypot(q.pose.x-ball.x,q.pose.y-ball.y) < 1.3
                       for q in ctx.opponents.values())
        if near_opp:
            y = 0.76 * ball.y * ratio + 0.24 * clamp(ball.y, -0.8, 0.8)
    return (x, clamp(y, -ctx.field.goal_width / 2 + 0.20,
                    ctx.field.goal_width / 2 - 0.20)), threat


def update_zone(ctx, store):
    """三区 + 0.3m 迟滞，不增加顶层比赛状态。"""
    from .param import DANGER_ZONE_X, ATTACK_ZONE_X, ZONE_HYSTERESIS_M
    x = ctx.ball.x
    old = getattr(store, 'zone', 'middle')
    h = ZONE_HYSTERESIS_M
    if old == 'danger' and x < DANGER_ZONE_X + h:
        zone = 'danger'
    elif old == 'attack' and x > ATTACK_ZONE_X - h:
        zone = 'attack'
    else:
        zone = 'danger' if x < DANGER_ZONE_X else 'attack' if x > ATTACK_ZONE_X else 'middle'
    store.zone = zone
    return zone


def legal_walk_point(ctx, target, margin=0.22, *, kickoff_taker=False):
    """场界及开球站位约束；裁判未解除开球阶段前保守约束路径。"""
    from .framework.types import GameState, SetPlay, KICKING_TEAM_NONE
    target = inside(ctx, target, margin)
    g = ctx.game
    kickoff = (g is not None and g.set_play == SetPlay.NONE and g.secondary_time > 0
               and g.kicking_team != KICKING_TEAM_NONE)
    if g is not None and (g.state == GameState.READY or kickoff):
        ours = g.kicking_team == ctx.team_id
        if not (ours and kickoff and kickoff_taker and math.hypot(*target) <= ctx.field.circle_radius - 0.22):
            target = (min(target[0], -0.22), target[1])
        if not ours and math.hypot(*target) < ctx.field.circle_radius + 0.22:
            a = math.atan2(target[1], min(target[0], -0.22))
            radius = ctx.field.circle_radius + 0.22
            target = (radius * math.cos(a), radius * math.sin(a))
    return target


def restart_retreat(ctx, target, radius=None):
    """V37 feasible SAFE point for opposing restart, including touchline balls.

    Old code could clamp every candidate against the touchline, ending up
    closer than the referee-exclusion distance. Never return an illegal
    candidate as a fallback. Distance applies to the robot center; margins
    include conservative space for the robot body and uncertain rule radius.
    """
    from .param import RESTART_V37_CLEARANCE_M, RESTART_V37_FIELD_MARGIN_M
    if ctx.ball is None:
        return inside(ctx, target, RESTART_V37_FIELD_MARGIN_M)
    bx, by = ctx.ball.x, ctx.ball.y
    minimum = max(RESTART_V37_CLEARANCE_M, radius or 0.0)
    wish = inside(ctx, target, RESTART_V37_FIELD_MARGIN_M)
    if dist(*wish, bx, by) >= minimum:
        return wish
    half_x = ctx.field.length / 2 - RESTART_V37_FIELD_MARGIN_M
    half_y = ctx.field.width / 2 - RESTART_V37_FIELD_MARGIN_M
    # Sample legal candidates in field interior, with a deterministic tie break.
    # Includes entire field as a fallback for impossible local annulus samples.
    candidates = []
    for rad in (minimum+0.10, minimum+0.45, minimum+0.90, minimum+1.50):
        for i in range(72):
            a = 2*math.pi*i/72
            x,y = bx+rad*math.cos(a), by+rad*math.sin(a)
            if -half_x <= x <= half_x and -half_y <= y <= half_y:
                if dist(x,y,bx,by) >= minimum - 1e-7:
                    candidates.append((x,y))
    if not candidates:
        for i in range(29):
            for j in range(19):
                p = (-half_x+2*half_x*i/28, -half_y+2*half_y*j/18)
                if dist(*p,bx,by) >= minimum:
                    candidates.append(p)
    if not candidates:
        # The field is larger than the avoidance disk under M-field rules;
        # stop is safer than fabricating an illegal target if field dimensions change.
        return None
    return min(candidates, key=lambda p: (dist(*p, *wish), -dist(*p,bx,by), p[0],p[1]))


def goal_gap_target(ctx, player_id):
    """Choose a real gap inside the actual goal posts, allowing aiming error.

    Uses goal line x=field.length/2, goal_width from framework. No screen pixel
    guesses. Checks two neighboring rays too: a single unobstructed pixel-ray
    is not a viable shot. The margins are engineering assumptions, not calibrated
    physical guarantees.
    """
    from .param import (SHOT_POST_MARGIN_M, SHOT_CLEARANCE_M,
                        SHOT_DIRECTION_TOL_RAD, SHOT_MIN_OPEN_ANGLE_RAD)
    gx = ctx.field.length / 2.0
    if ctx.ball is None or ctx.ball.x >= gx - 0.05:
        return None
    half = ctx.field.goal_width / 2 - SHOT_POST_MARGIN_M
    if half <= .12:
        return None
    bx,by = ctx.ball.x,ctx.ball.y
    dx = gx - bx
    # Angle noise shifts impact points more for long shots; reserve extra margin.
    bound = max(0.10, half - dx * math.tan(SHOT_DIRECTION_TOL_RAD))
    if bound <= .12:
        return None
    runs=[]; current=[]
    for i in range(81):
        y = -bound + 2*bound*i/80
        # +/-0.11 at the goal line: makes the lane less brittle to command noise.
        safe = all((abs(yy) <= half and
                    lane_clearance(ctx,(gx,yy),player_id) >= SHOT_CLEARANCE_M)
                   for yy in (y-0.11,y,y+0.11))
        if safe:
            current.append(y)
        elif current:
            runs.append(current); current=[]
    if current:
        runs.append(current)
    if not runs:
        return None
    def angular_span(run):
        return math.atan2(run[-1]-by,dx)-math.atan2(run[0]-by,dx)
    valid=[run for run in runs if angular_span(run)>=SHOT_MIN_OPEN_ANGLE_RAD]
    if not valid:
        return None
    run=max(valid,key=lambda rr:(angular_span(rr),-abs((rr[0]+rr[-1])/2)))
    y=(run[0]+run[-1])/2
    return (gx,y)


def defensive_cover(ctx, velocity):
    """第二人保护球后纵深，偏向未持球的对手接应点。"""
    ball = ctx.ball
    gx = -ctx.field.length / 2
    future = inside(ctx, (ball.x + velocity[0] * .35, ball.y + velocity[1] * .35))
    tx = clamp(future[0] - 1.8, gx + 2.0, -0.5)
    ratio = clamp((tx - gx) / max(future[0] - gx, .2), 0, 1)
    y = future[1] * ratio
    rivals = [q.pose for q in ctx.opponents.values() if q.pose]
    carrier = min(rivals, key=lambda q: dist(q.x, q.y, ball.x, ball.y), default=None)
    receivers = [q for q in rivals if q is not carrier and q.x < ball.x + .7
                 and abs(q.y - ball.y) > .8]
    if receivers:
        receiver = min(receivers, key=lambda q: q.x)
        y = .6 * y + .4 * receiver.y
    return inside(ctx, (tx, y))
