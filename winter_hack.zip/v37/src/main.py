"""SoccerSim 策略入口 —— 比赛策略主逻辑都在这里,改打法就改这个文件。

结构(由浅入深):
- main.py(本文件):比赛策略。play() 按 Phase 状态机分派到 _act_*;各 _act_* 选出
  attacker(离球最近)并直接调 player 动作。
- player.py:Player 控制 handle + 高层动作(attack / take_kickoff /
  move_to_position / walk_to);想加拐棍/技术动作直接改它。
- utils/:走位/几何/避障工具(opponent_goal / dist / angle_to ...)。
- framework/:平台管线,用户不改。

改打法主要改本文件:Phase 状态机、各 _act_* 行为、站位公式。
"""

from __future__ import annotations

import logging
import math
from enum import Enum

from booster_agent_framework import AgentBase

from .framework.agent import SoccerAgentMixin
from .framework.config import SoccerConfig
from .framework.types import KICKING_TEAM_NONE, Context, GameState, SetPlay
from .param import *
from .player import Player
from .utils import dist, opponent_goal, own_goal
from .utils.geom import clamp
from .tactics import inside, intercept, update_ball_motion, update_zone, restart_retreat
from .telemetry import record_frame


_log = logging.getLogger(__name__)


# ======================================================================
# Phase 状态机 —— 比赛阶段分类
# ======================================================================


class Phase(Enum):
    """比赛阶段。顶层状态机,决定当前是正常拼抢/开球/定位球/准备/停止。"""
    NORMAL = "normal"              # PLAYING 正常拼抢
    OUR_KICKOFF = "our_kickoff"    # 我方开球(SET+PLAYING 初期,take_kickoff)
    OPP_KICKOFF = "opp_kickoff"    # 对方开球(避让)
    OUR_SET_PLAY = "our_set_play"  # 我方定位球(任意球/角球/球门球)
    OPP_SET_PLAY = "opp_set_play"  # 对方定位球(避让)
    READY = "ready"                # READY 走位
    STOPPED = "stopped"            # SET(非开球重开) / INITIAL / FINISHED / stopped


def get_phase(context: Context) -> Phase:
    """根据裁判机状态判断当前比赛阶段。"""
    g = context.game
    if g is None:
        return Phase.STOPPED

    if g.stopped:
        return Phase.STOPPED
    state = g.state

    # READY:走 ready 位
    if state == GameState.READY:
        return Phase.READY

    # PLAYING:正常拼抢 or 开球/定位球执行中
    if state == GameState.PLAYING and not g.stopped:
        # 定位球:set_play != NONE,kicking_team 指示哪方
        if g.set_play != SetPlay.NONE and g.kicking_team != KICKING_TEAM_NONE:
            our_team = context.team_id
            if g.kicking_team == our_team:
                return Phase.OUR_SET_PLAY
            else:
                return Phase.OPP_SET_PLAY

        # 开球:secondary_time > 0(倒计时窗口),kicking_team 指示哪方
        if g.secondary_time > 0 and g.kicking_team != KICKING_TEAM_NONE:
            our_team = context.team_id
            if g.kicking_team == our_team:
                return Phase.OUR_KICKOFF
            else:
                return Phase.OPP_KICKOFF

        # 正常拼抢
        return Phase.NORMAL

    # SET / INITIAL / FINISHED / stopped:站定
    return Phase.STOPPED

def get_set_play_type(context: Context) -> SetPlay:
    """当前生效的定位球类型;无定位球(或无裁判机数据)时返回 ``SetPlay.NONE``。

    直接读裁判机的 ``set_play`` 字段,不区分是哪方主罚 —— 哪方由 :func:`get_phase`
    (OUR_SET_PLAY / OPP_SET_PLAY)判定。这里只回答"是什么类型的定位球"。

    共 7 种可能返回值(见 framework.types.SetPlay):
    - ``NONE``:无定位球(正常比赛/开球等)
    - ``DIRECT_FREE_KICK``:直接任意球(可直接射门得分)
    - ``INDIRECT_FREE_KICK``:间接任意球(须先触碰他人才能进球)
    - ``PENALTY_KICK``:点球
    - ``THROW_IN``:界外球(踢入)
    - ``GOAL_KICK``:球门球
    - ``CORNER_KICK``:角球
    """
    g = context.game
    if g is None:
        return SetPlay.NONE
    return g.set_play


# ======================================================================
# Agent 入口
# ======================================================================


def validate_red_identity(config):
    if config.team_id != 1 or config.robot_names != ("robot1", "robot2", "robot3"):
        raise ValueError("V37 is Red Challenger only: SOCCER_TEAM_ID=1; "
                         "SOCCER_ROBOT_NAMES=robot1,robot2,robot3")


class SoccerSimAgent(SoccerAgentMixin, AgentBase):
    """3v3 SoccerSim agent。"""

    player_class = Player

    def __init__(self):
        # 在创建 SDK handle 之前校验，拒绝把红队策略部署成蓝队控制器。
        config = SoccerConfig.from_env()
        validate_red_identity(config)
        super().__init__()

    def init_store(self, store) -> None:
        _log.info("V37 build=3.7.0 agent_id=com.winterhack.red.simple.v37 init_store")
        store.prev_phase = None       # 上一帧 phase,用于检测 phase 跳变(边沿)
        store.cur_phase = None
        store.kickoff_taker = None    # 锁定的开球主罚球员 id(每次进入开球时重选)
        store.normal_attacker = None
        store.zone = "middle"
        store.ball_sample = None
        store.ball_velocity = (0.0, 0.0)
        store.kickoff_origin = None
        store.kickoff_moved_at = None
        store.kickoff_started_at = None
        store.kickoff_aim = None
        store.kickoff_attempt_done = False
        store.restart_taker = None
        store.restart_origin = None
        store.restart_moved_at = None
        store.restart_type = None
        store.kickoff_finished_until = 0.0
        store.kickoff_receiver_id = 3
        store.pass_receiver_id = None
        store.pass_expected_target = None
        store.pass_started_at = 0.0

    def on_agent_activated(self) -> None:
        _log.info("V37 build=3.7.0 agent_id=com.winterhack.red.simple.v37 activated")
        super().on_agent_activated()

    @staticmethod
    def play(context: Context, players: list[Player], store) -> None:
        phase = get_phase(context)
        update_ball_motion(context, store)
        for p in players:
            p.ball_velocity = store.ball_velocity
            p.foot_side_hint = None
            p.keeper_decision = None
            p.keeper_line_covered = None
            p.target = None
            p.restart_taker = False
            p.kickoff_taker = False
        store.prev_phase = store.cur_phase
        store.cur_phase = phase
        if store.prev_phase != phase:
            for p in players:
                p.release_kick()
                p._kick_retry_until = 0.0
                p._nav_watch = None

        # 画可视化(每帧)
        _analyze_and_draw(context, players, store)

        # 当前 phase 以 label 画在场外。
        from .framework import debugdraw
        g = context.game
        game_state = g.state.value if g is not None else "none"
        set_play = g.set_play.value if g is not None else "none"
        secondary_time = g.secondary_time if g is not None else 0.0
        debugdraw.text(
            0.0, context.field.width / 2.0 + 0.2,
            f"phase={phase.value} state={game_state} set={set_play} secondary={secondary_time:.1f}",
            rgb=(1.0, 1.0, 0.0), ns="phase",
        )

        # 活性自理 + 过滤出本帧可行动的球员。
        # ensure_ready:摔倒起身 / 切 walk 模式(异步,不产生移动);被罚下的也做,
        # 这样解罚后能立刻投入。被罚下或未就绪的不参与分派(也不进角色分配,避免把
        # 动不了的人选成 attacker 导致该帧无人进攻)。
        active: list[Player] = []
        for p in players:
            # Penalties and SET/stopped phases take priority over any SDK
            # action, including get-up and mode switching.
            if p.is_penalized:
                st = context.game.get_player_state(context.team_id, p.id)
                secs = st.secs_till_unpenalised if st is not None else None
                p.action = f"penalized:{p.penalty.value}:{secs}s"
                p.stop()
                continue
            if phase == Phase.STOPPED:
                p.action = 'stopped'
                p.stop()
                continue
            ready = p.ensure_ready()
            if not ready:
                p.release_kick()
                p.action = "fallen" if p.is_fallen else "switching_mode"
            elif p.pose is None:
                p.action = "no_pose"
                p.stop()
            else:
                active.append(p)

        # 按 phase 对整队分派一次(角色分配等全队计算只在 _act_* 里算一次)。
        if phase == Phase.NORMAL:
            _act_normal(context, active, store)
        elif phase == Phase.OUR_KICKOFF:
            _clear_normal_sticky(store)
            _act_our_kickoff(context, active, store)
        elif phase == Phase.OPP_KICKOFF:
            _clear_normal_sticky(store)
            _act_opp_kickoff(context, active)
        elif phase == Phase.OUR_SET_PLAY:
            _clear_normal_sticky(store)
            _act_our_set_play(context, active, store)
        elif phase == Phase.OPP_SET_PLAY:
            _clear_normal_sticky(store)
            _act_opp_set_play(context, active, store)
        elif phase == Phase.READY:
            _clear_normal_sticky(store)
            _act_ready(context, active)
        elif phase == Phase.STOPPED:
            _clear_normal_sticky(store)
            for p in active:
                p.action = "stopped"
                p.stop()

        # 队员可视化统一在最后画一遍:覆盖所有球员(含判罚/未就绪/STOPPED),
        # 修复 SET 等状态下红球/标签消失的问题。
        for p in players:
            _draw_teammate_marker(p)
        record_frame(context, players, store)
        last_status = getattr(store, "status_at", -math.inf)
        if context.now - last_status >= 2.0 or context.now < last_status:
            store.status_at = context.now
            _log.info("V37 status phase=%s ball=%s active=%s robots=%s", phase.value,
                      context.ball is not None, [p.id for p in active],
                      [(p.id, p.mode, p.action) for p in players])


def _clear_normal_sticky(store) -> None:
    store.normal_attacker = None


def _player_dist_to_ball(context: Context, p: Player) -> float:
    """球员到球当前位置的距离。"""
    ball = context.ball
    return (
        dist(p.pose.x, p.pose.y, ball.x, ball.y) + _fallen_time_cost(p)
        if ball is not None else math.inf
    )


def _fallen_time_cost(p: Player) -> float:
    return FALLEN_COST if p.is_fallen else 0.0


def _select_closest_attacker(
    context: Context,
    players: list[Player],
    preferred_id: int | None = None,
) -> Player:
    """按短时预测的到球时间选择球员。

    ``players`` 非空、已就绪、pose 已知。normal 与开球共用。
    """
    if context.ball is None:
        return next((p for p in players if p.id == preferred_id), players[0])
    def control_eta(p):
        # Interception ETA alone is not control ETA: a robot next to the ball
        # with the ball behind its heels can lose to a slightly farther robot.
        eta = intercept(context, p.pose, p.ball_velocity)[1]
        b = context.ball
        dx, dy = b.x - p.pose.x, b.y - p.pose.y
        ct, st = math.cos(p.pose.theta), math.sin(p.pose.theta)
        forward = dx * ct + dy * st
        lateral = -dx * st + dy * ct
        d = math.hypot(dx, dy)
        if d <= SHOT_NEAR_BALL_ENTER_M and (-0.09 <= forward <= 0.60 and
                abs(lateral) <= SHOT_BODY_LATERAL_MAX_M):
            eta = max(0.0, eta - ATTACKER_FOOT_CONTROL_BONUS_SEC)
        elif forward < -0.12:
            eta += ATTACKER_BALL_BEHIND_COST_SEC
        # Wrong side of the ball requires a longer route to take a forward shot.
        if d < 1.1 and p.pose.x > b.x + 0.18:
            eta += ATTACKER_ATTACK_SIDE_COST_SEC
        return eta

    ranked = [(p, control_eta(p)) for p in players]
    best, best_dist = min(ranked, key=lambda item: item[1])
    preferred = next((item for item in ranked if item[0].id == preferred_id), None)
    if (
        preferred is not None
        and preferred[1] <= best_dist + ATTACKER_KEEP_ETA_MARGIN_SEC
    ):
        return preferred[0]
    return best


def _split_team(context, players):
    """优先保留 robot2 守门；不可用时由最靠近己方门者替补。"""
    if len(players) <= 1:
        return None, players
    guard = next((p for p in players if p.id == KEEPER_ID), None)
    if guard is None:
        gx, gy = own_goal(context)
        guard = min(players, key=lambda p: dist(p.pose.x, p.pose.y, gx, gy))
    return guard, [p for p in players if p is not guard]


def _keeper_independent(context: Context, guard: Player | None,
                        field: list[Player], *, allow_clear: bool = True) -> None:
    """Runs goalkeeper once per tick, independent of both forward states."""
    if guard is None:
        return
    forward_poses = tuple(p.pose for p in field if p.pose is not None)
    guard.guard(allow_clear=allow_clear, forwards=forward_poses)


def _forward_separation(context, attacker: Player, partner: Player) -> bool:
    """Move second striker to a forward receiving lane when they would crowd."""
    if attacker.pose is None or partner.pose is None or context.ball is None:
        return False
    if dist(attacker.pose.x,attacker.pose.y,partner.pose.x,partner.pose.y) >= FORWARD_SEPARATION_M:
        return False
    ball=context.ball
    side=-1 if attacker.pose.y >= ball.y else 1
    target=inside(context,(max(ball.x+FORWARD_SUPPORT_LEAD_M, partner.pose.x+0.6),
                           clamp(ball.y+side*FORWARD_SUPPORT_SIDE_M,-3.6,3.6)))
    partner.action='support:separate_forward'
    partner.walk_to(target,avoid_ball=False,avoid_robots=True,
                    omni=True,sprint=True,arrive_dist=0.10)
    return True


def _act_normal(context: Context, players: list[Player], store) -> None:
    """活球：一人主抢、一人动态逼抢/接应、门将先封线再判断是否出击。

    第二名前锋在对方反攻时不能被固定防守点锁住。门将接管仅限门前危险区，
    同帧只允许一个机器人进入 SDK KickManager，其他人不放弃压迫。
    """
    if not players:
        return
    guard, field = _split_team(context, players)
    if context.ball is None:
        for p in players:
            p.stop()
        return
    zone = update_zone(context, store)
    ball = context.ball
    if not field:                         # 只剩门将仍要正常处理球
        _keeper_independent(context,guard,[],allow_clear=True)
        store.normal_attacker = None
        return

    # 开球接球人的任务不要在 PLAYING 清除 secondary_time 后的下一帧突然消失。
    # 只在开球已真正触球、球留在中线附近向前移动时短时保留前插。
    follow_until = getattr(store, 'kickoff_finished_until', 0.0)
    kickoff_receiver = next((p for p in field if p.id == getattr(store, 'kickoff_receiver_id',3)), None)
    if (kickoff_receiver is not None and context.now < follow_until
            and ball.x > -0.55 and ball.x < 4.8
            and not any(q.pose and dist(q.pose.x,q.pose.y,ball.x,ball.y) < 0.75
                        for q in context.opponents.values())):
        taker = next((p for p in field if p is not kickoff_receiver),None)
        _keeper_independent(context,guard,field,allow_clear=True)
        near_receiver = (dist(kickoff_receiver.pose.x,kickoff_receiver.pose.y,ball.x,ball.y)
                         < RECEIVE_BALL_NEAR_M)
        if taker is not None:
            if near_receiver:
                # 只有一个 SDK 踢球控制器接管，防止两人同时踢同一球。
                taker.release_kick()
                taker.press_ball(side=1 if taker.pose.y > ball.y else -1)
            else:
                taker.attack()
        if near_receiver:
            kickoff_receiver.attack()
        else:
            kickoff_receiver.action = 'kickoff:receiver_sprint'
            bx= max(ball.x + 0.65, 1.0)
            by = clamp(ball.y + (-1.50 if taker is None or taker.pose.y >= ball.y else 1.50),
                       -2.4, 2.4)
            kickoff_receiver.walk_to(inside(context,(bx,by)),avoid_ball=False,
                                     avoid_robots=True,omni=True,sprint=True,arrive_dist=0.05)
        store.normal_attacker = taker.id if taker else kickoff_receiver.id
        return

    preferred = getattr(store, "normal_attacker", None)
    if store.prev_phase == Phase.OUR_KICKOFF:
        preferred = store.kickoff_taker
    attacker = _select_closest_attacker(context, field, preferred)
    receiver_lock = next((p for p in field
                          if p.id == getattr(store,'pass_receiver_id',None)),None)
    if (receiver_lock is not None and context.now <= getattr(store,'pass_started_at',0)
            + RECEIVE_HOLD_MAX_SEC
            and dist(receiver_lock.pose.x,receiver_lock.pose.y,ball.x,ball.y) < 0.53):
        # 接球者已近球时独占本帧出脚权，避免传球人和接球人双 KickManager。
        attacker = receiver_lock
    # 独立门将不再抢夺/重置前锋踢球控制器，更不因自己踢球强制前锋停球。
    _keeper_independent(context, guard, field, allow_clear=True)

    # 主抢手交给当下最有机会到球的前锋。守门员无权抢占主抢线路。
    store.normal_attacker = attacker.id
    for p in field:
        if p is not attacker:
            p.release_kick()
    attacker.attack()

    # 传球后保留接球者的短时来球窗口，避免因为每帧 support/press 切换而错过空位。
    receiver = next((p for p in field if p.id == getattr(store, 'pass_receiver_id', None)), None)
    if receiver is not None and receiver is not attacker:
        if (receiver.receive_pass(getattr(store, 'pass_expected_target', None) or
                                  (receiver.pose.x,receiver.pose.y),
                                  store.pass_started_at + RECEIVE_HOLD_MAX_SEC)):
            return
    # 对即将到来的传球安排接应锁：只有真正启动 SDK 的传球才激活。
    if attacker.action == 'attack:pass' and attacker.is_kicking:
        other = next((q for q in field if q is not attacker), None)
        aim = getattr(attacker, 'aim_target', None)
        if (other is not None and aim is not None and other.pose is not None and ball.x > 0
                and dist(other.pose.x,other.pose.y,*aim) <= 1.25):
            store.pass_receiver_id = other.id
            store.pass_expected_target = aim
            store.pass_started_at = context.now

    # 正常反击：只要对手已接近球/球朝我方滚动，第二前锋立即参与逼抢；
    # 未受威胁时进入动态接应，避免两人全程同时冲球造成撞人。
    opponent_claim = any(
        r.pose is not None and dist(r.pose.x, r.pose.y, ball.x, ball.y) < PRESS_OPPONENT_NEAR_M
        for r in context.opponents.values()
    )
    counterattack = (opponent_claim or attacker.ball_velocity[0] < -PRESS_BACKWARD_VX_MPS
                     or ball.x < PRESS_DEFENSIVE_X_M)
    for p in field:
        if p is attacker:
            continue
        if counterattack:
            if not _forward_separation(context,attacker,p):
                p.press_ball(side=1 if p.pose.y >= ball.y else -1)
        else:
            if not _forward_separation(context,attacker,p):
                p.support(zone)


def _act_our_kickoff(context: Context, players: list[Player], store) -> None:
    """V32: single direct shot into a SAFE CORNER of the far goal.

    Prevent the 10-20s `fixed_diagonal -> unstick -> screen_orbit` loop:
    - keep goal aim stable for the whole restart;
    - bypass regular attack() entirely while our kickoff is active;
    - at most one short reposition, never an infinite oscillation;
    - if the ball moves, stop issuing kickoff shots immediately.
    """
    if not players:
        return
    guard, field = _split_team(context, players)
    ball = context.ball
    if ball is None:
        for p in players:p.stop()
        return
    # Never issue a kickoff kick solely because a prior phase/store says ours.
    # The current referee message and centered restart ball must both agree.
    g = context.game
    if (g is None or g.stopped or g.state != GameState.PLAYING
            or g.set_play != SetPlay.NONE
            or g.kicking_team not in (context.team_id, KICKING_TEAM_NONE)
            or (g.kicking_team == context.team_id and g.secondary_time <= 0)
            or (store.prev_phase != Phase.OUR_KICKOFF and math.hypot(ball.x,ball.y) > 0.65)):
        # In production, play() dispatches here ONLY for explicit referee ownership.
        # The NONE owner is tolerated solely for direct unit calls to this helper.
        for p in field:
            p.release_kick()
            p.action='kickoff:referee_not_ours_or_not_center'
            p.stop()
        if guard: _keeper_independent(context,guard,field,allow_clear=False)
        return
    ids={p.id for p in field}
    if not field:
        if guard:_keeper_independent(context,guard,field,allow_clear=True)
        return
    if store.prev_phase != Phase.OUR_KICKOFF or getattr(store,'kickoff_taker',None) not in ids:
        store.kickoff_taker = 1 if 1 in ids else _select_closest_attacker(context, field).id
        store.kickoff_origin = (ball.x,ball.y)
        store.kickoff_moved_at = None
        store.kickoff_started_at = context.now
        store.kickoff_attempt_done = False
        for p in field:
            if p.id == store.kickoff_taker:
                p.reset_kickoff_v35()
        # Actual corners of mouth x=+7,y=+/-1.3; DO NOT aim at post.
        gx=context.field.length/2.0
        ysafe=min(KICKOFF_GOAL_Y_M,context.field.goal_width/2.0-KICKOFF_AIM_ERROR_RESERVE_M)
        options=[(gx,ysafe),(gx,-ysafe)]
        from .tactics import lane_clearance
        # Pick the clearer of the two *once*. Never flip every frame.
        store.kickoff_aim=max(options,key=lambda q:(lane_clearance(context,q,store.kickoff_taker),-q[1]))
    taker=next(p for p in field if p.id == store.kickoff_taker)
    taker.kickoff_taker=True
    bx,by=store.kickoff_origin or (ball.x,ball.y)
    moved=dist(ball.x,ball.y,bx,by)>KICKOFF_MOVE_CONFIRM_M
    if moved and getattr(store,'kickoff_moved_at',None) is None:
        store.kickoff_moved_at=context.now
        store.kickoff_finished_until=context.now+KICKOFF_FOLLOW_SEC
    elapsed=max(0.0,context.now - (context.now if getattr(store,'kickoff_started_at',None) is None else store.kickoff_started_at))
    # V36: a weak 0.4m nudge is NOT a successful kickoff. Keep the
    # direct-shot controller active (SDK or its ONE restage) until a verified
    # fast launch, a clearly escaped ball, referee phase change or timeout.
    progressed=dist(ball.x,ball.y,bx,by)
    if (not getattr(taker,'_ko35_verified',False) and
            (not moved or getattr(taker,'_ko35_attempts',0)>0) and
            progressed < 1.15 and elapsed < KICKOFF_V35_TOTAL_LIMIT_S):
        taker.kick_off_direct(getattr(store,'kickoff_aim',None) or
                              (context.field.length/2, KICKOFF_GOAL_Y_M),elapsed)
    elif not moved and elapsed < KICKOFF_V35_TOTAL_LIMIT_S:
        # Player owns an independent SDK lease and must not be interrupted
        # by the overall kickoff timer's old direct/retry branches.
        taker.kick_off_direct(getattr(store,'kickoff_aim',None) or (context.field.length/2,KICKOFF_GOAL_Y_M), elapsed)
    elif not moved:
        taker.release_kick()
        taker.action = 'kickoff:failed_wait_referee'
        taker.stop()  # referee determines restart timeout
    else:
        # The SDK has either verified a clean launch, or the ball was moved by
        # another agent. In either case the restart is over; return to chase.
        taker.release_kick()
        taker.action = 'kickoff:shot_follow'
        future=inside(context,(max(ball.x+0.45,0.8),ball.y))
        taker.walk_to(future,omni=True,sprint=True,avoid_ball=False,avoid_robots=True)
    if guard:
        _keeper_independent(context,guard,field,allow_clear=True)
    for p in field:
        if p is taker:continue
        if not moved:
            p.action='kickoff:rebound_ready'
            p.move_to_position((KICKOFF_RECEIVER_X,KICKOFF_RECEIVER_Y),sprint=True)
        else:
            # Sprint to opponent half for second balls, not back to home slots.
            rebound=inside(context,(max(1.3,ball.x+FORWARD_SUPPORT_LEAD_M),
                                    clamp(ball.y+(-FORWARD_SUPPORT_SIDE_M if taker.pose.y>=ball.y else FORWARD_SUPPORT_SIDE_M),-3.1,3.1)))
            p.action='kickoff:rebound_chase'
            p.walk_to(rebound,avoid_ball=False,avoid_robots=True,
                      sprint=True,omni=True,arrive_dist=0.07)


def _act_opp_kickoff(context: Context, players: list[Player]) -> None:
    """对方开球:一人守门,其余人站到中圈外固定点等待。"""
    if not players:
        return
    guard, rest = _split_team(context, players)
    if guard:
        _keeper_independent(context,guard,rest,allow_clear=False)
    r = context.field.circle_radius
    slots = [(-r - 0.5, 0.0), (-r - 2.0, 0.5)]
    for p, target in zip(rest, slots):
        p.action = "opp_kickoff:ready"
        p.walk_to(target, avoid_ball=True, avoid_robots=True)


def _act_our_set_play(context: Context, players: list[Player], store) -> None:
    if not players:
        return
    guard, field = _split_team(context, players)
    if context.ball is None:
        for p in players:
            p.stop()
        return
    kind = get_set_play_type(context)
    if (store.prev_phase != Phase.OUR_SET_PLAY or getattr(store, "restart_type", None) != kind
            or getattr(store, "restart_taker", None) not in {p.id for p in field}):
        store.restart_taker = _select_closest_attacker(context, field).id
        store.restart_origin = (context.ball.x, context.ball.y)
        store.restart_moved_at = None
        store.restart_type = kind
    taker = next(p for p in field if p.id == store.restart_taker)
    receiver = next((p for p in field if p is not taker), None)
    taker.restart_taker = True
    ball = context.ball
    moved = dist(ball.x, ball.y, *store.restart_origin) > CENTER_LEAVE_DIST_M
    if moved and getattr(store, "restart_moved_at", None) is None:
        store.restart_moved_at = context.now
    receive_target = None
    if moved and context.now - store.restart_moved_at < 0.7:
        taker.action = "restart:follow"
        taker.move_to_position(inside(context, (ball.x - 1.0, ball.y)))
    elif moved:
        taker.attack()  # 裁判尚未清除我方定位球时恢复尝试，不能无限等待
    elif kind == SetPlay.CORNER_KICK:
        receive_target = inside(context, (context.field.length / 2 - 2.0, 1.0 if ball.y > 0 else -1.0))
        taker.attack(receive_target, KICK_LONG)
    elif kind in (SetPlay.INDIRECT_FREE_KICK, SetPlay.THROW_IN):
        receive_target = ((receiver.pose.x, receiver.pose.y)
                          if receiver and receiver.pose.x > ball.x + 0.5
                          else inside(context, (min(ball.x + 1.5, context.field.length / 2 - 1.0), ball.y * 0.65)))
        taker.attack(receive_target, KICK_SHORT)
    elif kind == SetPlay.GOAL_KICK:
        receive_target = inside(context, (ball.x + 3.5, 0.0))
        taker.attack(receive_target, CLEAR_POWER)
    else:
        taker.attack()
    if guard:
        _keeper_independent(context,guard,field,allow_clear=True)
    if receiver:
        if receive_target is not None:
            receiver.action = "restart:receive"
            receiver.move_to_position(receive_target)
        else:
            receiver.support()


def _act_opp_set_play(context: Context, players: list[Player], store) -> None:
    """Referee-FIRST: never contest an opponent restart before ball release.

    V36 ILLEGAL_POSITIONING: robot1 was 0.60-0.69m from opposing THROW_IN
    while y≈4.7m. V37 treats clearance + field bounds as hard constraints,
    including already-illegal starting poses (evacuate toward legal interior).
    """
    if not players:
        return
    ball=context.ball
    if ball is None:
        for p in players:p.stop()
        return
    guard,field = _split_team(context,players)
    targets=[]
    for idx,p in enumerate(field):
        # Defensive shape behind the restart point; two strikers spread out.
        gx,gy=own_goal(context)
        dx,dy=gx-ball.x,gy-ball.y
        norm=max(math.hypot(dx,dy),1e-6)
        side=1 if idx%2==0 else -1
        spread=0.65*side if len(field)>1 else 0.0
        wish=(ball.x+dx/norm*(2.6+0.65*idx)-dy/norm*spread,
              ball.y+dy/norm*(2.6+0.65*idx)+dx/norm*spread)
        safe=restart_retreat(context,wish,radius=RESTART_V37_CLEARANCE_M)
        if safe is None:
            p.action='restart:no_legal_point';p.stop()
            continue
        targets.append((p,safe))
    # Even the goalkeeper must not remain in the illegal restart-radius.
    if guard is not None:
        safe = restart_retreat(context, (-context.field.length/2+KEEPER_HOME_X_FROM_GOAL_M,0),
                               radius=RESTART_V37_CLEARANCE_M)
        if safe is None:
            guard.action='restart:keeper_stop';guard.stop()
        elif dist(guard.pose.x,guard.pose.y,ball.x,ball.y) < RESTART_V37_PANIC_RADIUS_M:
            guard.action='restart:keeper_evacuation'
            guard.walk_to(safe,avoid_ball=True,avoid_robots=False,omni=False)
        else:
            _keeper_independent(context,guard,field,allow_clear=False)
            # guard plan might drift too close; verify target and replace.
            if guard.target is not None and dist(*guard.target,ball.x,ball.y) < RESTART_V37_CLEARANCE_M:
                guard.action='restart:keeper_safe_hold'
                guard.walk_to(safe,avoid_ball=True,avoid_robots=False)
    for idx,(p,target) in enumerate(targets):
        p.release_kick()
        current=dist(p.pose.x,p.pose.y,ball.x,ball.y)
        if current < RESTART_V37_PANIC_RADIUS_M:
            p.action='restart:evacuate_illegal'
        else:
            p.action='restart:safe_block' if idx==0 else 'restart:safe_cover'
        if current >= RESTART_V37_CLEARANCE_M and dist(p.pose.x,p.pose.y,*target) < RESTART_V37_HOLD_EPS_M:
            p.stop()
        else:
            p.move_to_position(target,sprint=False)


def _act_ready(context: Context, players: list[Player]) -> None:
    """按角色布置就绪位，少人时仍把替补门将放到门前。"""
    guard, field = _split_team(context, players)
    if guard:
        guard.action = "ready:keeper"
        guard.walk_to((-context.field.length / 2 + context.field.goal_area_length, 0.0),
                      face=0.0, avoid_ball=True, avoid_robots=True)
    ours = context.game is not None and context.game.kicking_team == context.team_id
    radius = context.field.circle_radius
    slots = [(-radius if ours else -radius - 0.5, 0.0), (KICKOFF_RECEIVER_X if ours else -3.5, KICKOFF_RECEIVER_Y if ours else -2.8)]
    for p, target in zip(sorted(field, key=lambda p: p.id), slots):
        p.action = "ready:field"
        p.walk_to(inside(context, target), face=0.0, avoid_ball=True, avoid_robots=True)


# ======================================================================
# 战场可视化 —— 显示球位置 + 球员到球的距离,画到 ROS 可视化
# ======================================================================

def _draw_teammate_marker(p: Player) -> None:
    """我方队员可视化:红色。踢球中→方块,否则→球体。

    每帧对所有球员统一调用(不受 phase/判罚/就绪影响)。标签两行:
    - 上:编号 + 当前高层动作(``p.action``),踢球中追加 ``[KICK]``。
    - 通过形状(方块 vs 球体)再次区分是否进入 kick 状态。
    """
    from .framework import debugdraw

    if p.pose is None:
        return
    red = (1.0, 0.2, 0.2)
    if p.is_kicking:
        debugdraw.cube(p.pose.x, p.pose.y, rgb=red, scale=0.38, ns="teammate")
    else:
        debugdraw.point(p.pose.x, p.pose.y, rgb=red, scale=0.3, ns="teammate")
    kick_tag = " [KICK]" if p.is_kicking else ""
    label = f"{p.id}:{p.action}{kick_tag} mode={p.mode} nav={p.navigation}"
    debugdraw.text(p.pose.x, p.pose.y, label, rgb=(1.0, 0.9, 0.6), ns="teammate_id")


def _analyze_and_draw(context: Context, players: list[Player], store) -> None:
    """每帧:计算球员到球的距离,画可视化。

    不再依赖 analysis 模块;距离改为基于球当前位置。
    """
    from .framework import debugdraw

    ball = context.ball

    # 球不可见:无可视化
    if ball is None:
        return

    # 1. 画球当前位置(绿色点)
    debugdraw.point(ball.x, ball.y, rgb=(0.0, 1.0, 0.0), scale=0.2, ns="ball_current")

    # 2. 球员到球的距离:我方(红标签)+ 敌方(蓝标签)
    for p in players:
        if p.pose is None:
            continue
        d = dist(p.pose.x, p.pose.y, ball.x, ball.y)
        debugdraw.text(
            p.pose.x + 0.3, p.pose.y - 0.3, f"{d:.1f}m",
            rgb=(1.0, 0.6, 0.6), ns="dist_ours",
        )
    for r in context.opponents.values():
        if r.pose is None:
            continue
        d = dist(r.pose.x, r.pose.y, ball.x, ball.y)
        team = next((t for t in context.game.teams if t.team_number != context.team_id), None) if context.game else None
        state = context.game.get_player_state(team.team_number, r.player_id) if team else None
        tag = f" {state.penalty.value}:{state.secs_till_unpenalised}s" if state and state.penalty.value != "NONE" else ""
        debugdraw.text(r.pose.x + 0.3, r.pose.y - 0.3, f"{d:.1f}m{tag}",
                       rgb=(0.6, 0.6, 1.0), ns="dist_opp")

